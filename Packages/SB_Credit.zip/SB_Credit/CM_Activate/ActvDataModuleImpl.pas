unit ActvDataModuleImpl;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  Oracle, Db, OracleData;

type
  TActvDataMod = class(TDataModule)
    CreditInfo: TOracleDataSet;
    DataSrcCreditInfo: TDataSource;
    ActivationPckg: TOraclePackage;
    CreditInfoOBLIGATION: TFloatField;
    CreditInfoPLEDGEPRICE: TFloatField;
    CreditInfoNAME: TWideStringField;
    CreditInfoVAL_NAME: TWideStringField;
    ActvInfo: TOracleDataSet;
    ActvInfoACTVDATE: TDateTimeField;
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  ActvDataMod: TActvDataMod;

implementation

{$R *.DFM}

uses
  sboapiDataModuleImpl;
  
end.
