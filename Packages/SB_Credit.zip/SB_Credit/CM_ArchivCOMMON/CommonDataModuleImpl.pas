unit CommonDataModuleImpl;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  Db, OracleData;

type
  TCommonDataModule = class(TDataModule)
    ReferencesData: TOracleDataSet;
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  CommonDataModule: TCommonDataModule;

implementation

{$R *.DFM}

uses
  sboapiDataModuleImpl;

end.
