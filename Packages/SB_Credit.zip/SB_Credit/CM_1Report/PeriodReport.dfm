object PeriodReportForm: TPeriodReportForm
  Left = 214
  Top = 118
  Width = 656
  Height = 187
  BorderIcons = [biSystemMenu]
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Azl Sans Serif'
  Font.Style = []
  KeyPreview = True
  OldCreateOrder = False
  Position = poMainFormCenter
  OnCanResize = FormCanResize
  OnCreate = FormCreate
  PixelsPerInch = 96
  TextHeight = 13
  object Panel1: TPanel
    Left = 0
    Top = 0
    Width = 648
    Height = 60
    Align = alTop
    TabOrder = 0
    object GroupBox1: TGroupBox
      Left = 1
      Top = 1
      Width = 216
      Height = 58
      Align = alLeft
      Caption = '�������'
      TabOrder = 0
      object CheckBox1: TCheckBox
        Left = 5
        Top = 38
        Width = 97
        Height = 17
        Caption = '������ ��'
        TabOrder = 0
      end
      object DBLookupComboboxEh1: TDBLookupComboboxEh
        Left = 5
        Top = 14
        Width = 204
        Height = 21
        EditButtons = <>
        KeyField = 'VALUTE'
        ListField = 'VALU_NAME'
        ListSource = DSCurrencys
        TabOrder = 1
        Visible = True
      end
    end
    object GroupBox2: TGroupBox
      Left = 433
      Top = 1
      Width = 214
      Height = 58
      Align = alClient
      Caption = '���������� �����'
      TabOrder = 1
      object DBLookupComboboxEh3: TDBLookupComboboxEh
        Left = 5
        Top = 14
        Width = 204
        Height = 21
        EditButtons = <>
        KeyField = 'ID'
        ListField = 'DESCRIPTION'
        ListSource = DSUserGroups
        TabOrder = 0
        Visible = True
      end
      object CheckBox3: TCheckBox
        Left = 5
        Top = 38
        Width = 97
        Height = 17
        Caption = '������ ��'
        TabOrder = 1
      end
    end
    object GroupBox3: TGroupBox
      Left = 217
      Top = 1
      Width = 216
      Height = 58
      Align = alLeft
      Caption = '������'
      TabOrder = 2
      object DBLookupComboboxEh2: TDBLookupComboboxEh
        Left = 5
        Top = 14
        Width = 204
        Height = 21
        EditButtons = <>
        KeyField = 'ID'
        ListField = 'NAME'
        ListSource = DSBranches
        TabOrder = 0
        Visible = True
      end
      object CheckBox2: TCheckBox
        Left = 6
        Top = 38
        Width = 97
        Height = 17
        Caption = '������ ��'
        TabOrder = 1
      end
    end
  end
  object Panel5: TPanel
    Left = 0
    Top = 60
    Width = 648
    Height = 60
    Align = alTop
    TabOrder = 1
    object GroupBox7: TGroupBox
      Left = 1
      Top = 1
      Width = 216
      Height = 58
      Align = alLeft
      Caption = '���������� ����'
      TabOrder = 0
      object CheckBox7: TCheckBox
        Left = 5
        Top = 38
        Width = 97
        Height = 17
        Caption = '������ ��'
        TabOrder = 0
      end
      object DBLookupComboboxEh7: TDBLookupComboboxEh
        Left = 5
        Top = 14
        Width = 204
        Height = 21
        EditButtons = <>
        KeyField = 'ID'
        ListField = 'DESCRIPION'
        ListSource = DSPersons
        TabOrder = 1
        Visible = True
      end
    end
    object GroupBox9: TGroupBox
      Left = 217
      Top = 1
      Width = 216
      Height = 58
      Align = alLeft
      Caption = '���������� �����������'
      TabOrder = 1
      object CheckBox8: TCheckBox
        Left = 5
        Top = 38
        Width = 97
        Height = 17
        Caption = '������ ��'
        TabOrder = 0
      end
      object DBLookupComboboxEh8: TDBLookupComboboxEh
        Left = 5
        Top = 14
        Width = 204
        Height = 21
        EditButtons = <>
        KeyField = 'ID'
        ListField = 'DESCRIPTION'
        ListSource = DSCategories
        TabOrder = 1
        Visible = True
      end
    end
    object GroupBox4: TGroupBox
      Left = 433
      Top = 1
      Width = 216
      Height = 58
      Align = alLeft
      Caption = '������� �������'
      TabOrder = 2
      object Label1: TLabel
        Left = 8
        Top = 16
        Width = 66
        Height = 13
        Caption = '������ ������'
      end
      object Label2: TLabel
        Left = 8
        Top = 38
        Width = 61
        Height = 13
        Caption = '������ ����'
      end
      object BDateP: TDateTimePicker
        Left = 83
        Top = 12
        Width = 126
        Height = 21
        CalAlignment = dtaLeft
        Date = 38477.5930607986
        Time = 38477.5930607986
        DateFormat = dfShort
        DateMode = dmComboBox
        Kind = dtkDate
        ParseInput = False
        TabOrder = 0
      end
      object EDateP: TDateTimePicker
        Left = 83
        Top = 34
        Width = 126
        Height = 21
        CalAlignment = dtaLeft
        Date = 38477.5930689352
        Time = 38477.5930689352
        DateFormat = dfShort
        DateMode = dmComboBox
        Kind = dtkDate
        ParseInput = False
        TabOrder = 1
      end
    end
  end
  object Button1: TButton
    Left = 488
    Top = 128
    Width = 75
    Height = 25
    Caption = '�����'
    TabOrder = 2
    OnClick = Button1Click
  end
  object Button2: TButton
    Left = 568
    Top = 128
    Width = 75
    Height = 25
    Caption = '�����'
    ModalResult = 2
    TabOrder = 3
  end
  object NLSLocalizer1: TNLSLocalizer
    Caption = '������ �������� (��1)'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -11
    Font.Name = 'Azl Sans Serif'
    Font.Style = []
    Left = 264
    Top = 128
  end
  object CreditsDS: TOracleDataSet
    SQL.Strings = (
      'select ID '
      '  from CM_ACTIVE '
      '')
    ReadBuffer = 25
    Optimize = True
    Debug = False
    StringFieldsOnly = False
    SequenceField.ApplyMoment = amOnPost
    OracleDictionary.EnforceConstraints = False
    OracleDictionary.UseMessageTable = False
    OracleDictionary.DefaultValues = False
    OracleDictionary.DynamicDefaults = False
    OracleDictionary.FieldKinds = False
    OracleDictionary.DisplayFormats = False
    OracleDictionary.RangeValues = False
    QBEDefinition.SaveQBEValues = True
    QBEDefinition.AllowFileWildCards = True
    Cursor = crSQLWait
    ReadOnly = False
    LockingMode = lmCheckImmediate
    QueryAllRecords = True
    CountAllRecords = False
    RefreshOptions = []
    CommitOnPost = True
    CachedUpdates = False
    QBEMode = False
    Session = CMDataModule.CMSession
    DesignActivation = False
    Active = False
    Left = 216
    Top = 96
  end
  object CM_AK_REPORTS: TOraclePackage
    Session = CMDataModule.CMSession
    Debug = False
    PackageName = 'CM_AK_REPORTS'
    ParameterMode = pmNamed
    Cursor = crHourGlass
    Optimize = True
    Left = 344
    Top = 128
  end
  object DSCurrencys: TDataSource
    DataSet = Currencys
    Left = 8
    Top = 128
  end
  object Currencys: TOracleDataSet
    SQL.Strings = (
      'SELECT valute,  valu_name'
      '  FROM SB_AVALUTE'
      'ORDER BY VALUTE')
    ReadBuffer = 25
    Optimize = True
    Debug = False
    StringFieldsOnly = False
    SequenceField.ApplyMoment = amOnPost
    OracleDictionary.EnforceConstraints = False
    OracleDictionary.UseMessageTable = False
    OracleDictionary.DefaultValues = False
    OracleDictionary.DynamicDefaults = False
    OracleDictionary.FieldKinds = False
    OracleDictionary.DisplayFormats = False
    OracleDictionary.RangeValues = False
    QBEDefinition.SaveQBEValues = True
    QBEDefinition.AllowFileWildCards = True
    Cursor = crSQLWait
    ReadOnly = False
    LockingMode = lmCheckImmediate
    QueryAllRecords = True
    CountAllRecords = False
    RefreshOptions = []
    CommitOnPost = True
    CachedUpdates = False
    QBEMode = False
    Session = CMDataModule.CMSession
    DesignActivation = False
    Active = False
    Left = 8
    Top = 96
  end
  object DSBranches: TDataSource
    DataSet = Branches
    Left = 48
    Top = 128
  end
  object Branches: TOracleDataSet
    SQL.Strings = (
      'SELECT id, name'
      '  FROM SB_filial')
    ReadBuffer = 25
    Optimize = True
    Debug = False
    StringFieldsOnly = False
    SequenceField.ApplyMoment = amOnPost
    OracleDictionary.EnforceConstraints = False
    OracleDictionary.UseMessageTable = False
    OracleDictionary.DefaultValues = False
    OracleDictionary.DynamicDefaults = False
    OracleDictionary.FieldKinds = False
    OracleDictionary.DisplayFormats = False
    OracleDictionary.RangeValues = False
    QBEDefinition.SaveQBEValues = True
    QBEDefinition.AllowFileWildCards = True
    Cursor = crSQLWait
    ReadOnly = False
    LockingMode = lmCheckImmediate
    QueryAllRecords = True
    CountAllRecords = False
    RefreshOptions = []
    CommitOnPost = True
    CachedUpdates = False
    QBEMode = False
    Session = CMDataModule.CMSession
    DesignActivation = False
    Active = False
    Left = 48
    Top = 96
  end
  object DSUserGroups: TDataSource
    DataSet = UserGroups
    Left = 168
    Top = 128
  end
  object UserGroups: TOracleDataSet
    SQL.Strings = (
      'SELECT id, description'
      '  FROM cm_usergroups')
    ReadBuffer = 25
    Optimize = True
    Debug = False
    StringFieldsOnly = False
    SequenceField.ApplyMoment = amOnPost
    OracleDictionary.EnforceConstraints = False
    OracleDictionary.UseMessageTable = False
    OracleDictionary.DefaultValues = False
    OracleDictionary.DynamicDefaults = False
    OracleDictionary.FieldKinds = False
    OracleDictionary.DisplayFormats = False
    OracleDictionary.RangeValues = False
    QBEDefinition.SaveQBEValues = True
    QBEDefinition.AllowFileWildCards = True
    Cursor = crSQLWait
    ReadOnly = False
    LockingMode = lmCheckImmediate
    QueryAllRecords = True
    CountAllRecords = False
    RefreshOptions = []
    CommitOnPost = True
    CachedUpdates = False
    QBEMode = False
    Session = CMDataModule.CMSession
    DesignActivation = False
    Active = False
    Left = 168
    Top = 96
  end
  object DSPersons: TDataSource
    DataSet = Persons
    Left = 88
    Top = 128
  end
  object Persons: TOracleDataSet
    SQL.Strings = (
      'SELECT id,  descripion'
      '  FROM cm_persons')
    ReadBuffer = 25
    Optimize = True
    Debug = False
    StringFieldsOnly = False
    SequenceField.ApplyMoment = amOnPost
    OracleDictionary.EnforceConstraints = False
    OracleDictionary.UseMessageTable = False
    OracleDictionary.DefaultValues = False
    OracleDictionary.DynamicDefaults = False
    OracleDictionary.FieldKinds = False
    OracleDictionary.DisplayFormats = False
    OracleDictionary.RangeValues = False
    QBEDefinition.SaveQBEValues = True
    QBEDefinition.AllowFileWildCards = True
    Cursor = crSQLWait
    ReadOnly = False
    LockingMode = lmCheckImmediate
    QueryAllRecords = True
    CountAllRecords = False
    RefreshOptions = []
    CommitOnPost = True
    CachedUpdates = False
    QBEMode = False
    Session = CMDataModule.CMSession
    DesignActivation = False
    Active = False
    Left = 88
    Top = 96
  end
  object DSCategories: TDataSource
    DataSet = Categories
    Left = 128
    Top = 128
  end
  object Categories: TOracleDataSet
    SQL.Strings = (
      'SELECT id, description'
      '  FROM cm_categories')
    ReadBuffer = 25
    Optimize = True
    Debug = False
    StringFieldsOnly = False
    SequenceField.ApplyMoment = amOnPost
    OracleDictionary.EnforceConstraints = False
    OracleDictionary.UseMessageTable = False
    OracleDictionary.DefaultValues = False
    OracleDictionary.DynamicDefaults = False
    OracleDictionary.FieldKinds = False
    OracleDictionary.DisplayFormats = False
    OracleDictionary.RangeValues = False
    QBEDefinition.SaveQBEValues = True
    QBEDefinition.AllowFileWildCards = True
    Cursor = crSQLWait
    ReadOnly = False
    LockingMode = lmCheckImmediate
    QueryAllRecords = True
    CountAllRecords = False
    RefreshOptions = []
    CommitOnPost = True
    CachedUpdates = False
    QBEMode = False
    Session = CMDataModule.CMSession
    DesignActivation = False
    Active = False
    Left = 128
    Top = 96
  end
  object ResultDS: TOracleDataSet
    SQL.Strings = (
      'SELECT p.numberofcredit, r.*, b.name,'
      'h.descripion person,'
      'g.description project,'
      'getbranchname(p.branchid) filial'
      ' FROM CM_REPORT_SD1 r,'
      '      cm_boorowerinfo b,'
      '      cm_portfolio p,'
      '      cm_persons h,'
      '      cm_usergroups g'
      '--    , sb_filial f'
      ' where r.creditid = b.creditid'
      '   and r.creditid=p.id'
      '   and h.id = p.personaltype'
      '   and g.id = p.usrgroup'
      '--   and f.id = p.branchid')
    ReadBuffer = 25
    Optimize = True
    Debug = False
    StringFieldsOnly = False
    SequenceField.ApplyMoment = amOnPost
    OracleDictionary.EnforceConstraints = False
    OracleDictionary.UseMessageTable = False
    OracleDictionary.DefaultValues = False
    OracleDictionary.DynamicDefaults = False
    OracleDictionary.FieldKinds = False
    OracleDictionary.DisplayFormats = False
    OracleDictionary.RangeValues = False
    QBEDefinition.SaveQBEValues = True
    QBEDefinition.AllowFileWildCards = True
    Cursor = crSQLWait
    ReadOnly = False
    LockingMode = lmCheckImmediate
    QueryAllRecords = True
    CountAllRecords = False
    RefreshOptions = []
    CommitOnPost = True
    CachedUpdates = False
    QBEMode = False
    Session = CMDataModule.CMSession
    DesignActivation = False
    Active = False
    Left = 216
    Top = 128
    object ResultDSCREDITID: TFloatField
      FieldName = 'CREDITID'
      Required = True
      Visible = False
    end
    object ResultDSNUMBEROFCREDIT: TStringField
      DisplayLabel = '���. �'
      FieldName = 'NUMBEROFCREDIT'
      Size = 32
    end
    object ResultDSNAME: TStringField
      DisplayLabel = '��������'
      FieldName = 'NAME'
      Size = 64
    end
    object ResultDSPERSON: TStringField
      DisplayLabel = '���������� ����.'
      FieldName = 'PERSON'
      Size = 64
    end
    object ResultDSPROJECT: TStringField
      DisplayLabel = '������'
      FieldName = 'PROJECT'
      Size = 64
    end
    object ResultDSFILIAL: TStringField
      DisplayLabel = '������'
      FieldName = 'FILIAL'
      Size = 90
    end
    object ResultDSPBMAIN: TFloatField
      DisplayLabel = '�.�.���� �.'
      FieldName = 'PBMAIN'
      Required = True
      DisplayFormat = '#,#0.00'
    end
    object ResultDSPBINT: TFloatField
      DisplayLabel = '�.�. ���� �'
      FieldName = 'PBINT'
      Required = True
      DisplayFormat = '#,#0.00'
    end
    object ResultDSPBDUEMAIN: TFloatField
      DisplayLabel = '�.�. ���. ���� �'
      FieldName = 'PBDUEMAIN'
      Required = True
      DisplayFormat = '#,#0.00'
    end
    object ResultDSPBDUEINT: TFloatField
      DisplayLabel = '�.�. ��� ���� �'
      FieldName = 'PBDUEINT'
      Required = True
      DisplayFormat = '#,#0.00'
    end
    object ResultDSPAYMAIN: TFloatField
      DisplayLabel = '����. ���� �'
      FieldName = 'PAYMAIN'
      Required = True
      DisplayFormat = '#,#0.00'
    end
    object ResultDSPAYINT: TFloatField
      DisplayLabel = '����. ���� �'
      FieldName = 'PAYINT'
      Required = True
      DisplayFormat = '#,#0.00'
    end
    object ResultDSPAYDUE: TFloatField
      DisplayLabel = '����. ���. ���� �'
      FieldName = 'PAYDUE'
      Required = True
      DisplayFormat = '#,#0.00'
    end
    object ResultDSPAYDUEINT: TFloatField
      DisplayLabel = '����. ��� ���� �'
      FieldName = 'PAYDUEINT'
      Required = True
      DisplayFormat = '#,#0.00'
    end
    object ResultDSTRANCHEMAIN: TFloatField
      DisplayLabel = '�������� ���.'
      FieldName = 'TRANCHEMAIN'
      Required = True
      DisplayFormat = '#,#0.00'
    end
    object ResultDSPEMAIN: TFloatField
      DisplayLabel = '�.�.���� �.'
      FieldName = 'PEMAIN'
      Required = True
      DisplayFormat = '#,#0.00'
    end
    object ResultDSPEINT: TFloatField
      DisplayLabel = '�.�.���� �.'
      FieldName = 'PEINT'
      Required = True
      DisplayFormat = '#,#0.00'
    end
    object ResultDSPEDUEMAIN: TFloatField
      DisplayLabel = '�.�. ��� ���� �.'
      FieldName = 'PEDUEMAIN'
      Required = True
      DisplayFormat = '#,#0.00'
    end
    object ResultDSPEDUEINT: TFloatField
      DisplayLabel = '�.�. ��� ���� �.'
      FieldName = 'PEDUEINT'
      Required = True
      DisplayFormat = '#,#0.00'
    end
    object ResultDSCRDPERIOD: TFloatField
      DisplayLabel = '������'
      FieldName = 'CRDPERIOD'
      Required = True
    end
  end
  object Kera: TCMExcelExport
    ConnectTo = ctNewInstance
    StyleColumnWidth = cwAutoFit
    ColumnWidth = 0
    FontTitles.Charset = DEFAULT_CHARSET
    FontTitles.Color = clGreen
    FontTitles.Height = -11
    FontTitles.Name = 'Azl Sans Serif'
    FontTitles.Style = [fsBold]
    OrientationTitles = 0
    FontData.Charset = RUSSIAN_CHARSET
    FontData.Color = clWindowText
    FontData.Height = -11
    FontData.Name = 'Azl Sans Serif'
    FontData.Style = []
    FontSummary.Charset = DEFAULT_CHARSET
    FontSummary.Color = clWindowText
    FontSummary.Height = -11
    FontSummary.Name = 'Azl Sans Serif'
    FontSummary.Style = []
    SummarySelection = ssNone
    SummaryCalculation = scSUM
    Left = 376
    Top = 8
  end
end
