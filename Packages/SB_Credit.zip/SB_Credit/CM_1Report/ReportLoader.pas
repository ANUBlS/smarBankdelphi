unit ReportLoader;

interface


procedure InitPlugin(S : String);export;

implementation

uses
  MISImpl, PeriodReport, CommonDecls;

procedure ShowMisReport;
begin
  with TMISForm.Create(CommonApplication) do
  try
    ShowModal
  finally
    Release
  end;
end;

procedure ShowPeriodReport;
begin
  with TPeriodReportForm.Create(CommonApplication) do
  try
    ShowMe;
  finally
    Release
  end;
end;

procedure InitPlugin(S : String);export;
const
  SMisReport='MIS';
  SPeriodReport='PERIODREPORT';
begin
  if S = SMisReport then
    ShowMisReport
  else if S = SPeriodReport then
    ShowPeriodReport;
end;

exports
  InitPlugin;

end.
