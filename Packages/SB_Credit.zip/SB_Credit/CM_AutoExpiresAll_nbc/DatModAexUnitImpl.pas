unit DatModAexUnitImpl;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  Db, OracleData;

type
  TDatModAex = class(TDataModule)
    DatSetExpCredits: TOracleDataSet;
    DatSrcExpCredits: TDataSource;
    DatSetExpCreditsNUMBEROFCREDIT: TWideStringField;
    DatSetExpCreditsNAME: TWideStringField;
    DatSetExpCreditsCUSTACCREST: TFloatField;
    DatSetExpCreditsPRINCIPAL: TFloatField;
    DatSetExpCreditsPENALTYREST: TFloatField;
    DatSetPayments: TOracleDataSet;
    DatSetSchedule: TOracleDataSet;
    DatSrcPayments: TDataSource;
    DatSrcSchedule: TDataSource;
    DatSetPaymentsPAYDATE: TDateTimeField;
    DatSetPaymentsPAYEDAMT: TFloatField;
    DatSetPaymentsPAYEDINTAMT: TFloatField;
    DatSetPaymentsPAYEDPENALTYAMT: TFloatField;
    DatSetSchedulePAYMENTDATE: TDateTimeField;
    DatSetSchedulePRINCIPAL: TFloatField;
    DatSetScheduleINTEREST: TFloatField;
    DatSetTranches: TOracleDataSet;
    DatSrcTranches: TDataSource;
    DatSetTranchesTRANCHEDATE: TDateTimeField;
    DatSetTranchesTRANCHEAMOUNT: TFloatField;
    DatSetInterests: TOracleDataSet;
    DatSrcInterests: TDataSource;
    DatSetInterestsHDATE: TDateTimeField;
    DatSetInterestsINTEREST: TFloatField;
    DatSetInterestsDUEINTEREST: TFloatField;
    DatSetInterestsPENALTYINTEREST: TFloatField;
    DatSetPaymentsPAYEDDUEAMT: TFloatField;
    DatSetPaymentsPAYEDDUEINTAMT: TFloatField;
    DatSetExpCreditsID: TFloatField;
    DatSetExpCreditsEXPDATCOUNT: TFloatField;
    DatSetReserves: TOracleDataSet;
    DatSrcReserves: TDataSource;
    DatSetCategories: TOracleDataSet;
    DatSrcPersons: TDataSource;
    DatSetCreditTypes: TOracleDataSet;
    DatSrctCategories: TDataSource;
    DatSetValute: TOracleDataSet;
    DatSrcCreditTypes: TDataSource;
    DatSetFilials: TOracleDataSet;
    DatSrcFilials: TDataSource;
    DatSetPersons: TOracleDataSet;
    DatSrcValute: TDataSource;
    DatSetValuteVALUTE: TIntegerField;
    DatSetValuteVALU_NAME: TWideStringField;
    DatSetPersonsID: TFloatField;
    DatSetPersonsDESCRIPION: TWideStringField;
    DatSetCategoriesID: TFloatField;
    DatSetCreditTypesID: TFloatField;
    DatSetCreditTypesDESCRIPTION: TWideStringField;
    DatSetReservesID: TFloatField;
    DatSetReservesDESCRIPTION: TWideStringField;
    DatSetExpCreditsVAL_NAME: TWideStringField;
    DatSetExpCreditsCONTRACTACCNO: TWideStringField;
    DatSetExpCreditsCURRENCY: TFloatField;
    DatSetExpCreditsPERSONALTYPE: TFloatField;
    DatSetExpCreditsCUSTOMERTYPE: TFloatField;
    DatSetExpCreditsBRANCHID: TFloatField;
    DatSetExpCreditsCREDITTYPE: TFloatField;
    DatSetExpCreditsRESERVEID: TFloatField;
    DatSetExpCreditsSUMAMT: TFloatField;
    DatSetExpCreditsPLR: TFloatField;
    DatSetExpCreditsOPENDATE: TDateTimeField;
    DatSetExpCreditsCLOSEDATE: TDateTimeField;
    DatSetExpCreditsANNUALYINTERESTRATE: TFloatField;
    DatSetExpCreditsBALACCNO: TFloatField;
    DatSetExpCreditsBOOROWERID: TFloatField;
    DatSetExpCreditsPHONENUMBER: TWideStringField;
    DatSetExpCredits_: TOracleDataSet;
    DatSetExpCredits_ID: TFloatField;
    DatSetExpCredits_NUMBEROFCREDIT: TWideStringField;
    DatSetExpCredits_OPENDATE: TDateTimeField;
    DatSetExpCredits_CLOSEDATE: TDateTimeField;
    DatSetExpCredits_ANNUALYINTERESTRATE: TFloatField;
    DatSetExpCredits_BOOROWERID: TFloatField;
    DatSetExpCredits_CONTRACTACCNO: TWideStringField;
    DatSetExpCredits_VAL_NAME: TWideStringField;
    DatSetExpCredits_CUSTACCREST: TFloatField;
    DatSetExpCredits_PRINCIPAL: TFloatField;
    DatSetExpCredits_INTEREST: TFloatField;
    DatSetExpCredits_SUMAMT: TFloatField;
    DatSetExpCredits_PENALTYREST: TFloatField;
    DatSetExpCredits_RESERVEID: TFloatField;
    DatSetExpCredits_BALACCNO: TFloatField;
    DatSetExpCredits_NAME: TWideStringField;
    DatSetExpCredits_OUTDAT: TDateTimeField;
    DatSetExpCredits_PLANREST: TFloatField;
    DatSetExpCredits_CURRENCY: TFloatField;
    DatSetExpCredits_PERSONALTYPE: TFloatField;
    DatSetExpCredits_CUSTOMERTYPE: TFloatField;
    DatSetExpCredits_BRANCHID: TFloatField;
    DatSetExpCredits_CREDITTYPE: TFloatField;
    DatSetExpCredits_DATEOFCONCLUSION: TDateTimeField;
    DatSetExpCredits_DUEDATEFIRSTCONTRACT: TDateTimeField;
    DatSetExpCredits_DUEDATELASTCONTRACT: TDateTimeField;
    DatSetExpCredits_EXDATCOUNT: TFloatField;
    DatSetExpCredits_PHONENUMBER: TWideStringField;
    OracleDataSet1: TOracleDataSet;
    DatSetExpCreditsSALARY: TWideStringField;
    DatSetExpCredits_SALARY: TWideStringField;
    DatSetExpCreditsCREDITEND: TWideStringField;
    DatSetExpCreditsREST: TFloatField;
    DatSetExpCreditsINTERESTREST: TFloatField;
    DatSetCategoriesDESCRIPTION: TWideStringField;
    DatSetExpCreditsGUARANTORNAME: TWideStringField;
    DatSetExpCreditsZAMINWORK1: TWideStringField;
    DatSetExpCreditsZAMINTEL1: TWideStringField;
    DatSetExpCreditsZMTELMOB1: TWideStringField;
    DatSetExpCreditsNAME2: TWideStringField;
    DatSetExpCreditsWR2: TWideStringField;
    DatSetExpCreditsEVTEL2: TWideStringField;
    DatSetExpCreditsMOBTEL2: TWideStringField;
    DatSetExpCreditsNAME3: TWideStringField;
    DatSetExpCreditsWR3: TWideStringField;
    DatSetExpCreditsEVTEL3: TWideStringField;
    DatSetExpCreditsMOBTEL3: TWideStringField;
    DatSetExpCreditsDUEREST: TFloatField;
    DatSetExpCreditsFILIAL: TWideStringField;
    DatSetExpCreditsKREDITTIP: TWideStringField;
    OracleDataSet2: TOracleDataSet;
    FloatField1: TFloatField;
    WideStringField1: TWideStringField;
    WideStringField2: TWideStringField;
    WideStringField3: TWideStringField;
    DateTimeField1: TDateTimeField;
    DateTimeField2: TDateTimeField;
    FloatField2: TFloatField;
    FloatField3: TFloatField;
    WideStringField4: TWideStringField;
    WideStringField5: TWideStringField;
    FloatField4: TFloatField;
    FloatField5: TFloatField;
    FloatField6: TFloatField;
    WideStringField6: TWideStringField;
    WideStringField7: TWideStringField;
    FloatField7: TFloatField;
    FloatField8: TFloatField;
    FloatField9: TFloatField;
    FloatField10: TFloatField;
    FloatField11: TFloatField;
    FloatField12: TFloatField;
    FloatField13: TFloatField;
    FloatField14: TFloatField;
    FloatField15: TFloatField;
    FloatField16: TFloatField;
    FloatField17: TFloatField;
    FloatField18: TFloatField;
    FloatField19: TFloatField;
    WideStringField8: TWideStringField;
    WideStringField9: TWideStringField;
    WideStringField10: TWideStringField;
    WideStringField11: TWideStringField;
    WideStringField12: TWideStringField;
    WideStringField13: TWideStringField;
    WideStringField14: TWideStringField;
    WideStringField15: TWideStringField;
    WideStringField16: TWideStringField;
    WideStringField17: TWideStringField;
    WideStringField18: TWideStringField;
    WideStringField19: TWideStringField;
    WideStringField20: TWideStringField;
    WideStringField21: TWideStringField;
    WideStringField22: TWideStringField;
    WideStringField23: TWideStringField;
    WideStringField24: TWideStringField;
    WideStringField25: TWideStringField;
    DatSetExpCreditsDAT: TDateTimeField;
    DatSetExpCreditsMAXPAY: TFloatField;
    procedure DataModuleCreate(Sender: TObject);
    procedure DataModuleDestroy(Sender: TObject);
  private
  public
    { Public declarations }
  end;

var
  DatModAex: TDatModAex;

implementation

{$R *.DFM}
uses sboapiDataModuleImpl;



procedure TDatModAex.DataModuleCreate(Sender: TObject);
begin
   DatSetValute.Open;
   DatSetFilials.open;
   DatSetPersons.open;
   DatSetCategories.open;
   DatSetCreditTypes.open;
   DatSetReserves.open;
end;

procedure TDatModAex.DataModuleDestroy(Sender: TObject);
begin
   DatSetValute.CloseAll;
   DatSetFilials.CloseAll;
   DatSetPersons.CloseAll;
   DatSetCategories.CloseAll;
   DatSetCreditTypes.CloseAll;
   DatSetReserves.CloseAll;

end;

end.
