object frmBCFilter: TfrmBCFilter
  Left = 665
  Top = 240
  ClientHeight = 439
  ClientWidth = 690
  Color = clBtnFace
  Font.Charset = RUSSIAN_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  KeyPreview = True
  OldCreateOrder = False
  Position = poMainFormCenter
  OnCanResize = FormCanResize
  OnCreate = FormCreate
  OnDestroy = FormDestroy
  PixelsPerInch = 96
  TextHeight = 13
  object Panel1: TPanel
    Left = 0
    Top = 0
    Width = 690
    Height = 67
    Align = alTop
    BevelInner = bvRaised
    BevelOuter = bvLowered
    TabOrder = 0
    object GroupBox1: TGroupBox
      Left = 2
      Top = 2
      Width = 224
      Height = 63
      Align = alLeft
      Caption = #1042#1072#1083#1081#1091#1090#1072
      TabOrder = 0
      object CheckBox1: TCheckBox
        Left = 5
        Top = 41
        Width = 105
        Height = 18
        Caption = #1058#1103#1090#1073#1080#1075' '#1077#1090
        TabOrder = 0
      end
      object DBLookupComboboxEh1: TDBLookupComboboxEh
        Left = 5
        Top = 15
        Width = 210
        Height = 21
        DropDownBox.Sizable = True
        EditButtons = <>
        KeyField = 'VALUTE'
        ListField = 'VALU_NAME'
        ListSource = DSCurrencys
        TabOrder = 1
        Visible = True
      end
    end
    object GroupBox2: TGroupBox
      Left = 459
      Top = 2
      Width = 229
      Height = 63
      Align = alClient
      Caption = #1048#1089#1090#1080#1092#1072#1076#1103#1095#1080' '#1075#1088#1091#1087#1091
      TabOrder = 1
      object DBLookupComboboxEh3: TDBLookupComboboxEh
        Left = 5
        Top = 15
        Width = 220
        Height = 21
        DropDownBox.Sizable = True
        EditButtons = <>
        KeyField = 'ID'
        ListField = 'DESCRIPTION'
        ListSource = DSUserGroups
        TabOrder = 0
        Visible = True
      end
      object CheckBox3: TCheckBox
        Left = 5
        Top = 41
        Width = 105
        Height = 16
        Caption = #1058#1103#1090#1073#1080#1075' '#1077#1090
        TabOrder = 1
      end
    end
    object GroupBox3: TGroupBox
      Left = 226
      Top = 2
      Width = 233
      Height = 63
      Align = alLeft
      Caption = #1060#1080#1083#1080#1072#1083
      TabOrder = 2
      object DBLookupComboboxEh2: TDBLookupComboboxEh
        Left = 5
        Top = 15
        Width = 220
        Height = 21
        DropDownBox.Sizable = True
        EditButtons = <>
        KeyField = 'ID'
        ListField = 'NAME'
        ListSource = DSBranches
        TabOrder = 0
        Visible = True
      end
      object CheckBox2: TCheckBox
        Left = 6
        Top = 41
        Width = 105
        Height = 18
        Caption = #1058#1103#1090#1073#1080#1075' '#1077#1090
        TabOrder = 1
      end
    end
  end
  object Panel5: TPanel
    Left = 0
    Top = 67
    Width = 690
    Height = 64
    Align = alTop
    BevelInner = bvRaised
    BevelOuter = bvLowered
    TabOrder = 1
    object GroupBox7: TGroupBox
      Left = 2
      Top = 2
      Width = 224
      Height = 60
      Align = alLeft
      Caption = #1041#1086#1088#1078#1072#1083#1072#1085#1099#1085' '#1090#1080#1087#1080
      TabOrder = 0
      object CheckBox7: TCheckBox
        Left = 5
        Top = 40
        Width = 105
        Height = 18
        Caption = #1058#1103#1090#1073#1080#1075' '#1077#1090
        TabOrder = 0
      end
      object DBLookupComboboxEh7: TDBLookupComboboxEh
        Left = 5
        Top = 15
        Width = 210
        Height = 21
        DropDownBox.Sizable = True
        EditButtons = <>
        KeyField = 'ID'
        ListField = 'DESCRIPION'
        ListSource = DSPersons
        TabOrder = 1
        Visible = True
      end
    end
    object GroupBox9: TGroupBox
      Left = 226
      Top = 2
      Width = 233
      Height = 60
      Align = alLeft
      Caption = #1041#1086#1088#1078#1072#1083#1072#1085#1099#1085' '#1082#1072#1090#1077#1075#1086#1088#1081#1072#1089#1099
      TabOrder = 1
      object CheckBox8: TCheckBox
        Left = 5
        Top = 40
        Width = 105
        Height = 18
        Caption = #1058#1103#1090#1073#1080#1075' '#1077#1090
        TabOrder = 0
      end
      object DBLookupComboboxEh8: TDBLookupComboboxEh
        Left = 5
        Top = 15
        Width = 220
        Height = 21
        DropDownBox.Sizable = True
        EditButtons = <>
        KeyField = 'ID'
        ListField = 'DESCRIPTION'
        ListSource = DSCategories
        TabOrder = 1
        Visible = True
      end
    end
    object GroupBox13: TGroupBox
      Left = 459
      Top = 2
      Width = 232
      Height = 60
      Align = alLeft
      Caption = #1042#1077#1088#1080#1083#1084#1103' '#1087#1077#1088#1080#1086#1076#1091
      TabOrder = 2
      object CheckBox11: TCheckBox
        Left = 5
        Top = 40
        Width = 105
        Height = 18
        Caption = #1058#1103#1090#1073#1080#1075' '#1077#1090
        TabOrder = 0
      end
      object DBLookupComboboxEh9: TDBLookupComboboxEh
        Left = 5
        Top = 15
        Width = 220
        Height = 21
        DropDownBox.Sizable = True
        EditButtons = <>
        KeyField = 'ID'
        ListField = 'PURPOSEDESC'
        ListSource = DSPeriods
        TabOrder = 1
        Visible = True
      end
    end
  end
  object Panel2: TPanel
    Left = 0
    Top = 200
    Width = 690
    Height = 68
    Align = alTop
    BevelInner = bvRaised
    BevelOuter = bvLowered
    TabOrder = 2
    object GroupBox6: TGroupBox
      Left = 225
      Top = 2
      Width = 186
      Height = 64
      Align = alLeft
      Caption = #1052#1094#1096#1090#1103#1088#1080
      TabOrder = 0
      DesignSize = (
        186
        64)
      object CheckBox5: TCheckBox
        Left = 5
        Top = 41
        Width = 78
        Height = 18
        Caption = #1058#1103#1090#1073#1080#1075' '#1077#1090
        TabOrder = 0
        OnClick = CheckBox5Click
      end
      object DBLookupComboboxEh4: TDBLookupComboboxEh
        Left = 5
        Top = 15
        Width = 174
        Height = 21
        Anchors = [akLeft, akTop, akRight]
        DropDownBox.Sizable = True
        EditButtons = <>
        KeyField = 'ID'
        ListField = 'IDNAME'
        ListSource = DSCustName
        TabOrder = 1
        Visible = True
      end
    end
    object GroupBox8: TGroupBox
      Left = 2
      Top = 2
      Width = 223
      Height = 64
      Align = alLeft
      Caption = 'Rayon'
      TabOrder = 1
      DesignSize = (
        223
        64)
      object CheckBox6: TCheckBox
        Left = 5
        Top = 41
        Width = 105
        Height = 18
        Caption = #1058#1103#1090#1073#1080#1075' '#1077#1090
        TabOrder = 0
      end
      object DBLookupComboboxEh5: TDBLookupComboboxEh
        Left = 5
        Top = 15
        Width = 210
        Height = 21
        Anchors = [akLeft, akTop, akRight]
        DropDownBox.Sizable = True
        EditButtons = <>
        KeyField = 'ID'
        ListField = 'IDNAME'
        ListSource = DSDistricts
        TabOrder = 1
        Visible = True
      end
    end
    object GroupBox10: TGroupBox
      Left = 411
      Top = 2
      Width = 153
      Height = 64
      Align = alClient
      Caption = #1052#1094#1096#1090#1103#1088#1080' '#1082#1086#1076#1091
      TabOrder = 2
      DesignSize = (
        153
        64)
      object CheckBox9: TCheckBox
        Left = 5
        Top = 41
        Width = 78
        Height = 18
        Caption = #1058#1103#1090#1073#1080#1075' '#1077#1090
        TabOrder = 0
        OnClick = CheckBox5Click
      end
      object DBLookupComboboxEh6: TDBLookupComboboxEh
        Left = 5
        Top = 15
        Width = 194
        Height = 21
        Anchors = [akLeft, akTop, akRight]
        DropDownBox.Sizable = True
        EditButtons = <>
        KeyField = 'ID'
        ListField = 'IDNAME'
        ListSource = DSCustomers
        TabOrder = 1
        Visible = True
      end
    end
    object GroupBox11: TGroupBox
      Left = 564
      Top = 2
      Width = 124
      Height = 64
      Align = alRight
      Caption = #1065#1077#1089#1072#1073#1072#1090
      TabOrder = 3
      DesignSize = (
        124
        64)
      object CheckBox10: TCheckBox
        Left = 5
        Top = 41
        Width = 78
        Height = 18
        Caption = #1058#1103#1090#1073#1080#1075' '#1077#1090
        Checked = True
        Color = clSilver
        Enabled = False
        ParentColor = False
        State = cbChecked
        TabOrder = 0
        OnClick = CheckBox5Click
      end
      object cbFormsLook: TDBLookupComboboxEh
        Left = 5
        Top = 15
        Width = 111
        Height = 21
        Anchors = [akLeft, akTop, akRight]
        DropDownBox.Sizable = True
        EditButtons = <>
        KeyField = 'ID'
        ListField = 'NAME'
        ListSource = DSRepForms
        TabOrder = 1
        Visible = True
        OnChange = cbFormsLookChange
      end
    end
  end
  object Panel3: TPanel
    Left = 0
    Top = 334
    Width = 690
    Height = 68
    Align = alTop
    BevelInner = bvRaised
    BevelOuter = bvLowered
    TabOrder = 3
    object RGReportType: TRadioGroup
      Left = 320
      Top = 2
      Width = 187
      Height = 64
      Align = alClient
      Caption = 'Hesabat'
      ItemIndex = 0
      Items.Strings = (
        'Excel'
        'Hesabat')
      TabOrder = 0
    end
    object rgPR: TRadioGroup
      Left = 174
      Top = 2
      Width = 146
      Height = 64
      Align = alLeft
      Caption = #1069#1077#1078#1080#1082#1084#1103#1083#1103#1088#1080' '#1089#1072#1081#1084#1072#1075
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -12
      Font.Name = 'Azl Sans Serif'
      Font.Style = []
      ItemIndex = 0
      Items.Strings = (
        'QALIQLAR '#1094#1079#1088#1103
        #1057#1061#1045#1052' '#1094#1079#1088#1103)
      ParentFont = False
      TabOrder = 1
    end
    object GroupBox5: TGroupBox
      Left = 2
      Top = 2
      Width = 172
      Height = 64
      Align = alLeft
      Caption = #1063#1072#1087' '#1076#1103#1088#1080#1085#1083#1080#1081#1080
      TabOrder = 2
      object cbPrintDeep: TComboBox
        Left = 4
        Top = 17
        Width = 156
        Height = 21
        Style = csDropDownList
        DropDownCount = 4
        TabOrder = 0
        Items.Strings = (
          'M'#252#351't'#601'ri'
          'K'#601'nd'
          'Payon'
          'Filial'
          'Sah'#601'l'#601'r'
          'M'#601'hsullar')
      end
      object CheckBox4: TCheckBox
        Left = 4
        Top = 41
        Width = 105
        Height = 18
        Caption = #1058#1103#1090#1073#1080#1075' '#1077#1090
        TabOrder = 1
      end
    end
    object rgKredStatus: TRadioGroup
      Left = 507
      Top = 2
      Width = 181
      Height = 64
      Align = alRight
      Caption = 'Kre'#1076'itl'#1103'r'
      ItemIndex = 0
      Items.Strings = (
        'Aktiv olanlar'
        'Ham'#1099's'#1099
        #1041#1072#1100#1083#1099' '#1082#1088#1077#1076#1080#1090#1083#1103#1088)
      TabOrder = 3
    end
  end
  object Panel4: TPanel
    Left = 0
    Top = 402
    Width = 690
    Height = 37
    Align = alTop
    BevelInner = bvRaised
    BevelOuter = bvLowered
    TabOrder = 4
    object Button1: TButton
      Left = 320
      Top = 4
      Width = 81
      Height = 27
      Caption = #1043#1103#1073#1091#1083
      Font.Charset = RUSSIAN_CHARSET
      Font.Color = clWindowText
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = [fsBold]
      ParentFont = False
      TabOrder = 0
      OnClick = Button1Click
    end
    object btnYeniden: TButton
      Left = 417
      Top = 5
      Width = 81
      Height = 26
      Caption = #1049#1077#1085#1080#1076#1103#1085
      TabOrder = 1
      OnClick = btnYenidenClick
    end
    object Button2: TButton
      Left = 606
      Top = 5
      Width = 81
      Height = 26
      Caption = #1041#1072#1100#1083#1072
      ModalResult = 2
      TabOrder = 2
    end
    object btnAll: TButton
      Left = 512
      Top = 5
      Width = 80
      Height = 26
      Caption = #1062#1084#1091#1084#1080
      TabOrder = 3
      OnClick = btnAllClick
    end
    object Button4: TButton
      Left = 150
      Top = 6
      Width = 75
      Height = 25
      Caption = 'Button3'
      TabOrder = 4
      Visible = False
      OnClick = Button3Click
    end
    object BitBtn1: TBitBtn
      Left = 239
      Top = 6
      Width = 75
      Height = 25
      Caption = 'BitBtn1'
      DoubleBuffered = True
      ParentDoubleBuffered = False
      TabOrder = 5
      Visible = False
      OnClick = BitBtn1Click
    end
  end
  object Panel6: TPanel
    Left = 0
    Top = 131
    Width = 690
    Height = 69
    Align = alTop
    BevelInner = bvRaised
    BevelOuter = bvLowered
    TabOrder = 5
    object GroupBox4: TGroupBox
      Left = 2
      Top = 2
      Width = 197
      Height = 65
      Align = alLeft
      Caption = #1065#1077#1089#1072#1073#1072#1090' '#1072#1088#1072#1083#1099#1100#1099
      TabOrder = 0
      DesignSize = (
        197
        65)
      object Label1: TLabel
        Left = 9
        Top = 17
        Width = 80
        Height = 13
        Caption = #1044#1102#1074#1088#1094#1085' '#1103#1074#1074#1103#1083#1080
      end
      object Label2: TLabel
        Left = 9
        Top = 41
        Width = 67
        Height = 13
        Caption = #1044#1102#1074#1088#1094#1085' '#1089#1086#1085#1091
      end
      object BDateP: TDateTimePicker
        Left = 89
        Top = 13
        Width = 102
        Height = 21
        Anchors = [akLeft, akTop, akRight]
        Date = 38477.593060798600000000
        Time = 38477.593060798600000000
        TabOrder = 0
      end
      object EDateP: TDateTimePicker
        Left = 89
        Top = 37
        Width = 102
        Height = 21
        Anchors = [akLeft, akTop, akRight]
        Date = 38477.593068935200000000
        Time = 38477.593068935200000000
        TabOrder = 1
      end
    end
    object GroupBox12: TGroupBox
      Left = 199
      Top = 2
      Width = 155
      Height = 65
      Align = alLeft
      Caption = #1042#1077#1088#1080#1083#1084#1080#1096' '#1082#1088#1077#1076#1080#1090#1083#1103#1088
      TabOrder = 1
      DesignSize = (
        155
        65)
      object Label3: TLabel
        Left = 112
        Top = 17
        Width = 23
        Height = 13
        Caption = '-'#1076#1072#1085
      end
      object Label4: TLabel
        Left = 112
        Top = 40
        Width = 23
        Height = 13
        Caption = '-'#1076#1103#1082
      end
      object GCredBegD: TDateTimePicker
        Left = 6
        Top = 13
        Width = 103
        Height = 21
        Anchors = [akLeft, akTop, akRight]
        Date = 35431.593060798600000000
        Time = 35431.593060798600000000
        TabOrder = 0
      end
      object GCredEndD: TDateTimePicker
        Left = 6
        Top = 37
        Width = 103
        Height = 21
        Anchors = [akLeft, akTop, akRight]
        Date = 38477.593068935200000000
        Time = 38477.593068935200000000
        TabOrder = 1
      end
    end
    object GroupBox14: TGroupBox
      Left = 354
      Top = 2
      Width = 155
      Height = 65
      Align = alLeft
      Caption = #1057#1090#1072#1090#1091#1089#1091
      TabOrder = 2
      DesignSize = (
        155
        65)
      object CheckBox12: TCheckBox
        Left = 5
        Top = 40
        Width = 105
        Height = 18
        Caption = #1058#1103#1090#1073#1080#1075' '#1077#1090
        TabOrder = 0
      end
      object DBLookupComboboxEh10: TDBLookupComboboxEh
        Left = 5
        Top = 15
        Width = 143
        Height = 21
        Anchors = [akLeft, akTop, akRight]
        DropDownBox.Sizable = True
        EditButtons = <>
        KeyField = 'ID'
        ListField = 'STATNAME'
        ListSource = DSStatuses
        TabOrder = 1
        Visible = True
      end
    end
    object GroupBox19: TGroupBox
      Left = 509
      Top = 2
      Width = 181
      Height = 65
      Align = alLeft
      Caption = #1058#1077#1093#1085#1080#1082#1072#1085#1099#1085' '#1090#1080#1087#1080
      TabOrder = 3
      DesignSize = (
        181
        65)
      object CheckBox17: TCheckBox
        Left = 5
        Top = 40
        Width = 105
        Height = 18
        Caption = #1058#1103#1090#1073#1080#1075' '#1077#1090
        TabOrder = 0
      end
      object DBLookupComboboxEh13: TDBLookupComboboxEh
        Left = 5
        Top = 15
        Width = 168
        Height = 21
        Anchors = [akLeft, akTop, akRight]
        DropDownBox.Sizable = True
        EditButtons = <>
        KeyField = 'ID'
        ListField = 'NAME'
        ListSource = DSGType
        TabOrder = 1
        Visible = True
      end
    end
  end
  object Panel7: TPanel
    Left = 0
    Top = 268
    Width = 690
    Height = 66
    Align = alTop
    BevelInner = bvRaised
    BevelOuter = bvLowered
    TabOrder = 6
    object GroupBox15: TGroupBox
      Left = 225
      Top = 2
      Width = 155
      Height = 62
      Align = alLeft
      Caption = #1060#1072#1080#1079' '#1075#1086#1081#1091#1083#1091#1096#1091
      TabOrder = 0
      object Label5: TLabel
        Left = 69
        Top = 17
        Width = 6
        Height = 19
        Caption = '-'
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -17
        Font.Name = 'Azl Sans Serif'
        Font.Style = []
        ParentFont = False
      end
      object CheckBox13: TCheckBox
        Left = 5
        Top = 41
        Width = 105
        Height = 18
        Caption = #1058#1103#1090#1073#1080#1075' '#1077#1090
        TabOrder = 0
      end
      object fsm: TCMCurrencyEdit
        Left = 5
        Top = 17
        Width = 56
        Height = 21
        TabOrder = 1
        Text = '0'
      end
      object fsx: TCMCurrencyEdit
        Left = 83
        Top = 17
        Width = 56
        Height = 21
        TabOrder = 2
        Text = '100'
        Value = 100.000000000000000000
      end
    end
    object GroupBox16: TGroupBox
      Left = 2
      Top = 2
      Width = 90
      Height = 62
      Align = alLeft
      Caption = #1052#1094#1076#1076#1103#1090#1080
      TabOrder = 1
      DesignSize = (
        90
        62)
      object CheckBox14: TCheckBox
        Left = 5
        Top = 41
        Width = 105
        Height = 18
        Caption = #1058#1103#1090#1073#1080#1075' '#1077#1090
        TabOrder = 0
      end
      object DBLookupComboboxEh12: TDBLookupComboboxEh
        Left = 5
        Top = 15
        Width = 77
        Height = 21
        Anchors = [akLeft, akTop, akRight]
        DropDownBox.Sizable = True
        EditButtons = <>
        KeyField = 'ID'
        ListField = 'IDNAME'
        ListSource = DSTypes
        TabOrder = 1
        Visible = True
      end
    end
    object GroupBox17: TGroupBox
      Left = 380
      Top = 2
      Width = 308
      Height = 62
      Align = alClient
      Caption = #1053#1103#1079#1103#1088#1076#1103' '#1090#1091#1090#1091#1083#1072#1085' '#1084#1103#1073#1083#1103#1100
      TabOrder = 2
      object Label6: TLabel
        Left = 138
        Top = 17
        Width = 6
        Height = 19
        Caption = '-'
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -17
        Font.Name = 'Azl Sans Serif'
        Font.Style = []
        ParentFont = False
      end
      object CheckBox15: TCheckBox
        Left = 5
        Top = 41
        Width = 105
        Height = 18
        Caption = #1058#1103#1090#1073#1080#1075' '#1077#1090
        TabOrder = 0
      end
      object ntmm: TCMCurrencyEdit
        Left = 5
        Top = 17
        Width = 125
        Height = 21
        TabOrder = 1
        Text = '0'
      end
      object ntmx: TCMCurrencyEdit
        Left = 152
        Top = 17
        Width = 151
        Height = 21
        TabOrder = 2
        Text = '1000000000'
        Value = 1000000000.000000000000000000
      end
    end
    object GroupBox18: TGroupBox
      Left = 92
      Top = 2
      Width = 133
      Height = 62
      Align = alLeft
      Caption = 'Q'#1103'rar'
      TabOrder = 3
      DesignSize = (
        133
        62)
      object CheckBox16: TCheckBox
        Left = 5
        Top = 41
        Width = 105
        Height = 18
        Caption = #1058#1103#1090#1073#1080#1075' '#1077#1090
        TabOrder = 0
      end
      object DBLookupComboboxEh11: TDBLookupComboboxEh
        Left = 5
        Top = 15
        Width = 121
        Height = 21
        Anchors = [akLeft, akTop, akRight]
        DropDownBox.Sizable = True
        EditButtons = <>
        KeyField = 'ID'
        ListField = 'SHORT'
        ListSource = DSShort
        TabOrder = 1
        Visible = True
      end
    end
  end
  object CreditsDS: TOracleDataSet
    SQL.Strings = (
      'select ID   from cm_portfolio'
      ''
      ''
      '')
    Optimize = False
    Cursor = crSQLWait
    Session = sboapiDataModule.SBSession
    Left = 576
    Top = 56
  end
  object CM_AK_REPORTS: TOraclePackage
    Session = sboapiDataModule.SBSession
    PackageName = 'CM_AK_REPORTS'
    ParameterMode = pmNamed
    Cursor = crHourGlass
    Left = 504
    Top = 48
  end
  object DSCurrencys: TDataSource
    DataSet = Currencys
    Left = 16
    Top = 56
  end
  object Currencys: TOracleDataSet
    SQL.Strings = (
      'SELECT valute,  valu_name'
      '  FROM AVALUTE'
      'ORDER BY VALUTE')
    Optimize = False
    Cursor = crSQLWait
    Session = sboapiDataModule.SBSession
    Left = 16
    Top = 24
  end
  object DSBranches: TDataSource
    DataSet = Branches
    Left = 56
    Top = 56
  end
  object Branches: TOracleDataSet
    SQL.Strings = (
      'SELECT id, name'
      '  FROM filial')
    Optimize = False
    Cursor = crSQLWait
    Session = sboapiDataModule.SBSession
    Left = 56
    Top = 24
  end
  object DSUserGroups: TDataSource
    DataSet = UserGroups
    Left = 176
    Top = 56
  end
  object UserGroups: TOracleDataSet
    SQL.Strings = (
      'SELECT id, description'
      '  FROM cm_usergroups')
    Optimize = False
    Cursor = crSQLWait
    Session = sboapiDataModule.SBSession
    Left = 176
    Top = 24
    object UserGroupsID: TFloatField
      FieldName = 'ID'
      Required = True
    end
    object UserGroupsDESCRIPTION: TWideStringField
      FieldName = 'DESCRIPTION'
      Size = 64
    end
  end
  object DSPersons: TDataSource
    DataSet = Persons
    Left = 96
    Top = 56
  end
  object Persons: TOracleDataSet
    SQL.Strings = (
      'SELECT id,  descripion'
      '  FROM cm_persons')
    Optimize = False
    Cursor = crSQLWait
    Session = sboapiDataModule.SBSession
    Left = 96
    Top = 24
  end
  object DSCategories: TDataSource
    DataSet = Categories
    Left = 136
    Top = 56
  end
  object Categories: TOracleDataSet
    SQL.Strings = (
      'SELECT id, description'
      '  FROM cm_categories')
    Optimize = False
    Cursor = crSQLWait
    Session = sboapiDataModule.SBSession
    Left = 136
    Top = 24
  end
  object Kera: TCMExcelExport
    ConnectTo = ctNewInstance
    StyleColumnWidth = cwAutoFit
    ColumnWidth = 0
    FontTitles.Charset = RUSSIAN_CHARSET
    FontTitles.Color = clNavy
    FontTitles.Height = -13
    FontTitles.Name = 'Tahoma'
    FontTitles.Style = [fsBold]
    BorderTitles.Weight = bwThin
    BorderTitles.LineStyle = blLine
    OrientationTitles = 0
    FontData.Charset = RUSSIAN_CHARSET
    FontData.Color = clWindowText
    FontData.Height = -11
    FontData.Name = 'Tahoma'
    FontData.Style = []
    FontSummary.Charset = RUSSIAN_CHARSET
    FontSummary.Color = clWindowText
    FontSummary.Height = -11
    FontSummary.Name = 'Tahoma'
    FontSummary.Style = []
    SummarySelection = ssNone
    SummaryCalculation = scSUM
    Left = 448
    Top = 8
  end
  object Customers: TOracleDataSet
    SQL.Strings = (
      'SELECT id, id||'#39'-'#39'||name idname'
      '  FROM customers'
      'order by id')
    Optimize = False
    Cursor = crSQLWait
    Session = sboapiDataModule.SBSession
    Left = 256
    Top = 24
  end
  object DSCustomers: TDataSource
    DataSet = Customers
    Left = 256
    Top = 56
  end
  object Districts: TOracleDataSet
    SQL.Strings = (
      'SELECT id, id ||'#39'-'#39'||name idname'
      '  FROM agro_region'
      'order by id')
    Optimize = False
    Cursor = crSQLWait
    Session = sboapiDataModule.SBSession
    Left = 216
    Top = 24
    object DistrictsID: TFloatField
      FieldName = 'ID'
      Required = True
    end
    object DistrictsIDNAME: TWideStringField
      FieldName = 'IDNAME'
      Size = 169
    end
  end
  object DSDistricts: TDataSource
    DataSet = Districts
    Left = 216
    Top = 56
  end
  object CustNames: TOracleDataSet
    SQL.Strings = (
      'SELECT id, name idname'
      
        '  FROM customers where id in(select boorowerid from cm_portfolio' +
        ')'
      'order by name')
    Optimize = False
    Cursor = crSQLWait
    Session = sboapiDataModule.SBSession
    Left = 296
    Top = 24
  end
  object DSCustName: TDataSource
    DataSet = CustNames
    Left = 296
    Top = 56
  end
  object RepForms: TOracleDataSet
    SQL.Strings = (
      'select * from cm_bc_reports order by id')
    Optimize = False
    Cursor = crSQLWait
    Session = sboapiDataModule.SBSession
    Left = 336
    Top = 24
  end
  object DSRepForms: TDataSource
    DataSet = RepForms
    Left = 336
    Top = 56
  end
  object Periods: TOracleDataSet
    SQL.Strings = (
      'SELECT *'
      '  FROM cm_bp_purposes')
    Optimize = False
    Cursor = crSQLWait
    Session = sboapiDataModule.SBSession
    Left = 16
    Top = 105
  end
  object Statuses: TOracleDataSet
    SQL.Strings = (
      'SELECT 0 ID, '#39'Hesablanmayan'#39' STATNAME'
      '  FROM dual'
      'union'
      'SELECT 1, '#39'Hesablanan'#39
      '  FROM dual')
    Optimize = False
    Cursor = crSQLWait
    Session = sboapiDataModule.SBSession
    Left = 55
    Top = 105
  end
  object DSPeriods: TDataSource
    DataSet = Periods
    Left = 16
    Top = 140
  end
  object DSStatuses: TDataSource
    DataSet = Statuses
    Left = 56
    Top = 140
  end
  object ODSMakeTemp: TOracleDataSet
    SQL.Strings = (
      'insert into agro_history'
      'select * from cm_history where hdate=:enddat'
      '/'
      'insert into agro_tranches'
      'select * from cm_tranches tranchedate=:enddat'
      '/'
      'insert into agro_payments'
      
        'select * from cm_payments where paydate between :begdat and :end' +
        'dat'
      ''
      '')
    Optimize = False
    Variables.Data = {
      04000000020000000E0000003A0045004E0044004400410054000C0000000000
      0000000000000E0000003A004200450047004400410054000C00000000000000
      00000000}
    Cursor = crSQLWait
    Session = sboapiDataModule.SBSession
    Left = 144
    Top = 372
  end
  object Types: TOracleDataSet
    SQL.Strings = (
      'SELECT id, id ||'#39'-'#39'||typedesc idname'
      '  FROM cm_bp_types'
      'order by id')
    Optimize = False
    Cursor = crSQLWait
    Session = sboapiDataModule.SBSession
    Left = 376
    Top = 24
    object FloatField1: TFloatField
      FieldName = 'ID'
      Required = True
    end
    object StringField1: TWideStringField
      FieldName = 'IDNAME'
      Size = 169
    end
  end
  object DSTypes: TDataSource
    DataSet = Types
    Left = 376
    Top = 56
  end
  object Short: TOracleDataSet
    SQL.Strings = (
      'SELECT s.id, p.purposedesc||'#39'-'#39'||shortname as short, description'
      '  FROM cm_bp_sources s, cm_bp_purposes p'
      '  where purpid=p.id'
      '  order by short')
    Optimize = False
    Session = sboapiDataModule.SBSession
    Left = 418
    Top = 26
    object ShortID: TFloatField
      FieldName = 'ID'
      Required = True
    end
    object ShortSHORT: TWideStringField
      FieldName = 'SHORT'
      Size = 49
    end
    object ShortDESCRIPTION: TWideStringField
      FieldName = 'DESCRIPTION'
      Required = True
      Size = 255
    end
  end
  object DSShort: TDataSource
    DataSet = Short
    Left = 418
    Top = 56
  end
  object GTypes: TOracleDataSet
    SQL.Strings = (
      'SELECT id, name'
      '  FROM cm_ak_type')
    Optimize = False
    Cursor = crSQLWait
    Session = sboapiDataModule.SBSession
    Left = 458
    Top = 32
    object GTypesID: TFloatField
      FieldName = 'ID'
      Required = True
    end
    object GTypesNAME: TWideStringField
      FieldName = 'NAME'
      Size = 50
    end
  end
  object DSGType: TDataSource
    DataSet = GTypes
    Left = 458
    Top = 56
  end
  object sysdat: TOracleDataSet
    SQL.Strings = (
      'select * from smart.sysdat')
    Optimize = False
    QBEDefinition.QBEFieldDefs = {
      05000000040000000E000000540045004B005F00440041005400010000000000
      1000000050005200450044005F004400410054000100000000000E0000004100
      520043005F004400410059000100000000000A00000043004C004F0053004500
      010000000000}
    Session = sboapiDataModule.SBSession
    Left = 72
    Top = 373
    object sysdatTEK_DAT: TDateTimeField
      FieldName = 'TEK_DAT'
      Required = True
    end
    object sysdatPRED_DAT: TDateTimeField
      FieldName = 'PRED_DAT'
    end
    object sysdatARC_DAY: TDateTimeField
      FieldName = 'ARC_DAY'
    end
    object sysdatCLOSE: TIntegerField
      FieldName = 'CLOSE'
    end
  end
  object ResultDS_: TOracleDataSet
    SQL.Strings = (
      'SELECT f.*'
      '     , cm_ak_funcs.getlmcount(f.creditid,4) pret'
      '     , cm_ak_funcs.getlmcount(f.creditid,6) idd'
      '     , cm_ak_funcs.getlmcount(f.creditid,7) qatn'
      '     , cm_ak_funcs.geticracount(f.creditid,7) icra'
      
        '    ,s.paymentdate,s.principal,s.interest,s.principal+s.interest' +
        ' as cem,'
      '  case when s.sex=1 then'
      ' '#39'Ki'#1096#1080#39'  '
      'when s.sex=0 then '#39'Qadin'#39
      
        ' end as sex,cm_rport.get_vid_sob(p.activities_type) as"'#1052#1094#1083#1082#1080#1081#1081#1103#1090 +
        ' '#1085#1102#1074#1094'",cm_rport.get_cred(p.creditact)as "'#1041#1086#1088#1078#1072#1083#1072#1085#1099#1085' '#1089#1077#1082#1090#1086#1088#1091'",'
      
        'cm_rport.get_actives(p.activities) as "'#1041#1086#1088#1078#1072#1083#1072#1085#1099#1085' '#1092#1103#1072#1083#1080#1081#1081#1103#1090'i",c.' +
        'description  as "'#1041#1086#1088#1078#1072#1083#1072#1085#1099#1085' '#1092#1103#1072#1083#1080#1081#1081#1103#1090' '#1085#1102#1074#1094'"'
      
        '  FROM cm_report_f1 f,cm_payment_schedule_portfel s,cm_active_cr' +
        'edits p,cm_categories c where f.CREDITID=s.CREDITID and p.CUSTOM' +
        'ERTYPE=c.id  and p.id=f.creditid'
      ''
      ''
      ''
      'ORDER BY'
      '  branch, district, village, boorowername'
      ''
      ''
      ''
      ''
      ''
      ''
      ''
      ''
      ''
      ''
      ''
      ''
      ''
      ''
      ''
      ''
      ''
      ''
      ''
      ''
      ''
      ''
      ''
      ''
      ''
      ''
      ''
      ''
      ''
      '/*SELECT f.*'
      '     , cm_ak_funcs.getlmcount(f.creditid,4) pret'
      '     , cm_ak_funcs.getlmcount(f.creditid,6) idd'
      '     , cm_ak_funcs.getlmcount(f.creditid,7) qatn'
      '     , cm_ak_funcs.geticracount(f.creditid,7) icra'
      
        '    ,s.paymentdate,s.principal,s.interest,s.principal+s.interest' +
        ' as cem,'
      '  case when s.sex=1 then'
      ' '#39'Ki'#1096#1080#39'  '
      'when s.sex=0 then '#39'Qadin'#39
      ' end as sex,cm_r'
      ''
      
        '  FROM cm_report_f1 f,cm_payment_schedule_portfel s,cm_active_cr' +
        'edits p,cm_categories c where f.CREDITID=s.CREDITID and p.CUSTOM' +
        'ERTYPE=c.id'
      ''
      ''
      ''
      'ORDER BY'
      '  branch, district, village, boorowername*/')
    Optimize = False
    QBEDefinition.QBEFieldDefs = {
      0500000048000000100000004300520045004400490054004900440001000000
      00001400000042004F004F0052004F0057004500520049004400010000000000
      0C0000004300520044004E0055004D000100000000001800000042004F004F00
      52004F005700450052004E0041004D0045000100000000001000000042005200
      41004E0043004800490044000100000000000C0000004200520041004E004300
      4800010000000000140000004400490053005400520049004300540049004400
      0100000000001000000044004900530054005200490043005400010000000000
      12000000560049004C004C00410047004500490044000100000000000E000000
      560049004C004C00410047004500010000000000120000005000550052005000
      4F0053004500490044000100000000000E00000050005500520050004F005300
      45000100000000000C0000005400590050004500490044000100000000001000
      0000540059005000450044004500530043000100000000001000000043005200
      440043004F0055004E0054000100000000001A00000050004100590045004400
      43005200440043004F0055004E0054000100000000001A000000460049005200
      5300540054005200430048004400410054004500010000000000160000004C00
      4100530054005000410059004400410054004500010000000000160000004700
      4900560045004E0041004D004F0055004E005400010000000000220000004300
      41004C00430055004C004100540045004400500045005200430045004E005400
      01000000000018000000440041005400450044004500420054004D0041004900
      4E00010000000000160000004400410054004500440045004200540049004E00
      540001000000000012000000500041005900450044004D00410049004E000100
      00000000100000005000410059004500440049004E0054000100000000001800
      0000500041005900450044004D004F004E004D00410049004E00010000000000
      16000000500041005900450044004D004F004E0049004E005400010000000000
      1000000044004500420054004D00410049004E000100000000000E0000004400
      45004200540049004E0054000100000000001800000044004500420054004F00
      5600450052004D00410049004E00010000000000160000004400450042005400
      4F0056004500520049004E00540001000000000014000000430041004C004300
      5300540041005400550053000100000000001400000043005200450044005000
      4500520049004F0044000100000000000E00000049004E005400520041005400
      45000100000000000C0000004F00440052004100540045000100000000000A00
      0000530042004F005500540001000000000016000000500052004F004C004F00
      4E004700440041005400450001000000000014000000500052004F004C004F00
      4E00470043004E0054000100000000002000000044005500450049004E005400
      4500520045005300540044004500420049005400010000000000080000005000
      5200450054000100000000000600000049004400440001000000000008000000
      5100410054004E00010000000000080000004900430052004100010000000000
      14000000440045005300430052004900500049004F004E000100000000001000
      0000530046004500520041004400410059000100000000001E00000050005500
      520050004F00530045004F004600430052004500440049005400010000000000
      10000000430055005200520045004E0043005900010000000000120000004C00
      4F0041004E00410043004300490044000100000000001A00000042004F004F00
      52004F00570045005200410043004300490044000100000000001E0000004200
      4F004F0052004F00570045005200410043004300520045005300540001000000
      00000E00000041004400440052004500530053000100000000000C0000005300
      41004C0041005200590001000000000016000000500048004F004E0045004E00
      55004D004200450052000100000000000E000000520045005300450052005600
      45000100000000000E0000004C00410054004500440041005900010000000000
      160000004400450053004300520049005000540049004F004E00010000000000
      120000004700490052004F005600520045005300540001000000000026000000
      5000520049004D00410052005900520045005300450052005600450041005200
      4500530054000100000000002C0000005000520049004D004100520059005000
      5500520052004500530045005200560045004100520045005300540001000000
      000014000000470045004300470055004E004600410049005A00010000000000
      1400000050004C0045004400470045004E0041004D0045000100000000001800
      00004F00440045004D0045005F0045004D00530041004C004900010000000000
      180000004500580050004500520054005F005F004E0041004D00450001000000
      00000A0000004B00550052005500530001000000000016000000500041005900
      4D0045004E005400440041005400450001000000000012000000500052004900
      4E0043004900500041004C000100000000001000000049004E00540045005200
      4500530054000100000000000600000053004500580001000000000006000000
      430045004D000100000000001C0000001C0446043B043A043804390439044F04
      420420003D044E04320446040100000000002400000011043E04400436043004
      3B0430043D044B043D042000410435043A0442043E0440044304010000000000
      2A00000011043E044004360430043B0430043D044B043D04200044044F043004
      3B043804390439044F04420469000100000000003200000011043E0440043604
      30043B0430043D044B043D04200044044F0430043B043804390439044F044204
      20003D044E0432044604010000000000}
    Cursor = crSQLWait
    Session = sboapiDataModule.SBSession
    Left = 408
    Top = 320
    object ResultDS_ODEME_EMSALI: TFloatField
      DisplayLabel = #1070#1076#1103#1084#1103' '#1103#1084#1089#1072#1083#1099
      FieldName = 'ODEME_EMSALI'
      DisplayFormat = '#,#0.00'
    end
    object ResultDS_CREDITID: TFloatField
      DisplayLabel = #1050#1088#1077#1076' '#1067#1044
      FieldName = 'CREDITID'
      Required = True
    end
    object ResultDS_BOOROWERID: TFloatField
      DisplayLabel = #1052#1094#1097' '#1067#1044
      FieldName = 'BOOROWERID'
      Required = True
    end
    object ResultDS_CRDNUM: TWideStringField
      DisplayLabel = #1052#1094#1075#1072#1074#1080#1083#1103
      FieldName = 'CRDNUM'
      Required = True
      Size = 255
    end
    object ResultDS_BOOROWERNAME: TWideStringField
      DisplayLabel = #1052#1094#1096#1090#1103#1088#1080
      FieldName = 'BOOROWERNAME'
      Required = True
      Size = 255
    end
    object ResultDS_DSDesigner: TWideStringField
      FieldName = #1052#1094#1083#1082#1080#1081#1081#1103#1090' '#1085#1102#1074#1094
      Size = 4000
    end
    object ResultDS_DSDesigner2: TWideStringField
      FieldName = #1041#1086#1088#1078#1072#1083#1072#1085#1099#1085' '#1089#1077#1082#1090#1086#1088#1091
      Size = 4000
    end
    object ResultDS_i: TWideStringField
      FieldName = #1041#1086#1088#1078#1072#1083#1072#1085#1099#1085' '#1092#1103#1072#1083#1080#1081#1081#1103#1090'i'
      Size = 4000
    end
    object ResultDS_DSDesigner3: TWideStringField
      FieldName = #1041#1086#1088#1078#1072#1083#1072#1085#1099#1085' '#1092#1103#1072#1083#1080#1081#1081#1103#1090' '#1085#1102#1074#1094
      Size = 128
    end
    object ResultDS_BRANCHID: TFloatField
      DisplayLabel = #1060#1080#1083' '#1067#1044
      FieldName = 'BRANCHID'
      Required = True
      Visible = False
    end
    object ResultDS_BRANCH: TWideStringField
      DisplayLabel = #1060#1080#1083#1080#1072#1083
      FieldName = 'BRANCH'
      Required = True
      Size = 255
    end
    object ResultDS_VILLAGEID: TFloatField
      DisplayLabel = #1050#1103#1085#1076' '#1067#1044
      FieldName = 'VILLAGEID'
      Required = True
      Visible = False
    end
    object ResultDS_DISTRICTID: TFloatField
      DisplayLabel = #1056#1072#1081#1086#1085' '#1067#1044
      FieldName = 'DISTRICTID'
      Required = True
      Visible = False
    end
    object ResultDS_VILLAGE: TWideStringField
      DisplayLabel = #1050#1103#1085#1076
      FieldName = 'VILLAGE'
      Required = True
      Size = 255
    end
    object ResultDS_DISTRICT: TWideStringField
      DisplayLabel = #1056#1072#1081#1086#1085
      FieldName = 'DISTRICT'
      Required = True
      Size = 255
    end
    object ResultDS_CREDPERIOD: TWideStringField
      DisplayLabel = #1042#1103#1089#1072#1080#1090#1080#1085' '#1084#1103#1085#1073#1103#1081#1080
      FieldName = 'CREDPERIOD'
      Required = True
    end
    object ResultDS_DESCRIPION: TWideStringField
      DisplayLabel = #1052#1094#1096#1090#1103#1088#1080#1085#1080#1085' '#1089#1090#1072#1090#1091#1089#1091
      FieldName = 'DESCRIPION'
      Size = 30
    end
    object ResultDS_SEX: TWideStringField
      DisplayLabel = #1041#1086#1088#1078#1072#1083#1072#1085#1099#1085' '#1078#1080#1085#1080#1089#1080
      FieldName = 'SEX'
      Size = 12
    end
    object ResultDS_PURPOSE: TWideStringField
      DisplayLabel = #1050#1088#1077#1076#1080#1090' '#1084#1103#1097#1089#1091#1083#1091#1085#1091#1085' '#1072#1076#1099
      FieldName = 'PURPOSE'
      Required = True
      Size = 255
    end
    object ResultDS_SFERADAY: TWideStringField
      DisplayLabel = #1052#1094#1096#1090#1103#1088#1080#1085#1080#1085' '#1092#1103#1072#1083#1080#1081#1081#1072#1090' '#1089#1072#1097#1103#1089#1080
      FieldName = 'SFERADAY'
      Size = 30
    end
    object ResultDS_PURPOSEOFCREDIT: TWideStringField
      DisplayLabel = #1050#1088#1077#1076#1080#1090#1080#1085' '#1090#1103#1081#1080#1085#1072#1090#1099
      FieldName = 'PURPOSEOFCREDIT'
      Size = 50
    end
    object ResultDS_PURPOSEID: TFloatField
      DisplayLabel = #1052#1103#1075#1089#1103#1076' '#1067#1044
      FieldName = 'PURPOSEID'
      Required = True
      Visible = False
    end
    object ResultDS_TYPEID: TFloatField
      DisplayLabel = #1058#1080#1087' '#1067#1044
      FieldName = 'TYPEID'
      Required = True
      Visible = False
    end
    object ResultDS_TYPEDESC: TWideStringField
      DisplayLabel = #1058#1080#1087
      FieldName = 'TYPEDESC'
      Required = True
      Size = 10
    end
    object ResultDS_CRDCOUNT: TFloatField
      DisplayLabel = #1050#1088#1077#1076' '#1057#1072#1081
      FieldName = 'CRDCOUNT'
      Required = True
      Visible = False
    end
    object ResultDS_PAYEDCRDCOUNT: TFloatField
      DisplayLabel = #1070#1076#1103#1085#1080#1083#1080#1073
      FieldName = 'PAYEDCRDCOUNT'
      Required = True
      Visible = False
    end
    object ResultDS_FIRSTTRCHDATE: TDateTimeField
      DisplayLabel = #1048#1083#1082' '#1090#1088#1072#1085#1096
      FieldName = 'FIRSTTRCHDATE'
      Required = True
    end
    object ResultDS_LASTPAYDATE: TDateTimeField
      DisplayLabel = #1057#1086#1085' '#1102#1076#1103#1084#1103
      FieldName = 'LASTPAYDATE'
      Required = True
    end
    object ResultDS_PROLONGDATE: TDateTimeField
      DisplayLabel = #1055#1088#1086#1083#1086#1085#1075#1087#1089#1080#1081#1103' '#1090#1072#1088#1080#1093#1080
      FieldName = 'PROLONGDATE'
    end
    object ResultDS_PROLONGCNT: TFloatField
      DisplayLabel = #1055#1088#1086#1083#1086#1085#1075#1087#1089#1080#1081#1103' '#1084#1094#1076#1076#1103#1090#1080
      FieldName = 'PROLONGCNT'
    end
    object ResultDS_CURRENCY: TWideStringField
      DisplayLabel = #1042#1072#1083#1081#1091#1090#1072
      FieldName = 'CURRENCY'
      Size = 65
    end
    object ResultDS_KURUS: TFloatField
      DisplayLabel = #1041#1091' '#1101#1094#1085#1103' '#1082#1091#1088#1089
      FieldName = 'KURUS'
    end
    object ResultDS_INTRATE: TFloatField
      DisplayLabel = #1092#1072#1080#1079'. stavkas'#1099
      FieldName = 'INTRATE'
      DisplayFormat = '#,#0.0'
    end
    object ResultDS_ODRATE: TFloatField
      DisplayLabel = 'gec '#1092#1072#1080#1079'. stavkas'#1099
      FieldName = 'ODRATE'
      DisplayFormat = '#,#0.0'
    end
    object ResultDS_GIVENAMOUNT: TFloatField
      DisplayLabel = #1042#1077#1088#1080#1083#1084#1080#1096' kr'
      FieldName = 'GIVENAMOUNT'
      Required = True
      DisplayFormat = '#,#0.0 '
    end
    object ResultDS_DATEDEBTMAIN: TFloatField
      DisplayLabel = #1042#1072#1093#1090#1099' '#1095#1072#1090'.'
      FieldName = 'DATEDEBTMAIN'
      Required = True
      DisplayFormat = '#,#0.0'
    end
    object ResultDS_PAYEDMAIN: TFloatField
      DisplayLabel = #1070#1076#1103#1085'. '#1103#1089#1072#1089
      FieldName = 'PAYEDMAIN'
      Required = True
      DisplayFormat = '#,#0.0'
    end
    object ResultDS_PAYEDMONMAIN: TFloatField
      DisplayLabel = #1046#1072#1088#1080' '#1072#1081#1076#1072' '#1102#1076#1103#1085#1103#1085' '#1103#1089#1072#1089
      FieldName = 'PAYEDMONMAIN'
      Required = True
      DisplayFormat = '#,#0.0'
    end
    object ResultDS_DEBTMAIN: TFloatField
      DisplayLabel = #1043#1072#1083#1099#1075' kredit borc'
      FieldName = 'DEBTMAIN'
      Required = True
      DisplayFormat = '#,#0.0'
    end
    object ResultDS_DEBTOVERMAIN: TFloatField
      DisplayLabel = #1069#1089#1072#1089' '#1073#1086#1088#1089' '#1094#1079#1088#1103' '#1101#1077#1080#1082#1084#1103' '#1084#1103#1073
      FieldName = 'DEBTOVERMAIN'
      Required = True
      DisplayFormat = '#,#0.0'
    end
    object ResultDS_LATEDAY: TFloatField
      DisplayLabel = #1071'.'#1041' '#1101#1077#1078' '#1101#1094#1085#1083#1103#1088#1080#1085' '#1089#1072#1081#1099
      FieldName = 'LATEDAY'
    end
    object ResultDS_CALCULATEDPERCENT: TFloatField
      DisplayLabel = #1065#1077#1089' '#1092#1072#1080#1079
      FieldName = 'CALCULATEDPERCENT'
      Required = True
      DisplayFormat = '#,#0.0'
    end
    object ResultDS_DATEDEBTINT: TFloatField
      DisplayLabel = #1042#1072#1093#1090#1099' '#1095#1072#1090'. %; '#1073#1086#1088#1078#1091'.'
      FieldName = 'DATEDEBTINT'
      Required = True
      DisplayFormat = '#,#0.0'
    end
    object ResultDS_PAYEDINT: TFloatField
      DisplayLabel = #1070#1076#1103#1085#1080#1083#1084#1080#1096'. % '#1073#1086#1088
      FieldName = 'PAYEDINT'
      Required = True
      DisplayFormat = '#,#0.0'
    end
    object ResultDS_PAYEDMONINT: TFloatField
      DisplayLabel = #1046#1072#1088#1080' '#1072#1081#1076#1072' '#1102#1076#1103#1085#1103#1085' '#1092#1072#1080#1079
      FieldName = 'PAYEDMONINT'
      Required = True
      DisplayFormat = '#,#0.0'
    end
    object ResultDS_DEBTINT: TFloatField
      DisplayLabel = #1060#1072#1080#1079' '#1075#1072#1083#1099#1100#1099
      FieldName = 'DEBTINT'
      Required = True
      DisplayFormat = '#,#0.0'
    end
    object ResultDS_DEBTOVERINT: TFloatField
      DisplayLabel = #1060#1072#1080#1079' '#1073#1086#1088#1078#1091' '#1094#1079#1088#1103'  '#1101#1077#1078#1080#1082#1084#1103' '#1084#1103#1073
      FieldName = 'DEBTOVERINT'
      Required = True
      DisplayFormat = '#,#0.0'
    end
    object ResultDS_GECGUNFAIZ: TFloatField
      DisplayLabel = #1060'.'#1041' '#1101#1077#1078' '#1101#1094#1085#1083#1103#1088#1080#1085' '#1089#1072#1081#1099
      FieldName = 'GECGUNFAIZ'
    end
    object ResultDS_LOANACCID: TWideStringField
      DisplayLabel = #1057#1089#1091#1076#1072' '#1097#1077#1089#1072#1073#1099
      FieldName = 'LOANACCID'
      Size = 30
    end
    object ResultDS_BOOROWERACCID: TWideStringField
      DisplayLabel = #1046#1072#1088#1080' '#1097#1077#1089#1072#1073
      FieldName = 'BOOROWERACCID'
      Size = 30
    end
    object ResultDS_BOOROWERACCREST: TFloatField
      DisplayLabel = #1046#1072#1088#1080' '#1097#1077#1089#1072#1073' '#1075#1072#1083#1099#1100#1099
      FieldName = 'BOOROWERACCREST'
      DisplayFormat = '#,#0.0 '
    end
    object ResultDS_ADDRESS: TWideStringField
      DisplayLabel = #1049#1072#1096#1072#1081#1099#1096' '#1081#1077#1088#1080
      FieldName = 'ADDRESS'
      Size = 60
    end
    object ResultDS_PHONENUMBER: TWideStringField
      DisplayLabel = #1058#1077#1083#1077#1092#1086#1085#1091
      FieldName = 'PHONENUMBER'
      Size = 350
    end
    object ResultDS_SALARY: TWideStringField
      DisplayLabel = #1060#1103#1072#1083#1080#1081#1081#1103#1090' '#1081#1077#1088#1080
      FieldName = 'SALARY'
      Size = 50
    end
    object ResultDS_DESCRIPTION: TWideStringField
      DisplayLabel = #1069#1080#1088#1086#1074#1091#1085' '#1085#1102#1074#1094
      FieldName = 'DESCRIPTION'
      Size = 45
    end
    object ResultDS_GIROVREST: TFloatField
      DisplayLabel = #1069#1080#1088#1086#1074#1091#1085' '#1076#1103#1081#1103#1088#1080
      FieldName = 'GIROVREST'
      DisplayFormat = '#,#0.0 '
    end
    object ResultDS_DUEBYSCHEME: TFloatField
      FieldKind = fkCalculated
      FieldName = 'DUEBYSCHEME'
      Visible = False
      Calculated = True
    end
    object ResultDS_CALCSTATUS: TWideStringField
      DisplayLabel = '% '#1097#1077#1089#1072#1073#1083#1072#1084#1072#1089#1099' '#1089#1090#1072#1090#1091#1089#1091
      FieldName = 'CALCSTATUS'
      Required = True
      Size = 12
    end
    object ResultDS_RESERVE: TWideStringField
      DisplayLabel = #1045#1097#1090#1080#1081#1081#1072#1090' '#1076#1103#1088#1103#1078#1103#1089#1080
      FieldName = 'RESERVE'
      Size = 18
    end
    object ResultDS_PRIMARYRESERVEAREST: TFloatField
      DisplayLabel = #1040#1076#1080' '#1077#1097#1090#1080#1081#1081#1072#1090' '#1097#1077#1089' '#1075#1072#1083#1099#1075
      FieldName = 'PRIMARYRESERVEAREST'
      DisplayFormat = '#,#0.0 '
    end
    object ResultDS_PRIMARYPURRESERVEAREST: TFloatField
      DisplayLabel = #1052#1103#1075#1089#1103#1076#1083#1080' '#1077#1097#1090#1080#1081#1081#1072#1090' '#1097#1077#1089' '#1075#1072#1083#1099#1075
      FieldName = 'PRIMARYPURRESERVEAREST'
      DisplayFormat = '#,#0.0 '
    end
    object ResultDS_PRET: TFloatField
      FieldName = 'PRET'
    end
    object ResultDS_IDD: TFloatField
      FieldName = 'IDD'
    end
    object ResultDS_QATN: TFloatField
      FieldName = 'QATN'
    end
    object ResultDS_ICRA: TFloatField
      FieldName = 'ICRA'
    end
    object ResultDS_EXPERT__NAME: TWideStringField
      DisplayLabel = #1050#1088#1077#1076#1080#1090#1080' '#1078#1103#1083#1073' '#1077#1076#1103#1085' '#1052' '#1072#1076#1099
      FieldName = 'EXPERT__NAME'
      Size = 25
    end
    object ResultDS_PAYMENTDATE: TDateTimeField
      DisplayLabel = 'Cari ayda '#1102#1076#1103#1085#1080#1096' '#1090#1072#1088#1080#1093#1080
      FieldName = 'PAYMENTDATE'
    end
    object ResultDS_PRINCIPAL: TFloatField
      DisplayLabel = 'Cari ayda '#1103#1089#1072#1089#1076#1072#1085' '#1102#1076#1103#1085#1080#1096
      FieldName = 'PRINCIPAL'
    end
    object ResultDS_INTEREST: TFloatField
      DisplayLabel = 'Cari ayda  % '#1076#1103#1085' '#1102#1076#1103#1085#1080#1096
      FieldName = 'INTEREST'
    end
    object ResultDS_CEM: TFloatField
      DisplayLabel = #1046#1103#1084#1080' '#1102#1076#1103#1085#1080#1096
      FieldName = 'CEM'
    end
  end
  object XLSExportFile1: TXLSExportFile
    Left = 136
    Top = 224
  end
  object XLSExportDataSource1: TXLSExportDataSource
    XLSExportFile = XLSExportFile1
    DataSource = DMBC.DS
    Options = []
    Left = 216
    Top = 224
  end
  object SaveDialog: TSaveDialog
    DefaultExt = 'xls'
    Filter = 'Excel File|*.xls;'
    InitialDir = 'GetCurrentDir'
    Title = 'Save an Excel File'
    Left = 312
    Top = 240
  end
end
