unit AKProgressFormImpl;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls, ComCtrls;

type
  TAKProgressForm = class(TForm)
    ProgressShower: TProgressBar;
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  AKProgressForm: TAKProgressForm;

implementation

{$R *.DFM}

end.
