object FrmCreditProperties: TFrmCreditProperties
  Left = 307
  Top = 220
  BorderIcons = [biSystemMenu]
  ClientHeight = 415
  ClientWidth = 517
  Color = clBtnFace
  Font.Charset = RUSSIAN_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Azl Sans Serif'
  Font.Style = []
  KeyPreview = True
  OldCreateOrder = False
  Position = poScreenCenter
  OnCanResize = FormCanResize
  OnCreate = FormCreate
  OnKeyPress = FormKeyPress
  OnShow = FormShow
  PixelsPerInch = 96
  TextHeight = 14
  object PCCreditProperties: TPageControl
    Left = 0
    Top = 0
    Width = 517
    Height = 375
    ActivePage = TabSheet1
    Align = alTop
    TabOrder = 0
    object TabSheet1: TTabSheet
      Caption = #1070#1076#1103#1085#1080#1096#1083#1103#1088
      object DBGridEh1: TDBGridEh
        Left = 0
        Top = 0
        Width = 509
        Height = 346
        Align = alClient
        DataSource = DatModAex.DatSrcPayments
        Flat = True
        FooterColor = clWindow
        FooterFont.Charset = RUSSIAN_CHARSET
        FooterFont.Color = clWindowText
        FooterFont.Height = -11
        FooterFont.Name = 'Azl Sans Serif'
        FooterFont.Style = []
        Options = [dgTitles, dgIndicator, dgColumnResize, dgColLines, dgRowLines, dgTabs, dgRowSelect, dgConfirmDelete, dgCancelOnExit]
        TabOrder = 0
        TitleFont.Charset = RUSSIAN_CHARSET
        TitleFont.Color = clWindowText
        TitleFont.Height = -11
        TitleFont.Name = 'Azl Sans Serif'
        TitleFont.Style = []
        VertScrollBar.VisibleMode = sbNeverShowEh
        Columns = <
          item
            EditButtons = <>
            FieldName = 'PAYDATE'
            Footers = <>
            Title.Color = clNavy
            Title.Font.Charset = RUSSIAN_CHARSET
            Title.Font.Color = clWhite
            Title.Font.Height = -12
            Title.Font.Name = 'Azl Sans Serif'
            Title.Font.Style = []
            Width = 69
          end
          item
            EditButtons = <>
            FieldName = 'PAYEDAMT'
            Footers = <>
            Title.Color = clNavy
            Title.Font.Charset = RUSSIAN_CHARSET
            Title.Font.Color = clWhite
            Title.Font.Height = -12
            Title.Font.Name = 'Azl Sans Serif'
            Title.Font.Style = []
            Width = 118
          end
          item
            EditButtons = <>
            FieldName = 'PAYEDINTAMT'
            Footers = <>
            Title.Color = clNavy
            Title.Font.Charset = RUSSIAN_CHARSET
            Title.Font.Color = clWhite
            Title.Font.Height = -12
            Title.Font.Name = 'Azl Sans Serif'
            Title.Font.Style = []
            Width = 116
          end
          item
            EditButtons = <>
            FieldName = 'PAYEDDUEAMT'
            Footers = <>
            Title.Caption = #1069#1077#1078' . '#1071#1089#1072#1089' '#1073#1086#1088#1078#1076#1072#1085' '
            Title.Color = clNavy
            Title.Font.Charset = RUSSIAN_CHARSET
            Title.Font.Color = clWhite
            Title.Font.Height = -12
            Title.Font.Name = 'Azl Sans Serif'
            Title.Font.Style = []
            Width = 113
          end
          item
            EditButtons = <>
            FieldName = 'PAYEDDUEINTAMT'
            Footers = <>
            Title.Caption = #1069#1077#1078' .'#1060#1072#1080#1079' '#1094#1079#1088#1103' '#1073#1086#1088#1078#1076#1072#1085' '
            Title.Color = clNavy
            Title.Font.Charset = RUSSIAN_CHARSET
            Title.Font.Color = clWhite
            Title.Font.Height = -12
            Title.Font.Name = 'Azl Sans Serif'
            Title.Font.Style = []
            Width = 125
          end
          item
            EditButtons = <>
            FieldName = 'PAYEDPENALTYAMT'
            Footers = <>
            Title.Color = clNavy
            Title.Font.Charset = RUSSIAN_CHARSET
            Title.Font.Color = clWhite
            Title.Font.Height = -12
            Title.Font.Name = 'Azl Sans Serif'
            Title.Font.Style = []
            Width = 104
          end>
      end
    end
    object TabSheet2: TTabSheet
      Caption = #1070#1076#1103#1084#1103' '#1075#1088#1072#1092#1080#1082#1080
      ImageIndex = 1
      ExplicitLeft = 0
      ExplicitTop = 0
      ExplicitWidth = 0
      ExplicitHeight = 0
      object DBGridEh2: TDBGridEh
        Left = 0
        Top = 0
        Width = 508
        Height = 345
        Align = alClient
        DataSource = DatModAex.DatSrcSchedule
        Flat = True
        FooterColor = clWindow
        FooterFont.Charset = RUSSIAN_CHARSET
        FooterFont.Color = clWindowText
        FooterFont.Height = -11
        FooterFont.Name = 'Azl Sans Serif'
        FooterFont.Style = []
        Options = [dgTitles, dgIndicator, dgColumnResize, dgColLines, dgRowLines, dgTabs, dgRowSelect, dgConfirmDelete, dgCancelOnExit]
        TabOrder = 0
        TitleFont.Charset = RUSSIAN_CHARSET
        TitleFont.Color = clWindowText
        TitleFont.Height = -11
        TitleFont.Name = 'Azl Sans Serif'
        TitleFont.Style = []
        VertScrollBar.VisibleMode = sbNeverShowEh
        Columns = <
          item
            EditButtons = <>
            FieldName = 'PAYMENTDATE'
            Footers = <>
            Title.Color = clNavy
            Title.Font.Charset = RUSSIAN_CHARSET
            Title.Font.Color = clWhite
            Title.Font.Height = -12
            Title.Font.Name = 'Azl Sans Serif'
            Title.Font.Style = []
            Width = 69
          end
          item
            EditButtons = <>
            FieldName = 'PRINCIPAL'
            Footers = <>
            Title.Color = clNavy
            Title.Font.Charset = RUSSIAN_CHARSET
            Title.Font.Color = clWhite
            Title.Font.Height = -12
            Title.Font.Name = 'Azl Sans Serif'
            Title.Font.Style = []
            Width = 116
          end
          item
            EditButtons = <>
            FieldName = 'INTEREST'
            Footers = <>
            Title.Color = clNavy
            Title.Font.Charset = RUSSIAN_CHARSET
            Title.Font.Color = clWhite
            Title.Font.Height = -12
            Title.Font.Name = 'Azl Sans Serif'
            Title.Font.Style = []
            Width = 148
          end>
      end
    end
    object TabSheet3: TTabSheet
      Caption = #1058#1088#1072#1085#1096#1083#1072#1088
      ImageIndex = 2
      ExplicitLeft = 0
      ExplicitTop = 0
      ExplicitWidth = 0
      ExplicitHeight = 0
      object DBGridEh3: TDBGridEh
        Left = 0
        Top = 0
        Width = 508
        Height = 345
        Align = alClient
        DataSource = DatModAex.DatSrcTranches
        Flat = True
        FooterColor = clWindow
        FooterFont.Charset = RUSSIAN_CHARSET
        FooterFont.Color = clWindowText
        FooterFont.Height = -11
        FooterFont.Name = 'Azl Sans Serif'
        FooterFont.Style = []
        Options = [dgTitles, dgIndicator, dgColumnResize, dgColLines, dgRowLines, dgTabs, dgRowSelect, dgConfirmDelete, dgCancelOnExit]
        TabOrder = 0
        TitleFont.Charset = RUSSIAN_CHARSET
        TitleFont.Color = clWindowText
        TitleFont.Height = -11
        TitleFont.Name = 'Azl Sans Serif'
        TitleFont.Style = []
        VertScrollBar.VisibleMode = sbNeverShowEh
        Columns = <
          item
            EditButtons = <>
            FieldName = 'TRANCHEDATE'
            Footers = <>
            Title.Color = clNavy
            Title.Font.Charset = RUSSIAN_CHARSET
            Title.Font.Color = clWhite
            Title.Font.Height = -12
            Title.Font.Name = 'Azl Sans Serif'
            Title.Font.Style = []
            Width = 69
          end
          item
            EditButtons = <>
            FieldName = 'TRANCHEAMOUNT'
            Footers = <>
            Title.Color = clNavy
            Title.Font.Charset = RUSSIAN_CHARSET
            Title.Font.Color = clWhite
            Title.Font.Height = -12
            Title.Font.Name = 'Azl Sans Serif'
            Title.Font.Style = []
            Width = 182
          end>
      end
    end
    object TabSheet4: TTabSheet
      Caption = #1065#1077#1089#1072#1073#1083#1072#1085#1084#1099#1096' '#1092#1072#1080#1079#1083#1103#1088
      ImageIndex = 3
      ExplicitLeft = 0
      ExplicitTop = 0
      ExplicitWidth = 0
      ExplicitHeight = 0
      object DBGridEh4: TDBGridEh
        Left = 0
        Top = 0
        Width = 508
        Height = 345
        Align = alClient
        DataSource = DatModAex.DatSrcInterests
        Flat = True
        FooterColor = clWindow
        FooterFont.Charset = RUSSIAN_CHARSET
        FooterFont.Color = clWindowText
        FooterFont.Height = -11
        FooterFont.Name = 'Azl Sans Serif'
        FooterFont.Style = []
        Options = [dgTitles, dgIndicator, dgColumnResize, dgColLines, dgRowLines, dgTabs, dgRowSelect, dgConfirmDelete, dgCancelOnExit]
        TabOrder = 0
        TitleFont.Charset = RUSSIAN_CHARSET
        TitleFont.Color = clWindowText
        TitleFont.Height = -11
        TitleFont.Name = 'Azl Sans Serif'
        TitleFont.Style = []
        VertScrollBar.VisibleMode = sbNeverShowEh
        Columns = <
          item
            EditButtons = <>
            FieldName = 'HDATE'
            Footers = <>
            Title.Color = clNavy
            Title.Font.Charset = RUSSIAN_CHARSET
            Title.Font.Color = clWhite
            Title.Font.Height = -12
            Title.Font.Name = 'Azl Sans Serif'
            Title.Font.Style = []
            Width = 69
          end
          item
            EditButtons = <>
            FieldName = 'INTEREST'
            Footers = <>
            Title.Color = clNavy
            Title.Font.Charset = RUSSIAN_CHARSET
            Title.Font.Color = clWhite
            Title.Font.Height = -12
            Title.Font.Name = 'Azl Sans Serif'
            Title.Font.Style = []
            Width = 72
          end
          item
            EditButtons = <>
            FieldName = 'DUEINTEREST'
            Footers = <>
            Title.Color = clNavy
            Title.Font.Charset = RUSSIAN_CHARSET
            Title.Font.Color = clWhite
            Title.Font.Height = -12
            Title.Font.Name = 'Azl Sans Serif'
            Title.Font.Style = []
            Width = 119
          end
          item
            EditButtons = <>
            FieldName = 'PENALTYINTEREST'
            Footers = <>
            Title.Color = clNavy
            Title.Font.Charset = RUSSIAN_CHARSET
            Title.Font.Color = clWhite
            Title.Font.Height = -12
            Title.Font.Name = 'Azl Sans Serif'
            Title.Font.Style = []
            Width = 135
          end>
      end
    end
  end
  object BitBtn1: TBitBtn
    Left = 414
    Top = 381
    Width = 80
    Height = 27
    Caption = #1041#1072#1100#1083#1072
    DoubleBuffered = True
    Kind = bkClose
    NumGlyphs = 2
    ParentDoubleBuffered = False
    TabOrder = 1
  end
end
