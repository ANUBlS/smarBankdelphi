﻿unit TesFrmImpl;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, DBGridEh, StdCtrls, Buttons, DBCtrlsEh, DBLookupEh, Mask, DBCtrls;

type
  TAddTesFrm = class(TForm)
    Label1: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    DBEdit1: TDBEdit;
    DBLookupComboboxEh19: TDBLookupComboboxEh;
    DBLookupComboboxEh1: TDBLookupComboboxEh;
    BitBtn1: TBitBtn;
    BitBtn2: TBitBtn;
    procedure FormCanResize(Sender: TObject; var NewWidth, NewHeight: Integer;
      var Resize: Boolean);
    procedure cxButton2Click(Sender: TObject);
    procedure BitBtn1Click(Sender: TObject);
    procedure BitBtn2Click(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure DBLookupComboboxEh19Change(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  AddTesFrm: TAddTesFrm;

implementation

{$R *.dfm}
  uses ResSettingImpl ;
procedure TAddTesFrm.BitBtn1Click(Sender: TObject);
begin
if DBEdit1.Text='' then
 begin
   ShowMessage('Ad sahəsi boşdur!');
   exit ;
 end;

  if DBLookupComboboxEh1.Text='' then
 begin
   ShowMessage('Ehtiyyatlar üzrə əməliyyatlar sahəsi boşdur!');
   exit ;
 end;
 FrmResSetting.OracleDataSet1.Post;
  close;
end;

procedure TAddTesFrm.BitBtn2Click(Sender: TObject);
begin

AddTesFrm.close;
end;

procedure TAddTesFrm.cxButton2Click(Sender: TObject);
begin
close;
end;

procedure TAddTesFrm.DBLookupComboboxEh19Change(Sender: TObject);
begin
AddTesFrm.DBLookupComboboxEh1.KeyValue:=FrmResSetting.OracleDataSet1.FieldByName('reserveoperation').AsInteger;
end;

procedure TAddTesFrm.FormCanResize(Sender: TObject; var NewWidth,
  NewHeight: Integer; var Resize: Boolean);
begin
resize:=false;
end;

procedure TAddTesFrm.FormClose(Sender: TObject; var Action: TCloseAction);
begin
FrmResSetting.OracleDataSet1.Close;
FrmResSetting.OracleDataSet1.open;
end;

end.
