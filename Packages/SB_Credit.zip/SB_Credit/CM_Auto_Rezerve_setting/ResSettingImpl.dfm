object FrmResSetting: TFrmResSetting
  Left = 0
  Top = 0
  AutoSize = True
  ClientHeight = 704
  ClientWidth = 490
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  Position = poOwnerFormCenter
  OnCreate = FormCreate
  OnDestroy = FormDestroy
  OnShow = FormShow
  PixelsPerInch = 96
  TextHeight = 13
  object GroupBox1: TGroupBox
    Left = 0
    Top = 0
    Width = 490
    Height = 191
    Align = alTop
    Caption = 'Kreditin t'#601'snifat'#305
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = [fsBold]
    ParentFont = False
    TabOrder = 0
    object Panel2: TPanel
      Left = 2
      Top = 158
      Width = 486
      Height = 31
      Align = alBottom
      BevelOuter = bvLowered
      TabOrder = 0
      object SpeedButton1: TSpeedButton
        Left = 297
        Top = 2
        Width = 80
        Height = 28
        Cursor = crHandPoint
        Caption = #399'lav'#601' et    '
        Flat = True
        Glyph.Data = {
          9E050000424D9E05000000000000360400002800000012000000120000000100
          0800000000006801000000000000000000000001000000000000000000000000
          80000080000000808000800000008000800080800000C0C0C000C0DCC000F0CA
          A600000000000000000000000000000000000000000000000000000000000000
          0000000000000000000000000000000000000000000000000000000000000000
          0000000000000000000000000000000000000000000000000000000000000000
          0000000000000000000000000000000000000000000000000000000000000000
          0000000000000000000000000000000000000000000000000000000000000000
          0000000000000000000000000000000000000000000000000000000000000000
          0000000000000000000000000000000000000000000000000000000000000000
          0000000000000000000000000000000000000000000000000000000000000000
          0000000000000000000000000000000000000000000000000000000000000000
          0000000000000000000000000000000000000000000000000000000000000000
          0000000000000000000000000000000000000000000000000000000000000000
          0000000000000000000000000000000000000000000000000000000000000000
          0000000000000000000000000000000000000000000000000000000000000000
          0000000000000000000000000000000000000000000000000000000000000000
          0000000000000000000000000000000000000000000000000000000000000000
          0000000000000000000000000000000000000000000000000000000000000000
          0000000000000000000000000000000000000000000000000000000000000000
          0000000000000000000000000000000000000000000000000000000000000000
          0000000000000000000000000000000000000000000000000000000000000000
          0000000000000000000000000000000000000000000000000000000000000000
          0000000000000000000000000000000000000000000000000000000000000000
          0000000000000000000000000000000000000000000000000000000000000000
          0000000000000000000000000000000000000000000000000000000000000000
          0000000000000000000000000000000000000000000000000000000000000000
          0000000000000000000000000000000000000000000000000000000000000000
          0000000000000000000000000000000000000000000000000000000000000000
          0000000000000000000000000000000000000000000000000000000000000000
          0000000000000000000000000000000000000000000000000000000000000000
          0000000000000000000000000000000000000000000000000000000000000000
          000000000000000000000000000000000000F0FBFF00A4A0A000808080000000
          FF0000FF000000FFFF00FF000000FF00FF00FFFF0000FFFFFF00FFFFFFFFFFFF
          FFFFFFFFFFFFFFFFFFFFFFFF0000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF
          0000FFFF040404040404040404040404FFFFFFFF0000FFFF04F8F8F8F8F8F8F8
          F8F8F804FFFFFFFF0000FFFF040707070707070707000704FFFFFFFF0000FFFF
          040700000700000700000004FFFFFFFF0000FFFF040707070707070707000000
          FFFFFFFF0000FFFF04070000070000070000FBF800FFFFFF0000FFFF04070707
          070707070700FB0700FFFFFF0000FFFF0404040404040404040400FBF800FFFF
          0000FFFF0404040404040404040400FB0700FFFF0000FFFF0404040404040404
          04040400FBF800FF0000FFFFFFFFFFFFFFFFFFFFFFFFFF00FBF800FF0000FFFF
          FFFFFFFFFFFFFFFFFFFFFFFF000005000000FFFFFFFFFFFFFFFFFFFFFFFFFFFF
          000505000000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF0000FF0000FFFFFFFFFFFF
          FFFFFFFFFFFFFFFFFFFFFFFF0000FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF
          0000}
        OnClick = SpeedButton1Click
      end
      object SpeedButton2: TSpeedButton
        Left = 378
        Top = 2
        Width = 93
        Height = 28
        Cursor = crHandPoint
        Caption = 'Redakt'#601' et    '
        Flat = True
        Glyph.Data = {
          36010000424D3601000000000000760000002800000011000000100000000100
          040000000000C0000000CE0E0000D80E00001000000000000000000000000000
          80000080000000808000800000008000800080800000C0C0C000808080000000
          FF0000FF000000FFFF00FF000000FF00FF00FFFF0000FFFFFF00700000000000
          0000000000007077777777777777000000007088888877788888000000007077
          7777777777770000000070888877700778880000000070777777011077770000
          0000708887709991077800000000707777709999107700000000708888770999
          030800000000707777777090B0300000000070777777770B0B03000000007000
          00777770B0B3300000007077707777770BBB3000000077077077777770BBB000
          0000777070777777770BB00000007777000000000000B0000000}
        OnClick = SpeedButton2Click
      end
    end
    object XDBGrid1: TXDBGrid
      Left = 2
      Top = 15
      Width = 486
      Height = 143
      Align = alClient
      DataSource = DataSource1
      Gradient.EndColor = clBtnShadow
      GridStyle.VisualStyle = vsXPStyle
      Options = [dgTitles, dgColumnResize, dgColLines, dgRowLines, dgTabs, dgRowSelect, dgConfirmDelete, dgCancelOnExit, dgExtendedSelect, dgInternalSelect, dgRowResize, dgRowScroll, dgHotButtons, dgTitleButtons, dgTitleHeaders, dgTitleWidthOff, dgMarkerAutoAlign, dgMarkerAutoToggle]
      TabOrder = 1
      TitleLinesCount = 2
      OnDblClick = XDBGrid1DblClick
      Columns = <
        item
          Expanded = False
          FieldName = 'NAME'
          Title.Caption = 'Ad'#305
          Visible = True
          Width = 166
        end
        item
          Expanded = False
          FieldName = 'operation'
          Title.Caption = 'Ehtiyyatlar '#252'zr'#601' '#601'm'#601'liyyatlar'
          Visible = True
          Width = 255
        end>
    end
  end
  object GroupBox2: TGroupBox
    Left = 0
    Top = 191
    Width = 490
    Height = 134
    Align = alTop
    Caption = 'M'#252#351't'#601'rinin keyfiyy'#601't meyar'#305
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = [fsBold]
    ParentFont = False
    TabOrder = 1
    object XDBGrid2: TXDBGrid
      Left = 2
      Top = 15
      Width = 486
      Height = 117
      Align = alClient
      DataSource = DataSource2
      Gradient.EndColor = clMedGray
      GridStyle.VisualStyle = vsXPStyle
      Options = [dgTitles, dgColumnResize, dgColLines, dgRowLines, dgTabs, dgRowSelect, dgConfirmDelete, dgCancelOnExit, dgExtendedSelect, dgInternalSelect, dgRowResize, dgRowScroll, dgHotButtons, dgTitleButtons, dgTitleHeaders, dgTitleWidthOff, dgMarkerAutoAlign, dgMarkerAutoToggle]
      TabOrder = 0
      Columns = <
        item
          Expanded = False
          FieldName = 'ID'
          Visible = True
          Width = 31
        end
        item
          Expanded = False
          FieldName = 'NAME'
          Title.Caption = 'Ad'#305
          Visible = True
          Width = 288
        end>
    end
  end
  object GroupBox3: TGroupBox
    Left = 0
    Top = 434
    Width = 490
    Height = 240
    Align = alTop
    Caption = 'Gecikm'#601' g'#252'nl'#601'ri '#252'zr'#601' ehtiyyat d'#601'r'#601'c'#601'l'#601'ri'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = [fsBold]
    ParentFont = False
    TabOrder = 2
    object XDBGrid3: TXDBGrid
      Left = 2
      Top = 15
      Width = 486
      Height = 223
      Align = alClient
      DataSource = DataSource3
      Gradient.EndColor = clMedGray
      GridStyle.VisualStyle = vsXPStyle
      Options = [dgEditing, dgTitles, dgColumnResize, dgColLines, dgRowLines, dgTabs, dgConfirmDelete, dgCancelOnExit, dgExtendedSelect, dgInternalSelect, dgRowResize, dgRowScroll, dgHotButtons, dgTitleButtons, dgTitleHeaders, dgTitleWidthOff, dgMarkerAutoAlign, dgMarkerAutoToggle]
      TabOrder = 0
      Columns = <
        item
          Expanded = False
          FieldName = 'TESNAME'
          ReadOnly = True
          Title.Caption = 'T'#601'snifat'#305'n ad'#305
          Visible = True
          Width = 188
        end
        item
          Expanded = False
          FieldName = 'PERCENT'
          ReadOnly = True
          Title.Caption = '%'
          Visible = True
          Width = 23
        end
        item
          Expanded = False
          FieldName = 'BDUEDAY'
          Title.Caption = 'Gec g'#252'n -dan'
          Visible = True
          Width = 82
        end
        item
          Expanded = False
          FieldName = 'EDUEDAY'
          Title.Caption = 'Gec g'#252'n-d'#601'k'
          Visible = True
          Width = 79
        end>
    end
  end
  object Panel1: TPanel
    Left = 0
    Top = 674
    Width = 490
    Height = 30
    Align = alTop
    BevelOuter = bvLowered
    TabOrder = 3
    object XFButton1: TXFButton
      Left = 414
      Top = 1
      Width = 75
      Height = 28
      Align = alRight
      Caption = 'Ba'#287'la'
      DoubleBuffered = True
      ParentDoubleBuffered = False
      TabOrder = 0
      OnClick = XFButton1Click
      Gradient.Direction = gdHorizontal
      Gradient.EndColor = clMedGray
    end
    object XFButton2: TXFButton
      Left = 0
      Top = 1
      Width = 105
      Height = 28
      Caption = 'Hesablar'#305' sazla'
      DoubleBuffered = True
      ParentDoubleBuffered = False
      TabOrder = 1
      OnClick = XFButton2Click
      Gradient.Direction = gdHorizontal
      Gradient.EndColor = clMedGray
    end
  end
  object GroupBox4: TGroupBox
    Left = 0
    Top = 325
    Width = 490
    Height = 109
    Align = alTop
    Caption = 'Valyuta'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -11
    Font.Name = 'Tahoma'
    Font.Style = [fsBold]
    ParentFont = False
    TabOrder = 4
    object XDBGrid4: TXDBGrid
      Left = 2
      Top = 15
      Width = 486
      Height = 92
      Align = alClient
      DataSource = DataSource4
      Gradient.EndColor = clMedGray
      GridStyle.VisualStyle = vsXPStyle
      Options = [dgTitles, dgColumnResize, dgColLines, dgRowLines, dgTabs, dgRowSelect, dgConfirmDelete, dgCancelOnExit, dgExtendedSelect, dgInternalSelect, dgRowResize, dgRowScroll, dgHotButtons, dgTitleButtons, dgTitleHeaders, dgTitleWidthOff, dgMarkerAutoAlign, dgMarkerAutoToggle]
      TabOrder = 0
      Columns = <
        item
          Expanded = False
          FieldName = 'ID'
          Visible = True
          Width = 31
        end
        item
          Expanded = False
          FieldName = 'NAME'
          Title.Caption = 'Ad'#305
          Visible = True
          Width = 288
        end>
    end
  end
  object OracleDataSet1: TOracleDataSet
    SQL.Strings = (
      'select rowid,a.*'
      ' from cm_tesnifat a')
    Optimize = False
    QBEDefinition.QBEFieldDefs = {
      05000000040000000400000049004400010000000000080000004E0041004D00
      45000100000000002000000052004500530045005200560045004F0050004500
      52004100540049004F004E00010000000000160000004100550054004F005200
      450053004500520056004500010000000000}
    Session = sboapiDataModule.SBSession
    AfterPost = OracleDataSet1AfterPost
    Left = 40
    Top = 80
    object OracleDataSet1ID: TFloatField
      FieldName = 'ID'
    end
    object OracleDataSet1NAME: TWideStringField
      FieldName = 'NAME'
      Size = 150
    end
    object OracleDataSet1RESERVEOPERATION: TFloatField
      FieldName = 'RESERVEOPERATION'
      Required = True
    end
    object OracleDataSet1AUTORESERVE: TFloatField
      FieldName = 'AUTORESERVE'
    end
    object OracleDataSet1autore: TWideStringField
      FieldKind = fkLookup
      FieldName = 'autore'
      LookupDataSet = AutoPayment
      LookupKeyFields = 'ID'
      LookupResultField = 'DESCRIPTION'
      KeyFields = 'AUTORESERVE'
      Lookup = True
    end
    object OracleDataSet1operation: TWideStringField
      FieldKind = fkLookup
      FieldName = 'operation'
      LookupDataSet = OracleDataSet5
      LookupKeyFields = 'ID'
      LookupResultField = 'NAME'
      KeyFields = 'RESERVEOPERATION'
      Size = 150
      Lookup = True
    end
  end
  object DataSource1: TDataSource
    DataSet = OracleDataSet1
    Left = 128
    Top = 80
  end
  object OracleDataSet3: TOracleDataSet
    SQL.Strings = (
      'SELECT a.id, a.name, a.tes_id, a.kef_id'
      '  FROM cm_keyfiyyet a '
      'where tes_id=:tes_id')
    Optimize = False
    Variables.Data = {
      04000000010000000E0000003A005400450053005F0049004400030000000000
      000000000000}
    QBEDefinition.QBEFieldDefs = {
      05000000040000000400000049004400010000000000080000004E0041004D00
      45000100000000000C0000005400450053005F00490044000100000000000C00
      00004B00450046005F0049004400010000000000}
    Master = OracleDataSet1
    MasterFields = 'id'
    DetailFields = 'tes_id'
    Session = sboapiDataModule.SBSession
    Left = 40
    Top = 232
  end
  object DataSource2: TDataSource
    DataSet = OracleDataSet3
    Left = 128
    Top = 232
  end
  object OracleDataSet4: TOracleDataSet
    SQL.Strings = (
      'select rowid,a.* from cm_gecguntesnifat a'
      'where kef_id=:kef_id'
      ''
      'order by percent')
    Optimize = False
    Variables.Data = {
      04000000010000000E0000003A004B00450046005F0049004400030000000000
      000000000000}
    QBEDefinition.QBEFieldDefs = {
      050000000700000004000000490044000100000000000C000000540045005300
      5F00490044000100000000000C0000004B00450046005F004900440001000000
      00000E000000500045005200430045004E0054000100000000000E0000005400
      450053004E0041004D0045000100000000000E00000042004400550045004400
      410059000100000000000E000000450044005500450044004100590001000000
      0000}
    Master = OracleDataSet6
    MasterFields = 'id'
    DetailFields = 'KEF_ID'
    Session = sboapiDataModule.SBSession
    Left = 130
    Top = 504
    object OracleDataSet4ID: TFloatField
      FieldName = 'ID'
    end
    object OracleDataSet4TES_ID: TFloatField
      FieldName = 'TES_ID'
    end
    object OracleDataSet4KEF_ID: TFloatField
      FieldName = 'KEF_ID'
    end
    object OracleDataSet4PERCENT: TFloatField
      FieldName = 'PERCENT'
    end
    object OracleDataSet4TESNAME: TWideStringField
      FieldName = 'TESNAME'
      Size = 150
    end
    object OracleDataSet4BDUEDAY: TFloatField
      FieldName = 'BDUEDAY'
    end
    object OracleDataSet4EDUEDAY: TFloatField
      FieldName = 'EDUEDAY'
    end
  end
  object DataSource3: TDataSource
    DataSet = OracleDataSet4
    Left = 224
    Top = 520
  end
  object AutoPayment: TOracleDataSet
    SQL.Strings = (
      'SELECT id, description'
      '  FROM cm_automation')
    Optimize = False
    QBEDefinition.QBEFieldDefs = {
      0500000002000000040000004900440001000000000016000000440045005300
      4300520049005000540049004F004E00010000000000}
    Cursor = crHourGlass
    Session = sboapiDataModule.SBSession
    Left = 240
    Top = 120
  end
  object DataSrcAutoRes: TDataSource
    DataSet = AutoPayment
    Left = 240
    Top = 72
  end
  object DataSource: TDataSource
    DataSet = OracleDataSet2
    Left = 336
    Top = 120
  end
  object OracleDataSet5: TOracleDataSet
    SQL.Strings = (
      'SELECT *'
      '  FROM cm_reserve_optype')
    Optimize = False
    QBEDefinition.QBEFieldDefs = {
      05000000030000000400000049004400010000000000080000004E0041004D00
      4500010000000000080000004100550054004F00010000000000}
    Session = sboapiDataModule.SBSession
    Active = True
    Left = 424
    Top = 72
  end
  object OracleDataSet2: TOracleDataSet
    SQL.Strings = (
      'SELECT *'
      '  FROM cm_reserve_optype'
      '')
    Optimize = False
    QBEDefinition.QBEFieldDefs = {
      05000000030000000400000049004400010000000000080000004E0041004D00
      4500010000000000080000004100550054004F00010000000000}
    Session = sboapiDataModule.SBSession
    Left = 336
    Top = 72
  end
  object OracleDataSet6: TOracleDataSet
    SQL.Strings = (
      'SELECT *'
      '  FROM cm_auto_reserve_valute'
      'where kefid=:kefid')
    Optimize = False
    Variables.Data = {
      04000000010000000C0000003A004B0045004600490044000300000000000000
      00000000}
    QBEDefinition.QBEFieldDefs = {
      05000000040000000400000049004400010000000000080000004E0041004D00
      45000100000000000C0000005400450053005F00490044000100000000000C00
      00004B00450046005F0049004400010000000000}
    Master = OracleDataSet3
    MasterFields = 'ID'
    DetailFields = 'KEFID'
    Session = sboapiDataModule.SBSession
    Left = 136
    Top = 336
  end
  object DataSource4: TDataSource
    DataSet = OracleDataSet6
    Left = 224
    Top = 336
  end
end
