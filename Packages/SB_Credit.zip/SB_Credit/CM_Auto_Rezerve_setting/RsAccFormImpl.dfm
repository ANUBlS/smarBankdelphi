object RsAccForm: TRsAccForm
  Left = 0
  Top = 0
  ClientHeight = 635
  ClientWidth = 956
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  Position = poDesktopCenter
  OnCreate = FormCreate
  PixelsPerInch = 96
  TextHeight = 13
  object GroupBox1: TGroupBox
    Left = 0
    Top = 0
    Width = 956
    Height = 348
    Align = alTop
    Caption = 'Filiallar'
    TabOrder = 0
    ExplicitWidth = 635
    object DBGrid1: TDBGrid
      Left = 2
      Top = 15
      Width = 952
      Height = 331
      Align = alClient
      DataSource = DataSource2
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = [fsBold]
      Options = [dgTitles, dgIndicator, dgColumnResize, dgColLines, dgRowLines, dgTabs, dgRowSelect, dgConfirmDelete, dgCancelOnExit, dgTitleClick, dgTitleHotTrack]
      ParentFont = False
      TabOrder = 0
      TitleFont.Charset = DEFAULT_CHARSET
      TitleFont.Color = clWindowText
      TitleFont.Height = -11
      TitleFont.Name = 'Tahoma'
      TitleFont.Style = []
      Columns = <
        item
          Expanded = False
          FieldName = 'fil_name'
          Title.Caption = 'Filial'#305'n ad'#305
          Width = 557
          Visible = True
        end>
    end
  end
  object GroupBox2: TGroupBox
    Left = 0
    Top = 348
    Width = 956
    Height = 257
    Align = alTop
    Caption = 'Filiallar '#252'zr'#601' ehtiyyat hesablar'#305
    TabOrder = 1
    ExplicitWidth = 635
    object DBGridEh1: TDBGridEh
      Left = 2
      Top = 15
      Width = 952
      Height = 240
      Align = alClient
      DataGrouping.GroupLevels = <>
      DataSource = DataSource3
      Flat = False
      FooterColor = clWindow
      FooterFont.Charset = DEFAULT_CHARSET
      FooterFont.Color = clWindowText
      FooterFont.Height = -11
      FooterFont.Name = 'Tahoma'
      FooterFont.Style = []
      RowDetailPanel.Color = clBtnFace
      TabOrder = 0
      TitleFont.Charset = DEFAULT_CHARSET
      TitleFont.Color = clWindowText
      TitleFont.Height = -11
      TitleFont.Name = 'Tahoma'
      TitleFont.Style = []
      Columns = <
        item
          EditButtons = <>
          FieldName = 'RESERVENAME'
          Footers = <>
          ReadOnly = True
          Title.Caption = 'Ehtiyyat '
          Width = 126
        end
        item
          EditButtons = <>
          FieldName = 'esashes'
          Footers = <>
          Title.Caption = #399'sas '#252'zr'#601' ehtiyyat hesab'#305
          Width = 373
        end
        item
          EditButtons = <>
          FieldName = 'faishes'
          Footers = <>
          Title.Caption = 'Faiz '#252'zr'#601' ehtiyat hesab'#305
          Width = 382
        end>
      object RowDetailData: TRowDetailPanelControlEh
      end
    end
  end
  object Button1: TButton
    Left = 776
    Top = 611
    Width = 75
    Height = 25
    Caption = 'Ba'#287'la'
    TabOrder = 2
    OnClick = Button1Click
  end
  object DataSource3: TDataSource
    DataSet = OracleDataSet3
    Left = 224
    Top = 416
  end
  object OracleDataSet3: TOracleDataSet
    SQL.Strings = (
      'select rowid,a.* from CM_RESERVE_ACCOUNT  a'
      'where fil_id=:fil_id'
      'order by reserveid'
      ''
      '')
    Optimize = False
    Variables.Data = {
      04000000010000000E0000003A00460049004C005F0049004400030000000000
      000000000000}
    QBEDefinition.QBEFieldDefs = {
      0500000006000000040000004900440001000000000012000000520045005300
      4500520056004500490044000100000000001600000052004500530045005200
      560045004E0041004D0045000100000000000C000000460049004C005F004900
      44000100000000001400000052004500530054005F0041004300430049004400
      0100000000001C00000049004E005400450052004500530054005F0041004300
      430049004400010000000000}
    Master = OracleDataSet2
    MasterFields = 'id'
    DetailFields = 'FIL_ID'
    Session = sboapiDataModule.SBSession
    Left = 304
    Top = 416
    object OracleDataSet3ID: TFloatField
      FieldName = 'ID'
    end
    object OracleDataSet3RESERVEID: TFloatField
      FieldName = 'RESERVEID'
    end
    object OracleDataSet3RESERVENAME: TWideStringField
      FieldName = 'RESERVENAME'
      Size = 80
    end
    object OracleDataSet3FIL_ID: TFloatField
      FieldName = 'FIL_ID'
    end
    object OracleDataSet3REST_ACCID: TFloatField
      FieldName = 'REST_ACCID'
    end
    object OracleDataSet3INTEREST_ACCID: TFloatField
      FieldName = 'INTEREST_ACCID'
    end
    object OracleDataSet3esashes: TWideStringField
      FieldKind = fkLookup
      FieldName = 'esashes'
      LookupDataSet = PReserveAccs
      LookupKeyFields = 'ID'
      LookupResultField = 'ACCNO'
      KeyFields = 'REST_ACCID'
      Size = 200
      Lookup = True
    end
    object OracleDataSet3faishes: TWideStringField
      FieldKind = fkLookup
      FieldName = 'faishes'
      LookupDataSet = PReserveAccs
      LookupKeyFields = 'ID'
      LookupResultField = 'ACCNO'
      KeyFields = 'INTEREST_ACCID'
      Size = 200
      Lookup = True
    end
  end
  object OracleDataSet2: TOracleDataSet
    SQL.Strings = (
      'select a.* from CM_RESERVE_FILIAL a '
      'where fil_id in(select id from filial)'
      ''
      'order by fil_id'
      ''
      '')
    Optimize = False
    QBEDefinition.QBEFieldDefs = {
      0500000004000000040000004900440001000000000010000000500045005200
      53004F004E00490044000100000000000E000000520045005A00440045004E00
      54000100000000000C00000044004F0056004C0045005400010000000000}
    Session = sboapiDataModule.SBSession
    Left = 312
    Top = 200
  end
  object DataSource2: TDataSource
    DataSet = OracleDataSet2
    Left = 224
    Top = 200
  end
  object DataSrcPReserveAccs: TDataSource
    DataSet = PReserveAccs
    Left = 505
    Top = 144
  end
  object PReserveAccs: TOracleDataSet
    SQL.Strings = (
      
        'SELECT   ac.id AS id, ac.kli_id AS custid, ac.acc_no||'#39' '#39'||ac.na' +
        'me AS accno,'
      '         ac.NAME AS clientname, ac.val_acc'
      '    FROM account ac'
      
        '   WHERE val_acc = 0 and close_dat is null --and ac.kli_id=:kli_' +
        'id'
      '   '
      '     AND (ac.bal_cn1 IN (SELECT accountnumber'
      '                           FROM cm_aginfo'
      '                          WHERE groupid = (SELECT g.id'
      
        '                                             FROM cm_accountgrou' +
        'ps g'
      
        '                                            WHERE g.iname = '#39'PRe' +
        'serveAccs'#39'))'
      '         )'
      'ORDER BY accno,kli_id'
      ''
      '')
    Optimize = False
    QBEDefinition.QBEFieldDefs = {
      050000000500000004000000490044000100000000000C000000430055005300
      5400490044000100000000000A0000004100430043004E004F00010000000000
      1400000043004C00490045004E0054004E0041004D0045000100000000000E00
      0000560041004C005F00410043004300010000000000}
    Cursor = crHourGlass
    Session = sboapiDataModule.SBSession
    Left = 505
    Top = 200
    object PReserveAccsID: TFloatField
      FieldName = 'ID'
      Required = True
    end
    object PReserveAccsCUSTID: TFloatField
      FieldName = 'CUSTID'
    end
    object PReserveAccsACCNO: TWideStringField
      FieldName = 'ACCNO'
      Size = 200
    end
    object PReserveAccsCLIENTNAME: TWideStringField
      FieldName = 'CLIENTNAME'
      Size = 250
    end
    object PReserveAccsVAL_ACC: TIntegerField
      FieldName = 'VAL_ACC'
    end
  end
end
