object CMDataModule: TCMDataModule
  OldCreateOrder = False
  OnCreate = DataModuleCreate
  Left = 399
  Top = 192
  Height = 479
  Width = 696
  object CMSession: TOracleSession
    DesignConnection = True
    LogonUsername = 'CreditsMgr'
    LogonPassword = 's6c457f61'
    LogonDatabase = 'TURAN'
    Connected = True
    Left = 40
    Top = 40
  end
  object CMLogon_: TOracleLogon
    Session = CMSession
    Retries = 3
    Options = [ldDatabase, ldDatabaseList]
    Left = 40
    Top = 96
  end
  object DSBankDate: TOracleDataSet
    SQL.Strings = (
      'select TEK_DAT , PRED_DAT '
      '  from SB_SYSDAT')
    Session = CMSession
    Left = 144
    Top = 32
  end
  object Branch: TOracleDataSet
    SQL.Strings = (
      'select'
      '   KOD_FIL'
      'from SB_BANKINFO')
    Session = CMSession
    Left = 144
    Top = 96
  end
  object CM_LOGIN: TOraclePackage
    Session = CMSession
    PackageName = 'CM_LOGIN'
    Left = 232
    Top = 40
  end
  object CMLogon: TOraLogon
    Session = CMSession
    Retries = 3
    Left = 232
    Top = 104
  end
end
