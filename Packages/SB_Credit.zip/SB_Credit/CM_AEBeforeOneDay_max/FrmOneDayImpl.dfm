object FrmOneDay: TFrmOneDay
  Left = 675
  Top = 261
  ClientHeight = 248
  ClientWidth = 346
  Color = clBtnFace
  Font.Charset = TURKISH_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  Position = poScreenCenter
  OnCanResize = FormCanResize
  OnCreate = FormCreate
  OnDestroy = FormDestroy
  OnKeyPress = FormKeyPress
  PixelsPerInch = 96
  TextHeight = 13
  object Panel1: TPanel
    Left = 0
    Top = 0
    Width = 346
    Height = 246
    Align = alTop
    BevelOuter = bvNone
    BiDiMode = bdLeftToRight
    BorderStyle = bsSingle
    Color = clWhite
    Ctl3D = False
    ParentBiDiMode = False
    ParentCtl3D = False
    TabOrder = 0
    OnCanResize = Panel1CanResize
    object SpeedButton1: TSpeedButton
      Left = 173
      Top = 215
      Width = 78
      Height = 26
      Cursor = crHandPoint
      Caption = 'Q'#601'bul et'
      Flat = True
      Font.Charset = TURKISH_CHARSET
      Font.Color = clGreen
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = [fsBold]
      Glyph.Data = {
        BE060000424DBE06000000000000360400002800000024000000120000000100
        0800000000008802000000000000000000000001000000000000000000000000
        80000080000000808000800000008000800080800000C0C0C000C0DCC000F0CA
        A600000000000000000000000000000000000000000000000000000000000000
        0000000000000000000000000000000000000000000000000000000000000000
        0000000000000000000000000000000000000000000000000000000000000000
        0000000000000000000000000000000000000000000000000000000000000000
        0000000000000000000000000000000000000000000000000000000000000000
        0000000000000000000000000000000000000000000000000000000000000000
        0000000000000000000000000000000000000000000000000000000000000000
        0000000000000000000000000000000000000000000000000000000000000000
        0000000000000000000000000000000000000000000000000000000000000000
        0000000000000000000000000000000000000000000000000000000000000000
        0000000000000000000000000000000000000000000000000000000000000000
        0000000000000000000000000000000000000000000000000000000000000000
        0000000000000000000000000000000000000000000000000000000000000000
        0000000000000000000000000000000000000000000000000000000000000000
        0000000000000000000000000000000000000000000000000000000000000000
        0000000000000000000000000000000000000000000000000000000000000000
        0000000000000000000000000000000000000000000000000000000000000000
        0000000000000000000000000000000000000000000000000000000000000000
        0000000000000000000000000000000000000000000000000000000000000000
        0000000000000000000000000000000000000000000000000000000000000000
        0000000000000000000000000000000000000000000000000000000000000000
        0000000000000000000000000000000000000000000000000000000000000000
        0000000000000000000000000000000000000000000000000000000000000000
        0000000000000000000000000000000000000000000000000000000000000000
        0000000000000000000000000000000000000000000000000000000000000000
        0000000000000000000000000000000000000000000000000000000000000000
        0000000000000000000000000000000000000000000000000000000000000000
        0000000000000000000000000000000000000000000000000000000000000000
        0000000000000000000000000000000000000000000000000000000000000000
        000000000000000000000000000000000000F0FBFF00A4A0A000808080000000
        FF0000FF000000FFFF00FF000000FF00FF00FFFF0000FFFFFF00030303030303
        0303030303030303030303030303030303030303030303030303030303030303
        03030303030303030303030303030303030303030303FF030303030303030303
        03030303030303040403030303030303030303030303030303F8F8FF03030303
        03030303030303030303040202040303030303030303030303030303F80303F8
        FF030303030303030303030303040202020204030303030303030303030303F8
        03030303F8FF0303030303030303030304020202020202040303030303030303
        0303F8030303030303F8FF030303030303030304020202FA0202020204030303
        0303030303F8FF0303F8FF030303F8FF03030303030303020202FA03FA020202
        040303030303030303F8FF03F803F8FF0303F8FF03030303030303FA02FA0303
        03FA0202020403030303030303F8FFF8030303F8FF0303F8FF03030303030303
        FA0303030303FA0202020403030303030303F80303030303F8FF0303F8FF0303
        0303030303030303030303FA0202020403030303030303030303030303F8FF03
        03F8FF03030303030303030303030303FA020202040303030303030303030303
        0303F8FF0303F8FF03030303030303030303030303FA02020204030303030303
        03030303030303F8FF0303F8FF03030303030303030303030303FA0202020403
        030303030303030303030303F8FF0303F8FF03030303030303030303030303FA
        0202040303030303030303030303030303F8FF03F8FF03030303030303030303
        03030303FA0202030303030303030303030303030303F8FFF803030303030303
        030303030303030303FA0303030303030303030303030303030303F803030303
        0303030303030303030303030303030303030303030303030303030303030303
        0303}
      NumGlyphs = 2
      ParentFont = False
      OnClick = SpeedButton1Click
    end
    object SpeedButton2: TSpeedButton
      Left = 252
      Top = 215
      Width = 78
      Height = 26
      Cursor = crHandPoint
      Caption = 'Ba'#287'la'
      Flat = True
      Font.Charset = TURKISH_CHARSET
      Font.Color = clMaroon
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = [fsBold]
      Glyph.Data = {
        36050000424D3605000000000000360400002800000010000000100000000100
        08000000000000010000CE0E0000D80E00000001000000000000000000008080
        8000000080000080800000800000808000008000000080008000408080004040
        0000FF80000080400000FF00400000408000FFFFFF00C0C0C0000000FF0000FF
        FF0000FF0000FFFF0000FF000000FF00FF0080FFFF0080FF0000FFFF8000FF80
        80008000FF004080FF00C0DCC000F0CAA6000008000000000800000808000804
        00000800080008080800130E0800040314001008100010101000151414001311
        1F002525210018133F004E0C11004D1D0F00681C1000561D21006B1C21004A3B
        36005655560077141800741324008F0E2200940F30008818230084292300893C
        400011097E004C4B75005A6B6300666666005A73630065706D00736D6D007373
        73007878730073737B0077777B00945D670096706D007B7B7B00837B8100947B
        73009C7B730084847B008484840084848C0090878700948C8E00948C94008C94
        9400949494009C9494009C9C940094949C009C949C009C9C9C00A80F2300AD18
        2900A9083100A5143500AF102B00AD0C3900BC072B00C10D3600AD1E2900A82C
        2700AD183900A9293100BE1B2900BD183100C01F3100B2154200A9213900B121
        3D00B5214200AB2C3900A9294200A92F4600BB1B4000B5294200BD293900B929
        4600C7184200CC253E00C1254A00CF254E00AC3F3200AB3F4200AE354A00AD4A
        4200C1383D00C6314A00CE314A00BD394A00AD3D4F00BD355200AD475000BD42
        5200C8395100C1425A00CC3F5E00B3524200B5525300B54E5E00B85C5B00C654
        5000D95F5100F6624600B2606A00C15A6B00CC586500CC5D6F00B7848300DD7C
        6E00E89889000C08B5000D0DE1001010EF000000F7000808F7000D0DFC001B1B
        ED003A3AE2002222FB003939FF006E6ECD005656FF007777FF009494A5009C9C
        A500A59CA500A5A5A500ADA5A5009494AD00A5A5AD00ADA5AD00A5A7B500A0A0
        C6009B9BDB008C8CFF009494FF009C9CFF00A5A5FF00B5A5A500BDA5A500B5AD
        A500BDADA500ADADAD00B5ADAD00B5B5AD00B1ADB500C6A7AA00C9B1AE00D6B1
        A900EDB0A900FFAFA200FFB5AD00FFBDAD00B5B5B500BDB5B500BDBDB500ADAD
        BD00B9B5BD00B3B3DB00B1B1FF00C1B9B900BDBDC600CBBBBA00E5BBB700C6C6
        C600DABDC600C1C1D600BDBDFF00D6C6C600DEC6C600CEC6CE00D6C6CE00DEC6
        CE00CECECE00D6CECE00D6D6CE00D2CED600D6D6D600DECECE00DECED600DED6
        D600D6D6DE00DED6DE00F4C8BE00F0CFCB00FFD6C600E7CED600E7D6D600F1D3
        D600FFD6CE00DEDEDE00E7DED600E7E7D600EBD6DE00E7DEDE00FFD6D600FFDE
        D600D2D2EF00C6C6FF00CECEFF00D6D6FF00DEDEE700DEDEFF00E7DEE700E7E7
        E700E7E7FF00EFDEDE00EFE7E700EFE7EF00F7E7E700FFDEDE00FFE7DE00FFE7
        E700EFEFEF00EFEFFF00F7EFEF00F7EFF700FFEFE700FFEFEF000F0F01010F0F
        0F0F0F0F0F0F0F0F0F0F0F100202010F0F0F0F0F10010F0F0F0F0F1002020201
        0F0F0F100202010F0F0F0F1002020202010F1002020202010F0F0F0F10020202
        02010202020202010F0F0F0F0F100202020202020202010F0F0F0F0F0F0F1002
        0202020202010F0F0F0F0F0F0F0F0F0202020202010F0F0F0F0F0F0F0F0F0F10
        02020202010F0F0F0F0F0F0F0F0F100202020202010F0F0F0F0F0F0F0F100202
        0201020202010F0F0F0F0F0F10020202010F10020202010F0F0F0F0F10020201
        0F0F0F10020202010F0F0F0F0F10020F0F0F0F0F100202020F0F0F0F0F0F0F0F
        0F0F0F0F0F1002100F0F0F0F0F0F0F0F0F0F0F0F0F0F0F0F0F0F}
      ParentFont = False
      OnClick = SpeedButton2Click
    end
    object Label1: TLabel
      Left = 5
      Top = 14
      Width = 32
      Height = 13
      Caption = 'Tarix '
      Font.Charset = TURKISH_CHARSET
      Font.Color = clBlue
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = [fsBold]
      ParentFont = False
    end
    object Label2: TLabel
      Left = 163
      Top = 17
      Width = 5
      Height = 13
      Caption = '-'
      Font.Charset = TURKISH_CHARSET
      Font.Color = clBlue
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = [fsBold]
      ParentFont = False
    end
    object GroupBox6: TGroupBox
      Left = 2
      Top = 37
      Width = 165
      Height = 65
      Caption = 'Valyuta'
      Font.Charset = TURKISH_CHARSET
      Font.Color = clBlue
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = [fsBold]
      ParentFont = False
      TabOrder = 0
      object CBaValute: TCheckBox
        Left = 8
        Top = 40
        Width = 97
        Height = 17
        Caption = 'T'#601'tbiq et'
        Font.Charset = TURKISH_CHARSET
        Font.Color = clWindowText
        Font.Height = -11
        Font.Name = 'Tahoma'
        Font.Style = []
        ParentFont = False
        TabOrder = 0
      end
      object LCBValutes: TDBLookupComboBox
        Left = 2
        Top = 18
        Width = 159
        Height = 19
        Ctl3D = False
        Font.Charset = TURKISH_CHARSET
        Font.Color = clWindowText
        Font.Height = -11
        Font.Name = 'Tahoma'
        Font.Style = []
        KeyField = 'VALUTE'
        ListField = 'VALU_NAME'
        ListSource = DatSrcValute
        ParentCtl3D = False
        ParentFont = False
        TabOrder = 1
      end
    end
    object GroupBox1: TGroupBox
      Left = 172
      Top = 37
      Width = 161
      Height = 65
      Caption = 'Filial'
      Font.Charset = TURKISH_CHARSET
      Font.Color = clBlue
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = [fsBold]
      ParentFont = False
      TabOrder = 1
      object CBFilial: TCheckBox
        Left = 8
        Top = 40
        Width = 97
        Height = 17
        Caption = 'T'#601'tbiq et'
        Font.Charset = RUSSIAN_CHARSET
        Font.Color = clWindowText
        Font.Height = -11
        Font.Name = 'Azl Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 0
      end
      object LCBFilials: TDBLookupComboBox
        Left = 2
        Top = 18
        Width = 156
        Height = 19
        Ctl3D = False
        Font.Charset = TURKISH_CHARSET
        Font.Color = clWindowText
        Font.Height = -11
        Font.Name = 'Tahoma'
        Font.Style = []
        KeyField = 'ID'
        ListField = 'NAME'
        ListSource = DatSrcFilials
        ParentCtl3D = False
        ParentFont = False
        TabOrder = 1
      end
    end
    object GroupBox2: TGroupBox
      Left = 2
      Top = 102
      Width = 165
      Height = 65
      Caption = 'Borcalan'#305'n kateqoriyas'#305
      Font.Charset = TURKISH_CHARSET
      Font.Color = clBlue
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = [fsBold]
      ParentFont = False
      TabOrder = 2
      object CBPersons: TCheckBox
        Left = 3
        Top = 42
        Width = 97
        Height = 17
        Caption = 'T'#601'tbiq et'
        Font.Charset = TURKISH_CHARSET
        Font.Color = clWindowText
        Font.Height = -11
        Font.Name = 'Tahoma'
        Font.Style = []
        ParentFont = False
        TabOrder = 0
      end
      object LCBPersons: TDBLookupComboBox
        Left = 2
        Top = 18
        Width = 158
        Height = 19
        Ctl3D = False
        Font.Charset = TURKISH_CHARSET
        Font.Color = clWindowText
        Font.Height = -11
        Font.Name = 'Tahoma'
        Font.Style = []
        KeyField = 'ID'
        ListField = 'DESCRIPION'
        ListSource = DatSrcPersons
        ParentCtl3D = False
        ParentFont = False
        TabOrder = 1
      end
    end
    object GroupBox3: TGroupBox
      Left = 172
      Top = 102
      Width = 161
      Height = 65
      Caption = 'Kreditin t'#601'snifat'#305
      Font.Charset = TURKISH_CHARSET
      Font.Color = clBlue
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = [fsBold]
      ParentFont = False
      TabOrder = 3
      DesignSize = (
        161
        65)
      object CBCategories: TCheckBox
        Left = 8
        Top = 40
        Width = 97
        Height = 17
        Caption = 'T'#601'tbiq et'
        Font.Charset = RUSSIAN_CHARSET
        Font.Color = clWindowText
        Font.Height = -11
        Font.Name = 'Azl Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 0
      end
      object LCBCategories: TDBLookupComboBox
        Left = 2
        Top = 18
        Width = 156
        Height = 19
        Anchors = [akLeft, akTop, akRight]
        Ctl3D = False
        Font.Charset = TURKISH_CHARSET
        Font.Color = clWindowText
        Font.Height = -11
        Font.Name = 'Tahoma'
        Font.Style = []
        ImeMode = imSAlpha
        KeyField = 'ID'
        ListField = 'FullDesc'
        ListSource = DataSrcReserves
        ParentCtl3D = False
        ParentFont = False
        TabOrder = 1
      end
    end
    object DateTimePicker1: TDateTimePicker
      Left = 38
      Top = 14
      Width = 121
      Height = 21
      Date = 41015.609337303240000000
      Time = 41015.609337303240000000
      TabOrder = 4
    end
    object DateTimePicker2: TDateTimePicker
      Left = 173
      Top = 14
      Width = 161
      Height = 21
      Date = 41015.609337303240000000
      Time = 41015.609337303240000000
      TabOrder = 5
    end
    object GroupBox4: TGroupBox
      Left = 2
      Top = 167
      Width = 165
      Height = 65
      Caption = 'Kredit inspoktoru'
      Font.Charset = TURKISH_CHARSET
      Font.Color = clBlue
      Font.Height = -11
      Font.Name = 'Tahoma'
      Font.Style = [fsBold]
      ParentFont = False
      TabOrder = 6
      object CheckBox1: TCheckBox
        Left = 8
        Top = 40
        Width = 97
        Height = 17
        Caption = 'T'#601'tbiq et'
        Font.Charset = TURKISH_CHARSET
        Font.Color = clWindowText
        Font.Height = -11
        Font.Name = 'Tahoma'
        Font.Style = []
        ParentFont = False
        TabOrder = 0
      end
      object DBLookupComboBox1: TDBLookupComboBox
        Left = 2
        Top = 18
        Width = 159
        Height = 19
        Ctl3D = False
        Font.Charset = TURKISH_CHARSET
        Font.Color = clWindowText
        Font.Height = -11
        Font.Name = 'Tahoma'
        Font.Style = []
        KeyField = 'ID'
        ListField = 'NAME'
        ListSource = DataSource1
        ParentCtl3D = False
        ParentFont = False
        TabOrder = 1
      end
    end
  end
  object DBLookupComboboxEh1: TDBLookupComboboxEh
    Left = -2
    Top = 309
    Width = 430
    Height = 21
    DropDownBox.Columns = <
      item
        FieldName = 'ID'
        Width = 30
      end
      item
        Alignment = taCenter
        Color = clWhite
        FieldName = 'DESCRIPION'
        Width = 20
      end>
    DropDownBox.ListSource = DatSrcPersons
    DropDownBox.AutoDrop = True
    EditButton.Style = ebsEllipsisEh
    EditButtons = <>
    KeyField = 'ID'
    ListField = 'DESCRIPION'
    ListSource = DatSrcPersons
    TabOrder = 1
    Visible = True
  end
  object DatSetValute: TOracleDataSet
    SQL.Strings = (
      'select valute,valu_name from avalute')
    Optimize = False
    Session = sboapiDataModule.SBSession
    Left = 119
    Top = 40
    object DatSetValuteVALUTE: TIntegerField
      FieldName = 'VALUTE'
      Required = True
    end
    object DatSetValuteVALU_NAME: TWideStringField
      FieldName = 'VALU_NAME'
      Size = 25
    end
  end
  object DatSrcValute: TDataSource
    DataSet = DatSetValute
    Left = 231
    Top = 56
  end
  object DatSrcFilials: TDataSource
    DataSet = DatSetFilials
    Left = 47
    Top = 40
  end
  object DatSetFilials: TOracleDataSet
    SQL.Strings = (
      'select id,name from sb_filial')
    Optimize = False
    QBEDefinition.QBEFieldDefs = {
      05000000020000000400000049004400010000000000080000004E0041004D00
      4500010000000000}
    Session = sboapiDataModule.SBSession
    Left = 272
    Top = 24
  end
  object EExport: TCMExcelExport
    ConnectTo = ctNewInstance
    StyleColumnWidth = cwAutoFit
    ColumnWidth = 0
    FontTitles.Charset = DEFAULT_CHARSET
    FontTitles.Color = clNavy
    FontTitles.Height = -13
    FontTitles.Name = 'Azl Sans Serif'
    FontTitles.Style = [fsBold]
    BorderTitles.Weight = bwThin
    BorderTitles.LineStyle = blLine
    OrientationTitles = 0
    FontData.Charset = RUSSIAN_CHARSET
    FontData.Color = clWindowText
    FontData.Height = -11
    FontData.Name = 'Azl Sans Serif'
    FontData.Style = []
    FontSummary.Charset = DEFAULT_CHARSET
    FontSummary.Color = clWindowText
    FontSummary.Height = -11
    FontSummary.Name = 'Azl Sans Serif'
    FontSummary.Style = []
    SummarySelection = ssNone
    SummaryCalculation = scSUM
    Left = 32
    Top = 96
  end
  object DatSetPersons: TOracleDataSet
    SQL.Strings = (
      'select id,descripion from cm_persons')
    Optimize = False
    Session = sboapiDataModule.SBSession
    Left = 144
    Top = 85
    object DatSetPersonsID: TFloatField
      FieldName = 'ID'
      Required = True
    end
    object DatSetPersonsDESCRIPION: TWideStringField
      FieldName = 'DESCRIPION'
      Size = 64
    end
  end
  object DatSrcPersons: TDataSource
    DataSet = DatSetPersons
    Left = 271
    Top = 80
  end
  object Reserves: TOracleDataSet
    SQL.Strings = (
      'select '
      '    ID,'
      '    Percent ,'
      '    Description'
      '  from'
      '    CM_RESERVES')
    Optimize = False
    Cursor = crHourGlass
    Session = sboapiDataModule.SBSession
    OnCalcFields = ReservesCalcFields
    Left = 102
    Top = 120
    object ReservesID: TFloatField
      FieldName = 'ID'
      Required = True
    end
    object ReservesPERCENT: TFloatField
      FieldName = 'PERCENT'
      Required = True
    end
    object ReservesDESCRIPTION: TWideStringField
      FieldName = 'DESCRIPTION'
      Required = True
      Size = 64
    end
    object ReservesFullDesc: TWideStringField
      FieldKind = fkCalculated
      FieldName = 'FullDesc'
      Size = 255
      Calculated = True
    end
  end
  object DataSrcReserves: TDataSource
    DataSet = Reserves
    Left = 222
    Top = 112
  end
  object OracleDataSet1: TOracleDataSet
    SQL.Strings = (
      
        'select p.numberofcredit,u.description mehsul_shexs,p.dateofgrant' +
        ', psh.PRINCIPAL,psh.INTEREST,psh.PRINCIPAL+psh.INTEREST odcem,ps' +
        'h.PAYMENTDATE,v.val_name,cm_common.get_accname(ac.CONTRACTACCID)' +
        '  as name ,e.name exname, l.phonenumber ,cm_utils.Get_PlanPrinci' +
        'pal(p.ID, :dat1) eo,interestrest,penaltyrest,cm_utils.Get_PlanPr' +
        'incipal(p.ID, :dat1) +interestrest+penaltyrest  cem '
      
        ',interestrest+((h.rest*annualyinterestrate/36000)*(:dat1-:dat)) ' +
        'proq,cm_utils.Get_MainPlanPayment(p.id,:dat1) odemeli,p.creditli' +
        'neamount,p.dateofconclusion,p.duedatefirstcontract,(select name ' +
        'from cm_mehsul where id =p.mehsulid) as mehsul ,(select name fro' +
        'm filial where id=p.branchid)filial from'
      
        'cm_active_credits p,cm_history h,CM_PAYMENT_SCHEDULE psh,smart.a' +
        'valute_t v,cm_accounts ac,cm_expert e,cm_boorowerinfo l,cm_userg' +
        'roups u'
      
        'where p.id=h.creditid and ac.creditid=p.id and p.id=l.creditid a' +
        'nd'
      
        '     h.hdate =sbop.get_date and h.rest+h.duerest>0 and p.usrgrou' +
        'p=u.id(+)'
      
        '     and psh.creditid=p.id and p.expertid=e.id(+)and --ishada go' +
        're yigilib and (((h.rest+h.duerest)>psh.rest) or(psh.PRINCIPAL=0' +
        '))  and'
      '     psh.PAYMENTDATE between :dat and :dat1 and'
      '     p.currency=v.valute'
      ''
      '/*8gh*/ '
      ''
      ''
      'order by p.numberofcredit')
    Optimize = False
    Variables.Data = {
      0400000002000000080000003A004400410054000C0000000000000000000000
      0A0000003A0044004100540031000C0000000000000000000000}
    QBEDefinition.QBEFieldDefs = {
      05000000160000001C0000004E0055004D004200450052004F00460043005200
      4500440049005400010000000000120000005000520049004E00430049005000
      41004C000100000000001000000049004E005400450052004500530054000100
      0000000010000000560041004C005F004E0041004D0045000100000000001600
      00005000410059004D0045004E00540044004100540045000100000000000800
      00004E0041004D0045000100000000000C000000450058004E0041004D004500
      01000000000016000000500048004F004E0045004E0055004D00420045005200
      0100000000000400000045004F000100000000001800000049004E0054004500
      5200450053005400520045005300540001000000000016000000500045004E00
      41004C0054005900520045005300540001000000000006000000430045004D00
      0100000000000A0000004F004400430045004D00010000000000080000005000
      52004F005100010000000000180000004D0045004800530055004C005F005300
      4800450058005300010000000000200000004300520045004400490054004C00
      49004E00450041004D004F0055004E0054000100000000001600000044004100
      540045004F0046004700520041004E0054000100000000000E0000004F004400
      45004D0045004C0049000100000000002000000044004100540045004F004600
      43004F004E0043004C005500530049004F004E00010000000000280000004400
      5500450044004100540045004600490052005300540043004F004E0054005200
      4100430054000100000000000C0000004D0045004800530055004C0001000000
      00000C000000460049004C00490041004C00010000000000}
    Session = sboapiDataModule.SBSession
    Left = 40
    Top = 160
    object OracleDataSet1NUMBEROFCREDIT: TWideStringField
      DisplayLabel = 'M'#252'qavil'#601'nin '#8470
      FieldName = 'NUMBEROFCREDIT'
      Size = 32
    end
    object OracleDataSet1NAME: TWideStringField
      DisplayLabel = 'Borcalan'
      FieldName = 'NAME'
      Size = 4000
    end
    object OracleDataSet1CREDITLINEAMOUNT: TFloatField
      DisplayLabel = 'Verilmi'#351' m'#601'bl'#601#287
      FieldName = 'CREDITLINEAMOUNT'
    end
    object OracleDataSet1DATEOFCONCLUSION: TDateTimeField
      DisplayLabel = 'M'#252'q. a'#231#305'lma tarixi'
      FieldName = 'DATEOFCONCLUSION'
    end
    object OracleDataSet1DUEDATEFIRSTCONTRACT: TDateTimeField
      DisplayLabel = 'M'#252'q. ba'#287'lanam tarixi'
      FieldName = 'DUEDATEFIRSTCONTRACT'
    end
    object OracleDataSet1MEHSUL: TWideStringField
      DisplayLabel = 'Kreditin m'#601'hsulu'
      FieldName = 'MEHSUL'
      Size = 400
    end
    object OracleDataSet1FILIAL: TWideStringField
      DisplayLabel = 'filial'
      FieldName = 'FILIAL'
      Size = 90
    end
    object OracleDataSet1PRINCIPAL: TFloatField
      DisplayLabel = #214'.P.'#399'sasdan'
      FieldName = 'PRINCIPAL'
    end
    object OracleDataSet1INTEREST: TFloatField
      DisplayLabel = #214'.P.Faizd'#601'n'
      FieldName = 'INTEREST'
    end
    object OracleDataSet1ODCEM: TFloatField
      DisplayLabel = 'C'#601'mi'
      FieldName = 'ODCEM'
    end
    object OracleDataSet1ODEMELI: TFloatField
      DisplayLabel = #214'd'#601'nilm'#601'li '#601'.b'
      FieldName = 'ODEMELI'
    end
    object OracleDataSet1PAYMENTDATE: TDateTimeField
      DisplayLabel = #214'd'#601'm'#601' tarixi'
      FieldName = 'PAYMENTDATE'
    end
    object OracleDataSet1EO: TFloatField
      DisplayLabel = 'Kr.'#399'sas'
      FieldName = 'EO'
    end
    object OracleDataSet1INTERESTREST: TFloatField
      DisplayLabel = 'Kr.Faiz'
      FieldName = 'INTERESTREST'
    end
    object OracleDataSet1PENALTYREST: TFloatField
      DisplayLabel = 'Penya'
      FieldName = 'PENALTYREST'
    end
    object OracleDataSet1CEM: TFloatField
      DisplayLabel = 'C'#601'mi'
      FieldName = 'CEM'
    end
    object OracleDataSet1PROQ: TFloatField
      DisplayLabel = 'Proqnoz faiz'
      FieldName = 'PROQ'
    end
    object OracleDataSet1VAL_NAME: TWideStringField
      DisplayLabel = 'Valyuta'
      FieldName = 'VAL_NAME'
      Size = 10
    end
    object OracleDataSet1PHONENUMBER: TWideStringField
      DisplayLabel = 'Telefonu'
      FieldName = 'PHONENUMBER'
      Size = 1020
    end
    object OracleDataSet1EXNAME: TWideStringField
      DisplayLabel = 'Kredit inspektoru'
      FieldName = 'EXNAME'
      Size = 320
    end
    object OracleDataSet1DATEOFGRANT: TDateTimeField
      DisplayLabel = 'Verilm'#601' tarixi'
      FieldName = 'DATEOFGRANT'
    end
    object OracleDataSet1MEHSUL_SHEXS: TWideStringField
      DisplayLabel = 'M'#601'sul '#351#601'xs'
      FieldName = 'MEHSUL_SHEXS'
      Size = 64
    end
  end
  object DataSource1: TDataSource
    DataSet = OracleDataSet2
    Left = 286
    Top = 128
  end
  object OracleDataSet2: TOracleDataSet
    SQL.Strings = (
      'select * from cm_expert')
    Optimize = False
    QBEDefinition.QBEFieldDefs = {
      050000000500000004000000490044000100000000000800000043004F004400
      4500010000000000080000004E0041004D004500010000000000100000004600
      49004C00490041004C00490044000100000000000A000000500048004F004E00
      4500010000000000}
    Cursor = crHourGlass
    Session = sboapiDataModule.SBSession
    Active = True
    OnCalcFields = ReservesCalcFields
    Left = 174
    Top = 120
    object OracleDataSet2ID: TFloatField
      FieldName = 'ID'
    end
    object OracleDataSet2CODE: TWideStringField
      FieldName = 'CODE'
      Size = 12
    end
    object OracleDataSet2NAME: TWideStringField
      FieldName = 'NAME'
      Size = 80
    end
    object OracleDataSet2FILIALID: TFloatField
      FieldName = 'FILIALID'
    end
  end
end
