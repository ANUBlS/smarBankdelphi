object FormReturns: TFormReturns
  Left = 0
  Top = 0
  Caption = 'ReturnTransactions'
  ClientHeight = 341
  ClientWidth = 652
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  Position = poDesktopCenter
  OnShow = FormShow
  PixelsPerInch = 96
  TextHeight = 13
  object DBGrid1: TDBGrid
    Left = 0
    Top = 0
    Width = 652
    Height = 341
    Align = alClient
    DataSource = CustAnalysDataModule.Returntransdata
    DrawingStyle = gdsGradient
    PopupMenu = PopupMenu1
    TabOrder = 0
    TitleFont.Charset = DEFAULT_CHARSET
    TitleFont.Color = clWindowText
    TitleFont.Height = -11
    TitleFont.Name = 'Tahoma'
    TitleFont.Style = []
    Columns = <
      item
        Expanded = False
        FieldName = 'BORROWERID'
        Title.Caption = 'Musteri '#8470
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'TRANSID'
        Visible = True
      end
      item
        Expanded = False
        FieldName = 'NAME'
        Visible = True
      end>
  end
  object PopupMenu1: TPopupMenu
    Left = 200
    Top = 136
    object mliyyatlvet1: TMenuItem
      Caption = #399'm'#601'liyyat'#305' l'#601#287'v et'
      OnClick = mliyyatlvet1Click
    end
  end
end
