object FilterForm: TFilterForm
  Left = 317
  Top = 165
  BorderIcons = [biSystemMenu]
  Caption = 'Filter'
  ClientHeight = 388
  ClientWidth = 430
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Azl Sans Serif'
  Font.Style = []
  KeyPreview = True
  OldCreateOrder = False
  Position = poScreenCenter
  OnCanResize = FormCanResize
  OnCreate = FormCreate
  OnDestroy = FormDestroy
  OnKeyPress = FormKeyPress
  PixelsPerInch = 96
  TextHeight = 14
  object Panel1: TPanel
    Left = 0
    Top = 0
    Width = 430
    Height = 388
    Align = alClient
    BevelInner = bvLowered
    TabOrder = 0
    object Panel2: TPanel
      Left = 2
      Top = 2
      Width = 161
      Height = 335
      Align = alLeft
      BevelInner = bvLowered
      TabOrder = 0
      object GroupBox2: TGroupBox
        Left = 2
        Top = 2
        Width = 157
        Height = 161
        Align = alTop
        Caption = 'Valyuta'
        TabOrder = 0
        object EvanescenceValute: TEvanescence
          Left = 2
          Top = 16
          Width = 153
          Height = 121
          Align = alTop
          Font.Charset = RUSSIAN_CHARSET
          Font.Color = clWindowText
          Font.Height = -12
          Font.Name = 'Tahoma'
          Font.Style = []
          ItemHeight = 14
          ParentFont = False
          TabOrder = 0
          DataSource = CustAnalysDataModule.CurrencysDataSource
          ListField = 'Valu_name'
          KeyField = 'Valute'
        end
        object CheckBoxValute: TCheckBox
          Left = 4
          Top = 138
          Width = 144
          Height = 18
          Caption = #1048#1089#1090#1080#1092#1072#1076#1103' '#1077#1090
          TabOrder = 1
        end
      end
      object GroupBox1: TGroupBox
        Left = 2
        Top = 163
        Width = 157
        Height = 160
        Align = alTop
        Caption = 'Filial'
        TabOrder = 1
        object EvanescenceFilial: TEvanescence
          Left = 2
          Top = 16
          Width = 153
          Height = 122
          Align = alTop
          Font.Charset = RUSSIAN_CHARSET
          Font.Color = clWindowText
          Font.Height = -12
          Font.Name = 'Tahoma'
          Font.Style = []
          ItemHeight = 14
          ParentFont = False
          TabOrder = 0
          DataSource = CustAnalysDataModule.FilialDataSource
          ListField = 'Name'
          KeyField = 'id'
        end
        object CheckBoxFilial: TCheckBox
          Left = 5
          Top = 139
          Width = 131
          Height = 18
          Caption = #1048#1089#1090#1080#1092#1072#1076#1103' '#1077#1090
          TabOrder = 1
        end
      end
    end
    object Panel3: TPanel
      Left = 163
      Top = 2
      Width = 265
      Height = 335
      Align = alClient
      BevelInner = bvLowered
      TabOrder = 1
      object GroupBox3: TGroupBox
        Left = 2
        Top = 281
        Width = 261
        Height = 57
        Align = alTop
        Caption = 'M'#1094#1096#1090#1103#1088#1080
        Font.Charset = RUSSIAN_CHARSET
        Font.Color = clWindowText
        Font.Height = -12
        Font.Name = 'Azl Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 0
        object DBLookupComEhCustomer: TDBLookupComboboxEh
          Left = 4
          Top = 17
          Width = 230
          Height = 22
          DropDownBox.Sizable = True
          EditButtons = <>
          Font.Charset = RUSSIAN_CHARSET
          Font.Color = clWindowText
          Font.Height = -12
          Font.Name = 'Tahoma'
          Font.Style = []
          KeyField = 'ID'
          ListField = 'NAME'
          ListSource = CustAnalysDataModule.CustomersDataSource
          ParentFont = False
          TabOrder = 0
          Visible = True
        end
        object CheckBoxCustomer: TCheckBox
          Left = 241
          Top = 23
          Width = 19
          Height = 18
          Caption = 'CheckBoxCustomer'
          TabOrder = 1
        end
      end
      object GroupBox4: TGroupBox
        Left = 2
        Top = 222
        Width = 261
        Height = 59
        Align = alTop
        Caption = 'Kreditin  tipi'
        Font.Charset = RUSSIAN_CHARSET
        Font.Color = clWindowText
        Font.Height = -12
        Font.Name = 'Azl Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 1
        object DBLookupComEhCredittype: TDBLookupComboboxEh
          Left = 4
          Top = 17
          Width = 230
          Height = 22
          DropDownBox.Sizable = True
          EditButtons = <>
          Font.Charset = RUSSIAN_CHARSET
          Font.Color = clWindowText
          Font.Height = -12
          Font.Name = 'Tahoma'
          Font.Style = []
          KeyField = 'ID'
          ListField = 'DESCRIPTION'
          ListSource = CustAnalysDataModule.CreditTypeDataSource
          ParentFont = False
          TabOrder = 0
          Visible = True
        end
        object CheckBoxCreditType: TCheckBox
          Left = 241
          Top = 20
          Width = 19
          Height = 19
          Caption = 'CheckBox3'
          TabOrder = 1
        end
      end
      object GroupBox5: TGroupBox
        Left = 2
        Top = 167
        Width = 261
        Height = 55
        Align = alTop
        Caption = 'Borclar'#1099'n  kategoriyas'#1099
        Font.Charset = RUSSIAN_CHARSET
        Font.Color = clWindowText
        Font.Height = -12
        Font.Name = 'Azl Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 2
        object DBLookupComEhCategories: TDBLookupComboboxEh
          Left = 4
          Top = 17
          Width = 230
          Height = 22
          DropDownBox.Sizable = True
          EditButtons = <>
          Font.Charset = RUSSIAN_CHARSET
          Font.Color = clWindowText
          Font.Height = -12
          Font.Name = 'Tahoma'
          Font.Style = []
          KeyField = 'ID'
          ListField = 'DESCRIPTION'
          ListSource = CustAnalysDataModule.CategoriesDataSource
          ParentFont = False
          TabOrder = 0
          Visible = True
        end
        object CheckBoxCategories: TCheckBox
          Left = 241
          Top = 22
          Width = 19
          Height = 18
          Caption = 'CheckBox3'
          TabOrder = 1
        end
      end
      object GroupBox6: TGroupBox
        Left = 2
        Top = 112
        Width = 261
        Height = 55
        Align = alTop
        Caption = 'Istifad'#1103#1095'i grupu'
        Font.Charset = RUSSIAN_CHARSET
        Font.Color = clWindowText
        Font.Height = -12
        Font.Name = 'Azl Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 3
        object DBLookupComEhUsersGroup: TDBLookupComboboxEh
          Left = 5
          Top = 20
          Width = 230
          Height = 22
          DropDownBox.Sizable = True
          EditButtons = <>
          Font.Charset = RUSSIAN_CHARSET
          Font.Color = clWindowText
          Font.Height = -12
          Font.Name = 'Tahoma'
          Font.Style = []
          KeyField = 'ID'
          ListField = 'DESCRIPTION'
          ListSource = CustAnalysDataModule.UserGroupsDataSource
          ParentFont = False
          TabOrder = 0
          Visible = True
        end
        object CheckBoxUsersgroup: TCheckBox
          Left = 239
          Top = 22
          Width = 18
          Height = 18
          Caption = 'CheckBox3'
          TabOrder = 1
        end
      end
      object GroupBox7: TGroupBox
        Left = 2
        Top = 60
        Width = 261
        Height = 52
        Align = alTop
        Caption = #1048#1089#1090#1080#1092#1072#1076#1103#1095#1080
        Font.Charset = RUSSIAN_CHARSET
        Font.Color = clWindowText
        Font.Height = -12
        Font.Name = 'Azl Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 4
        object DBLookupComEhUsers: TDBLookupComboboxEh
          Left = 4
          Top = 15
          Width = 230
          Height = 22
          DropDownBox.Sizable = True
          EditButtons = <>
          Font.Charset = RUSSIAN_CHARSET
          Font.Color = clWindowText
          Font.Height = -12
          Font.Name = 'Tahoma'
          Font.Style = []
          KeyField = 'ID'
          ListField = 'NAME'
          ListSource = CustAnalysDataModule.UsersDataSource
          ParentFont = False
          TabOrder = 0
          Visible = True
        end
        object CheckBoxUsers: TCheckBox
          Left = 241
          Top = 22
          Width = 19
          Height = 18
          Caption = 'CheckBox3'
          TabOrder = 1
        end
      end
      object GroupBox8: TGroupBox
        Left = 2
        Top = 2
        Width = 261
        Height = 58
        Align = alTop
        Caption = 'Borclar'#1099#1085'  '#1090#1080#1087#1080
        Font.Charset = RUSSIAN_CHARSET
        Font.Color = clWindowText
        Font.Height = -12
        Font.Name = 'Azl Sans Serif'
        Font.Style = []
        ParentFont = False
        TabOrder = 5
        object DBLookupComEhPersons: TDBLookupComboboxEh
          Left = 4
          Top = 17
          Width = 230
          Height = 22
          DropDownBox.Options = [dlgColumnResizeEh, dlgColLinesEh]
          DropDownBox.Sizable = True
          EditButtons = <>
          Font.Charset = RUSSIAN_CHARSET
          Font.Color = clWindowText
          Font.Height = -12
          Font.Name = 'Tahoma'
          Font.Style = []
          KeyField = 'ID'
          ListField = 'DESCRIPION'
          ListSource = CustAnalysDataModule.PersonsDataSource
          ParentFont = False
          TabOrder = 0
          Visible = True
        end
        object CheckBoxPersons: TCheckBox
          Left = 239
          Top = 22
          Width = 18
          Height = 18
          Caption = 'CheckBox3'
          TabOrder = 1
        end
      end
    end
    object Panel4: TPanel
      Left = 2
      Top = 337
      Width = 426
      Height = 49
      Align = alBottom
      BevelInner = bvLowered
      TabOrder = 2
      object SpeedButton1: TSpeedButton
        Left = 163
        Top = 15
        Width = 77
        Height = 30
        Action = ActionFlterAccept
        Caption = 'T'#1103#1089#1076#1080#1075
        Font.Charset = RUSSIAN_CHARSET
        Font.Color = clWindowText
        Font.Height = -12
        Font.Name = 'Azl Sans Serif'
        Font.Style = []
        Glyph.Data = {
          F6000000424DF600000000000000760000002800000010000000100000000100
          0400000000008000000000000000000000001000000000000000000000000000
          8000008000000080800080000000800080008080000080808000C0C0C0000000
          FF0000FF000000FFFF00FF000000FF00FF00FFFF0000FFFFFF00FFFFFFFFFFFF
          FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF0FFFFFFFFFFFFFF000FFF
          FFFFFFFFFF0F0FFFFFFFFFFFF00F00FFFFFFFFFF00FFF0FFFFFFFFFFFFFFF00F
          FFFFFFFFFFFFFF0FFFFFFFFFFFFFFF00FFFFFFFFFFFFFFF0FFFFFFFFFFFFFFF0
          FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF}
        ParentFont = False
      end
      object SpeedButton2: TSpeedButton
        Left = 251
        Top = 15
        Width = 77
        Height = 30
        Action = ActionFilterReject
        Caption = 'Imtina'
        Glyph.Data = {
          36050000424D3605000000000000360400002800000010000000100000000100
          08000000000000010000CE0E0000D80E00000001000000000000000000008080
          8000000080000080800000800000808000008000000080008000408080004040
          0000FF80000080400000FF00400000408000FFFFFF00C0C0C0000000FF0000FF
          FF0000FF0000FFFF0000FF000000FF00FF0080FFFF0080FF0000FFFF8000FF80
          80008000FF004080FF00C0DCC000F0CAA6000008000000000800000808000804
          00000800080008080800130E0800040314001008100010101000151414001311
          1F002525210018133F004E0C11004D1D0F00681C1000561D21006B1C21004A3B
          36005655560077141800741324008F0E2200940F30008818230084292300893C
          400011097E004C4B75005A6B6300666666005A73630065706D00736D6D007373
          73007878730073737B0077777B00945D670096706D007B7B7B00837B8100947B
          73009C7B730084847B008484840084848C0090878700948C8E00948C94008C94
          9400949494009C9494009C9C940094949C009C949C009C9C9C00A80F2300AD18
          2900A9083100A5143500AF102B00AD0C3900BC072B00C10D3600AD1E2900A82C
          2700AD183900A9293100BE1B2900BD183100C01F3100B2154200A9213900B121
          3D00B5214200AB2C3900A9294200A92F4600BB1B4000B5294200BD293900B929
          4600C7184200CC253E00C1254A00CF254E00AC3F3200AB3F4200AE354A00AD4A
          4200C1383D00C6314A00CE314A00BD394A00AD3D4F00BD355200AD475000BD42
          5200C8395100C1425A00CC3F5E00B3524200B5525300B54E5E00B85C5B00C654
          5000D95F5100F6624600B2606A00C15A6B00CC586500CC5D6F00B7848300DD7C
          6E00E89889000C08B5000D0DE1001010EF000000F7000808F7000D0DFC001B1B
          ED003A3AE2002222FB003939FF006E6ECD005656FF007777FF009494A5009C9C
          A500A59CA500A5A5A500ADA5A5009494AD00A5A5AD00ADA5AD00A5A7B500A0A0
          C6009B9BDB008C8CFF009494FF009C9CFF00A5A5FF00B5A5A500BDA5A500B5AD
          A500BDADA500ADADAD00B5ADAD00B5B5AD00B1ADB500C6A7AA00C9B1AE00D6B1
          A900EDB0A900FFAFA200FFB5AD00FFBDAD00B5B5B500BDB5B500BDBDB500ADAD
          BD00B9B5BD00B3B3DB00B1B1FF00C1B9B900BDBDC600CBBBBA00E5BBB700C6C6
          C600DABDC600C1C1D600BDBDFF00D6C6C600DEC6C600CEC6CE00D6C6CE00DEC6
          CE00CECECE00D6CECE00D6D6CE00D2CED600D6D6D600DECECE00DECED600DED6
          D600D6D6DE00DED6DE00F4C8BE00F0CFCB00FFD6C600E7CED600E7D6D600F1D3
          D600FFD6CE00DEDEDE00E7DED600E7E7D600EBD6DE00E7DEDE00FFD6D600FFDE
          D600D2D2EF00C6C6FF00CECEFF00D6D6FF00DEDEE700DEDEFF00E7DEE700E7E7
          E700E7E7FF00EFDEDE00EFE7E700EFE7EF00F7E7E700FFDEDE00FFE7DE00FFE7
          E700EFEFEF00EFEFFF00F7EFEF00F7EFF700FFEFE700FFEFEF000F0F01010F0F
          0F0F0F0F0F0F0F0F0F0F0F100202010F0F0F0F0F10010F0F0F0F0F1002020201
          0F0F0F100202010F0F0F0F1002020202010F1002020202010F0F0F0F10020202
          02010202020202010F0F0F0F0F100202020202020202010F0F0F0F0F0F0F1002
          0202020202010F0F0F0F0F0F0F0F0F0202020202010F0F0F0F0F0F0F0F0F0F10
          02020202010F0F0F0F0F0F0F0F0F100202020202010F0F0F0F0F0F0F0F100202
          0201020202010F0F0F0F0F0F10020202010F10020202010F0F0F0F0F10020201
          0F0F0F10020202010F0F0F0F0F10020F0F0F0F0F100202020F0F0F0F0F0F0F0F
          0F0F0F0F0F1002100F0F0F0F0F0F0F0F0F0F0F0F0F0F0F0F0F0F}
      end
      object SpeedButton3: TSpeedButton
        Left = 345
        Top = 15
        Width = 77
        Height = 30
        Caption = ' '#1041#1072#1100#1083#1072
        Font.Charset = RUSSIAN_CHARSET
        Font.Color = clWindowText
        Font.Height = -12
        Font.Name = 'Azl Sans Serif'
        Font.Style = []
        Glyph.Data = {
          36030000424D3603000000000000360000002800000010000000100000000100
          1800000000000003000000000000000000000000000000000000FFFFFFFFFFFF
          FFFFFFFFFFFFFFFFFF404040606060808080808080808080606060404040FFFF
          FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF20202020206020209F0000BF00
          00BF0000BF20209F404080808080606060202020FFFFFFFFFFFFFFFFFFFFFFFF
          00002020209F0000FF0000FF0000FF0000FF0000FF0000FF0000FF20209F6060
          80808080202020FFFFFFFFFFFF0000200000DF0000FF0000FF0000FF0000FF00
          00FF0000FF0000FF0000FF0000FF0000DF606080606060FFFFFFFFFFFF00007F
          0000FF0000FF3F3FFF0000FF0000FF0000FF0000FF0000FF3F3FFF0000FF0000
          FF20209F8080804040400000400000FF0000FF3F3FFFFFFFFFBFBFFF0000FF00
          00FF0000FFBFBFFFFFFFFF3F3FFF0000FF0000FF40408060606000007F0000FF
          0000FF0000FFBFBFFFFFFFFFBFBFFF0000FFBFBFFFFFFFFFBFBFFF0000FF0000
          FF0000FF20209F8080800000BF0000FF0000FF0000FF0000FFBFBFFFFFFFFFFF
          FFFFFFFFFFBFBFFF0000FF0000FF0000FF0000FF0000BF8080800000BF0000FF
          0000FF0000FF0000FF0000FFFFFFFFFFFFFFFFFFFF0000FF0000FF0000FF0000
          FF0000FF0000BF8080800000BF0000FF0000FF0000FF0000FFBFBFFFFFFFFFFF
          FFFFFFFFFFBFBFFF0000FF0000FF0000FF0000FF0000BF60606000007F0000FF
          0000FF0000FFBFBFFFFFFFFFBFBFFF0000FFBFBFFFFFFFFFBFBFFF0000FF0000
          FF0000FF20209F4040400000400000FF0000FF3F3FFFFFFFFFBFBFFF0000FF00
          00FF0000FFBFBFFFFFFFFF3F3FFF0000FF0000FF202060FFFFFFFFFFFF00007F
          0000FF0000FF3F3FFF0000FF0000FF0000FF0000FF0000FF3F3FFF0000FF0000
          FF20209F202020FFFFFFFFFFFF0000200000DF0000FF0000FF0000FF0000FF00
          00FF0000FF0000FF0000FF0000FF0000DF000020FFFFFFFFFFFFFFFFFFFFFFFF
          00002000007F0000FF0000FF0000FF0000FF0000FF0000FF0000FF00007F0000
          20FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF00004000007F0000BF00
          00BF0000BF00007F000040FFFFFFFFFFFFFFFFFFFFFFFFFFFFFF}
        ParentFont = False
        OnClick = SpeedButton3Click
      end
    end
  end
  object ActionList1: TActionList
    Left = 74
    Top = 307
    object ActionFlterAccept: TAction
      Caption = 'ActionFlterAccept'
      OnExecute = ActionFlterAcceptExecute
    end
    object ActionFilterReject: TAction
      Caption = 'ActionFilterReject'
      OnExecute = ActionFilterRejectExecute
    end
  end
end
