object frmBCFilter: TfrmBCFilter
  Left = 735
  Top = 224
  ClientHeight = 468
  ClientWidth = 649
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Azl Sans Serif'
  Font.Style = []
  KeyPreview = True
  OldCreateOrder = False
  Position = poMainFormCenter
  OnCanResize = FormCanResize
  OnCreate = FormCreate
  PixelsPerInch = 96
  TextHeight = 13
  object Panel1: TPanel
    Left = 0
    Top = 0
    Width = 649
    Height = 62
    Align = alTop
    BevelInner = bvRaised
    BevelOuter = bvLowered
    TabOrder = 0
    object GroupBox1: TGroupBox
      Left = 2
      Top = 2
      Width = 208
      Height = 58
      Align = alLeft
      Caption = #1042#1072#1083#1081#1091#1090#1072
      TabOrder = 0
      object CheckBox1: TCheckBox
        Left = 5
        Top = 38
        Width = 97
        Height = 17
        Caption = #1058#1103#1090#1073#1080#1075' '#1077#1090
        TabOrder = 0
      end
      object DBLookupComboboxEh1: TDBLookupComboboxEh
        Left = 5
        Top = 14
        Width = 195
        Height = 21
        DropDownBox.Sizable = True
        EditButtons = <>
        KeyField = 'VALUTE'
        ListField = 'VALU_NAME'
        ListSource = DSCurrencys
        TabOrder = 1
        Visible = True
      end
    end
    object GroupBox2: TGroupBox
      Left = 426
      Top = 2
      Width = 221
      Height = 58
      Align = alClient
      Caption = #1048#1089#1090#1080#1092#1072#1076#1103#1095#1080' '#1075#1088#1091#1087#1091
      TabOrder = 1
      object DBLookupComboboxEh3: TDBLookupComboboxEh
        Left = 5
        Top = 14
        Width = 204
        Height = 21
        DropDownBox.Sizable = True
        EditButtons = <>
        KeyField = 'ID'
        ListField = 'DESCRIPTION'
        ListSource = DSUserGroups
        TabOrder = 0
        Visible = True
      end
      object CheckBox3: TCheckBox
        Left = 5
        Top = 38
        Width = 97
        Height = 15
        Caption = #1058#1103#1090#1073#1080#1075' '#1077#1090
        TabOrder = 1
      end
    end
    object GroupBox3: TGroupBox
      Left = 210
      Top = 2
      Width = 216
      Height = 58
      Align = alLeft
      Caption = #1060#1080#1083#1080#1072#1083
      TabOrder = 2
      object DBLookupComboboxEh2: TDBLookupComboboxEh
        Left = 5
        Top = 14
        Width = 204
        Height = 21
        DropDownBox.Sizable = True
        EditButtons = <>
        KeyField = 'ID'
        ListField = 'NAME'
        ListSource = DSBranches
        TabOrder = 0
        Visible = True
      end
      object CheckBox2: TCheckBox
        Left = 6
        Top = 38
        Width = 97
        Height = 17
        Caption = #1058#1103#1090#1073#1080#1075' '#1077#1090
        TabOrder = 1
      end
    end
  end
  object Panel5: TPanel
    Left = 0
    Top = 62
    Width = 649
    Height = 60
    Align = alTop
    BevelInner = bvRaised
    BevelOuter = bvLowered
    TabOrder = 1
    object GroupBox7: TGroupBox
      Left = 2
      Top = 2
      Width = 208
      Height = 56
      Align = alLeft
      Caption = #1041#1086#1088#1078#1072#1083#1072#1085#1099#1085' '#1090#1080#1087#1080
      TabOrder = 0
      object CheckBox7: TCheckBox
        Left = 5
        Top = 37
        Width = 97
        Height = 17
        Caption = #1058#1103#1090#1073#1080#1075' '#1077#1090
        TabOrder = 0
      end
      object DBLookupComboboxEh7: TDBLookupComboboxEh
        Left = 5
        Top = 14
        Width = 195
        Height = 21
        DropDownBox.Sizable = True
        EditButtons = <>
        KeyField = 'ID'
        ListField = 'DESCRIPION'
        ListSource = DSPersons
        TabOrder = 1
        Visible = True
      end
    end
    object GroupBox9: TGroupBox
      Left = 210
      Top = 2
      Width = 216
      Height = 56
      Align = alLeft
      Caption = 'Kreditin tipi'
      TabOrder = 1
      object CheckBox8: TCheckBox
        Left = 5
        Top = 37
        Width = 97
        Height = 17
        Caption = #1058#1103#1090#1073#1080#1075' '#1077#1090
        TabOrder = 0
      end
      object DBLookupComboboxEh8: TDBLookupComboboxEh
        Left = 5
        Top = 14
        Width = 204
        Height = 21
        DropDownBox.Sizable = True
        EditButtons = <>
        KeyField = 'ID'
        ListField = 'DESCRIPTION'
        ListSource = DSCategories
        TabOrder = 1
        Visible = True
      end
    end
    object GroupBox13: TGroupBox
      Left = 426
      Top = 2
      Width = 216
      Height = 56
      Align = alLeft
      Caption = #1042#1077#1088#1080#1083#1084#1103' '#1087#1077#1088#1080#1086#1076#1091
      TabOrder = 2
      object CheckBox11: TCheckBox
        Left = 5
        Top = 37
        Width = 97
        Height = 17
        Caption = #1058#1103#1090#1073#1080#1075' '#1077#1090
        TabOrder = 0
      end
      object DBLookupComboboxEh9: TDBLookupComboboxEh
        Left = 5
        Top = 14
        Width = 204
        Height = 21
        DropDownBox.Sizable = True
        EditButtons = <>
        KeyField = 'ID'
        ListField = 'PURPOSEDESC'
        ListSource = DSPeriods
        TabOrder = 1
        Visible = True
      end
    end
  end
  object Panel2: TPanel
    Left = 0
    Top = 186
    Width = 649
    Height = 63
    Align = alTop
    BevelInner = bvRaised
    BevelOuter = bvLowered
    TabOrder = 2
    object GroupBox6: TGroupBox
      Left = 209
      Top = 2
      Width = 173
      Height = 59
      Align = alLeft
      Caption = #1052#1094#1096#1090#1103#1088#1080
      TabOrder = 0
      DesignSize = (
        173
        59)
      object CheckBox5: TCheckBox
        Left = 5
        Top = 38
        Width = 72
        Height = 17
        Caption = #1058#1103#1090#1073#1080#1075' '#1077#1090
        TabOrder = 0
        OnClick = CheckBox5Click
      end
      object DBLookupComboboxEh4: TDBLookupComboboxEh
        Left = 5
        Top = 14
        Width = 161
        Height = 21
        Anchors = [akLeft, akTop, akRight]
        DropDownBox.Sizable = True
        EditButtons = <>
        KeyField = 'ID'
        ListField = 'IDNAME'
        ListSource = DSCustName
        TabOrder = 1
        Visible = True
      end
    end
    object GroupBox8: TGroupBox
      Left = 2
      Top = 2
      Width = 207
      Height = 59
      Align = alLeft
      Caption = 'Rayon'
      TabOrder = 1
      DesignSize = (
        207
        59)
      object CheckBox6: TCheckBox
        Left = 5
        Top = 38
        Width = 97
        Height = 17
        Caption = #1058#1103#1090#1073#1080#1075' '#1077#1090
        TabOrder = 0
      end
      object DBLookupComboboxEh5: TDBLookupComboboxEh
        Left = 5
        Top = 14
        Width = 195
        Height = 21
        Anchors = [akLeft, akTop, akRight]
        DropDownBox.Sizable = True
        EditButtons = <>
        KeyField = 'ID'
        ListField = 'IDNAME'
        ListSource = DSDistricts
        TabOrder = 1
        Visible = True
      end
    end
    object GroupBox10: TGroupBox
      Left = 382
      Top = 2
      Width = 150
      Height = 59
      Align = alClient
      Caption = #1052#1094#1096#1090#1103#1088#1080' '#1082#1086#1076#1091
      TabOrder = 2
      DesignSize = (
        150
        59)
      object CheckBox9: TCheckBox
        Left = 5
        Top = 38
        Width = 72
        Height = 17
        Caption = #1058#1103#1090#1073#1080#1075' '#1077#1090
        TabOrder = 0
        OnClick = CheckBox5Click
      end
      object DBLookupComboboxEh6: TDBLookupComboboxEh
        Left = 5
        Top = 14
        Width = 144
        Height = 21
        Anchors = [akLeft, akTop, akRight]
        DropDownBox.Sizable = True
        EditButtons = <>
        KeyField = 'ID'
        ListField = 'IDNAME'
        ListSource = DSCustomers
        TabOrder = 1
        Visible = True
      end
    end
    object GroupBox11: TGroupBox
      Left = 532
      Top = 2
      Width = 115
      Height = 59
      Align = alRight
      Caption = #1065#1077#1089#1072#1073#1072#1090
      TabOrder = 3
      DesignSize = (
        115
        59)
      object CheckBox10: TCheckBox
        Left = 5
        Top = 38
        Width = 72
        Height = 17
        Caption = #1058#1103#1090#1073#1080#1075' '#1077#1090
        Checked = True
        Enabled = False
        State = cbChecked
        TabOrder = 0
        OnClick = CheckBox5Click
      end
      object cbFormsLook: TDBLookupComboboxEh
        Left = 3
        Top = 12
        Width = 103
        Height = 21
        Anchors = [akLeft, akTop, akRight]
        DropDownBox.Sizable = True
        EditButtons = <>
        KeyField = 'ID'
        ListField = 'NAME'
        ListSource = DSRepForms
        TabOrder = 1
        Visible = True
        OnChange = cbFormsLookChange
      end
    end
  end
  object Panel3: TPanel
    Left = 0
    Top = 310
    Width = 649
    Height = 63
    Align = alTop
    BevelInner = bvRaised
    BevelOuter = bvLowered
    TabOrder = 3
    object RGReportType: TRadioGroup
      Left = 297
      Top = 2
      Width = 182
      Height = 59
      Align = alClient
      Caption = 'Hesabat'
      ItemIndex = 0
      Items.Strings = (
        'Excel'
        'Hesabat')
      TabOrder = 0
    end
    object rgPR: TRadioGroup
      Left = 162
      Top = 2
      Width = 135
      Height = 59
      Align = alLeft
      Caption = #1069#1077#1078#1080#1082#1084#1103#1083#1103#1088#1080' '#1089#1072#1081#1084#1072#1075
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -11
      Font.Name = 'Azl Sans Serif'
      Font.Style = []
      ItemIndex = 0
      Items.Strings = (
        'QALIQLAR '#1094#1079#1088#1103
        #1057#1061#1045#1052' '#1094#1079#1088#1103)
      ParentFont = False
      TabOrder = 1
    end
    object GroupBox5: TGroupBox
      Left = 2
      Top = 2
      Width = 160
      Height = 59
      Align = alLeft
      Caption = #1063#1072#1087' '#1076#1103#1088#1080#1085#1083#1080#1081#1080
      TabOrder = 2
      object cbPrintDeep: TComboBox
        Left = 4
        Top = 16
        Width = 145
        Height = 21
        Style = csDropDownList
        DropDownCount = 4
        TabOrder = 0
        Items.Strings = (
          'M'#252#351't'#601'ri'
          'K'#601'nd'
          'Rayon'
          'Filial'
          'Sah'#601'l'#601'r'
          'M'#601'hsullar')
      end
      object CheckBox4: TCheckBox
        Left = 4
        Top = 38
        Width = 97
        Height = 17
        Caption = #1058#1103#1090#1073#1080#1075' '#1077#1090
        TabOrder = 1
      end
    end
    object rgKredStatus: TRadioGroup
      Left = 479
      Top = 2
      Width = 168
      Height = 59
      Align = alRight
      Caption = 'Kre'#1076'itl'#1103'r'
      ItemIndex = 0
      Items.Strings = (
        'Aktiv olanlar'
        'Ham'#1099's'#1099)
      TabOrder = 3
    end
  end
  object Panel4: TPanel
    Left = 0
    Top = 432
    Width = 649
    Height = 36
    Align = alBottom
    BevelInner = bvRaised
    BevelOuter = bvLowered
    TabOrder = 4
    object Button1: TButton
      Left = 323
      Top = 5
      Width = 75
      Height = 25
      Caption = #1043#1103#1073#1091#1083
      TabOrder = 0
      OnClick = Button1Click
    end
    object btnYeniden: TButton
      Left = 404
      Top = 5
      Width = 75
      Height = 24
      Caption = #1049#1077#1085#1080#1076#1103#1085
      TabOrder = 1
      OnClick = btnYenidenClick
    end
    object Button2: TButton
      Left = 563
      Top = 5
      Width = 75
      Height = 24
      Caption = #1041#1072#1100#1083#1072
      ModalResult = 2
      TabOrder = 2
    end
    object btnAll: TButton
      Left = 485
      Top = 5
      Width = 74
      Height = 24
      Caption = #1062#1084#1091#1084#1080
      TabOrder = 3
      OnClick = btnAllClick
    end
    object Button3: TButton
      Left = 98
      Top = 7
      Width = 112
      Height = 24
      Caption = 'T'#252't'#252'n,pamb'#305'q,qar'#287'dal'#305
      TabOrder = 4
      OnClick = Button3Click
    end
    object BitBtn1: TBitBtn
      Left = 389
      Top = -15
      Width = 70
      Height = 23
      Caption = 'BitBtn1'
      DoubleBuffered = True
      ParentDoubleBuffered = False
      TabOrder = 5
      Visible = False
      OnClick = BitBtn1Click
    end
    object Button4: TButton
      Left = 6
      Top = 7
      Width = 94
      Height = 24
      Cursor = crHourGlass
      Caption = 'Y'#246'n'#601'ltm'#601' hesabat'#305
      TabOrder = 6
      OnClick = Button4Click
    end
    object Button5: TButton
      Left = 230
      Top = 6
      Width = 70
      Height = 24
      Caption = 'Ipoteka'
      TabOrder = 7
      OnClick = Button5Click
    end
  end
  object Panel6: TPanel
    Left = 0
    Top = 122
    Width = 649
    Height = 64
    Align = alTop
    BevelInner = bvRaised
    BevelOuter = bvLowered
    TabOrder = 5
    object GroupBox4: TGroupBox
      Left = 2
      Top = 2
      Width = 183
      Height = 60
      Align = alLeft
      Caption = #1065#1077#1089#1072#1073#1072#1090' '#1072#1088#1072#1083#1099#1100#1099
      TabOrder = 0
      DesignSize = (
        183
        60)
      object Label1: TLabel
        Left = 8
        Top = 16
        Width = 66
        Height = 13
        Caption = #1044#1102#1074#1088#1094#1085' '#1103#1074#1074#1103#1083#1080
      end
      object Label2: TLabel
        Left = 8
        Top = 38
        Width = 61
        Height = 13
        Caption = #1044#1102#1074#1088#1094#1085' '#1089#1086#1085#1091
      end
      object BDateP: TDateTimePicker
        Left = 83
        Top = 12
        Width = 94
        Height = 21
        Anchors = [akLeft, akTop, akRight]
        Date = 38477.593060798600000000
        Time = 38477.593060798600000000
        TabOrder = 0
      end
      object EDateP: TDateTimePicker
        Left = 83
        Top = 34
        Width = 94
        Height = 21
        Anchors = [akLeft, akTop, akRight]
        Date = 38477.593068935200000000
        Time = 38477.593068935200000000
        TabOrder = 1
      end
    end
    object GroupBox12: TGroupBox
      Left = 185
      Top = 2
      Width = 144
      Height = 60
      Align = alLeft
      Caption = #1042#1077#1088#1080#1083#1084#1080#1096' '#1082#1088#1077#1076#1080#1090#1083#1103#1088
      TabOrder = 1
      DesignSize = (
        144
        60)
      object Label3: TLabel
        Left = 104
        Top = 16
        Width = 21
        Height = 13
        Caption = '-'#1076#1072#1085
      end
      object Label4: TLabel
        Left = 104
        Top = 37
        Width = 21
        Height = 13
        Caption = '-'#1076#1103#1082
      end
      object GCredBegD: TDateTimePicker
        Left = 6
        Top = 12
        Width = 95
        Height = 21
        Anchors = [akLeft, akTop, akRight]
        Date = 35431.593060798600000000
        Time = 35431.593060798600000000
        TabOrder = 0
      end
      object GCredEndD: TDateTimePicker
        Left = 6
        Top = 34
        Width = 95
        Height = 21
        Anchors = [akLeft, akTop, akRight]
        Date = 38477.593068935200000000
        Time = 38477.593068935200000000
        TabOrder = 1
      end
    end
    object GroupBox14: TGroupBox
      Left = 329
      Top = 2
      Width = 144
      Height = 60
      Align = alLeft
      Caption = #1057#1090#1072#1090#1091#1089#1091
      TabOrder = 2
      DesignSize = (
        144
        60)
      object CheckBox12: TCheckBox
        Left = 5
        Top = 37
        Width = 97
        Height = 17
        Caption = #1058#1103#1090#1073#1080#1075' '#1077#1090
        TabOrder = 0
      end
      object DBLookupComboboxEh10: TDBLookupComboboxEh
        Left = 5
        Top = 14
        Width = 132
        Height = 21
        Anchors = [akLeft, akTop, akRight]
        DropDownBox.Sizable = True
        EditButtons = <>
        KeyField = 'ID'
        ListField = 'STATNAME'
        ListSource = DSStatuses
        TabOrder = 1
        Visible = True
      end
    end
    object GroupBox19: TGroupBox
      Left = 473
      Top = 2
      Width = 168
      Height = 60
      Align = alLeft
      Caption = #1058#1077#1093#1085#1080#1082#1072#1085#1099#1085' '#1090#1080#1087#1080
      TabOrder = 3
      DesignSize = (
        168
        60)
      object CheckBox17: TCheckBox
        Left = 5
        Top = 37
        Width = 97
        Height = 17
        Caption = #1058#1103#1090#1073#1080#1075' '#1077#1090
        TabOrder = 0
      end
      object DBLookupComboboxEh13: TDBLookupComboboxEh
        Left = 5
        Top = 14
        Width = 156
        Height = 21
        Anchors = [akLeft, akTop, akRight]
        DropDownBox.Sizable = True
        EditButtons = <>
        KeyField = 'ID'
        ListField = 'NAME'
        ListSource = DSGType
        TabOrder = 1
        Visible = True
      end
    end
  end
  object Panel7: TPanel
    Left = 0
    Top = 249
    Width = 649
    Height = 61
    Align = alTop
    BevelInner = bvRaised
    BevelOuter = bvLowered
    TabOrder = 6
    object GroupBox15: TGroupBox
      Left = 209
      Top = 2
      Width = 144
      Height = 57
      Align = alLeft
      Caption = #1060#1072#1080#1079' '#1075#1086#1081#1091#1083#1091#1096#1091
      TabOrder = 0
      object Label5: TLabel
        Left = 64
        Top = 16
        Width = 5
        Height = 20
        Caption = '-'
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -16
        Font.Name = 'Azl Sans Serif'
        Font.Style = []
        ParentFont = False
      end
      object CheckBox13: TCheckBox
        Left = 5
        Top = 38
        Width = 97
        Height = 17
        Caption = #1058#1103#1090#1073#1080#1075' '#1077#1090
        TabOrder = 0
      end
      object fsm: TCMCurrencyEdit
        Left = 5
        Top = 16
        Width = 52
        Height = 21
        TabOrder = 1
        Text = '0'
      end
      object fsx: TCMCurrencyEdit
        Left = 77
        Top = 16
        Width = 52
        Height = 21
        TabOrder = 2
        Text = '100'
        Value = 100.000000000000000000
      end
    end
    object GroupBox16: TGroupBox
      Left = 2
      Top = 2
      Width = 83
      Height = 57
      Align = alLeft
      Caption = #1052#1094#1076#1076#1103#1090#1080
      TabOrder = 1
      DesignSize = (
        83
        57)
      object CheckBox14: TCheckBox
        Left = 5
        Top = 38
        Width = 97
        Height = 17
        Caption = #1058#1103#1090#1073#1080#1075' '#1077#1090
        TabOrder = 0
      end
      object DBLookupComboboxEh12: TDBLookupComboboxEh
        Left = 5
        Top = 14
        Width = 71
        Height = 21
        Anchors = [akLeft, akTop, akRight]
        DropDownBox.Sizable = True
        EditButtons = <>
        KeyField = 'ID'
        ListField = 'IDNAME'
        ListSource = DSTypes
        TabOrder = 1
        Visible = True
      end
    end
    object GroupBox17: TGroupBox
      Left = 353
      Top = 2
      Width = 294
      Height = 57
      Align = alClient
      Caption = #1053#1103#1079#1103#1088#1076#1103' '#1090#1091#1090#1091#1083#1072#1085' '#1084#1103#1073#1083#1103#1100
      TabOrder = 2
      object Label6: TLabel
        Left = 128
        Top = 16
        Width = 5
        Height = 20
        Caption = '-'
        Font.Charset = DEFAULT_CHARSET
        Font.Color = clWindowText
        Font.Height = -16
        Font.Name = 'Azl Sans Serif'
        Font.Style = []
        ParentFont = False
      end
      object CheckBox15: TCheckBox
        Left = 5
        Top = 38
        Width = 97
        Height = 17
        Caption = #1058#1103#1090#1073#1080#1075' '#1077#1090
        TabOrder = 0
      end
      object ntmm: TCMCurrencyEdit
        Left = 5
        Top = 16
        Width = 116
        Height = 21
        TabOrder = 1
        Text = '0'
      end
      object ntmx: TCMCurrencyEdit
        Left = 141
        Top = 16
        Width = 140
        Height = 21
        TabOrder = 2
        Text = '1000000000'
        Value = 1000000000.000000000000000000
      end
    end
    object GroupBox18: TGroupBox
      Left = 85
      Top = 2
      Width = 124
      Height = 57
      Align = alLeft
      Caption = 'Q'#1103'rar'
      TabOrder = 3
      DesignSize = (
        124
        57)
      object CheckBox16: TCheckBox
        Left = 5
        Top = 38
        Width = 97
        Height = 17
        Caption = #1058#1103#1090#1073#1080#1075' '#1077#1090
        TabOrder = 0
      end
      object DBLookupComboboxEh11: TDBLookupComboboxEh
        Left = 5
        Top = 14
        Width = 112
        Height = 21
        Anchors = [akLeft, akTop, akRight]
        DropDownBox.Sizable = True
        EditButtons = <>
        KeyField = 'ID'
        ListField = 'SHORT'
        ListSource = DSShort
        TabOrder = 1
        Visible = True
      end
    end
  end
  object GroupBox20: TGroupBox
    Left = 0
    Top = 373
    Width = 210
    Height = 59
    Align = alLeft
    Caption = #1048#1082#1090#1080#1089#1072#1076#1080' '#1079#1086#1085#1072
    TabOrder = 7
    DesignSize = (
      210
      59)
    object CheckBox18: TCheckBox
      Left = 5
      Top = 38
      Width = 72
      Height = 17
      Caption = #1058#1103#1090#1073#1080#1075' '#1077#1090
      TabOrder = 0
      OnClick = CheckBox5Click
    end
    object DBLookupComboboxEh14: TDBLookupComboboxEh
      Left = 5
      Top = 14
      Width = 198
      Height = 21
      Anchors = [akLeft, akTop, akRight]
      DropDownBox.Sizable = True
      EditButtons = <>
      KeyField = 'ID'
      ListField = 'NAME'
      ListSource = zonaSrc
      TabOrder = 1
      Visible = True
    end
  end
  object GroupBox21: TGroupBox
    Left = 210
    Top = 373
    Width = 210
    Height = 59
    Align = alLeft
    Caption = #1060#1103#1072#1083#1080#1081#1081#1103#1090' '#1082#1072#1090#1077#1075#1086#1088#1080#1081#1072#1089#1099
    TabOrder = 8
    DesignSize = (
      210
      59)
    object CheckBox19: TCheckBox
      Left = 5
      Top = 38
      Width = 72
      Height = 17
      Caption = #1058#1103#1090#1073#1080#1075' '#1077#1090
      TabOrder = 0
    end
    object DBCatActive: TDBLookupComboboxEh
      Left = 5
      Top = 14
      Width = 198
      Height = 21
      Anchors = [akLeft, akTop, akRight]
      DropDownBox.Sizable = True
      EditButtons = <>
      KeyField = 'ID'
      ListField = 'DESCRIPTION'
      ListSource = DSCmActCat
      TabOrder = 1
      Visible = True
    end
  end
  object CreditsDS: TOracleDataSet
    SQL.Strings = (
      'select ID '
      '  from cm_portfolio where 1=1'
      ''
      '')
    Optimize = False
    Cursor = crSQLWait
    Session = sboapiDataModule.SBSession
    Left = 488
    Top = 16
  end
  object CM_AK_REPORTS: TOraclePackage
    Session = sboapiDataModule.SBSession
    PackageName = 'CM_AK_REPORTS'
    ParameterMode = pmNamed
    Cursor = crHourGlass
    Left = 504
    Top = 48
  end
  object DSCurrencys: TDataSource
    DataSet = Currencys
    Left = 16
    Top = 56
  end
  object Currencys: TOracleDataSet
    SQL.Strings = (
      'SELECT valute,  valu_name'
      '  FROM AVALUTE'
      'ORDER BY VALUTE')
    Optimize = False
    Cursor = crSQLWait
    Session = sboapiDataModule.SBSession
    Left = 16
    Top = 24
  end
  object DSBranches: TDataSource
    DataSet = Branches
    Left = 56
    Top = 56
  end
  object Branches: TOracleDataSet
    SQL.Strings = (
      'SELECT id, name'
      '  FROM filial')
    Optimize = False
    Cursor = crSQLWait
    Session = sboapiDataModule.SBSession
    Left = 56
    Top = 24
  end
  object DSUserGroups: TDataSource
    DataSet = UserGroups
    Left = 160
    Top = 88
  end
  object UserGroups: TOracleDataSet
    SQL.Strings = (
      'SELECT id, description'
      '  FROM cm_usergroups')
    Optimize = False
    Cursor = crSQLWait
    Session = sboapiDataModule.SBSession
    Left = 176
    Top = 24
    object UserGroupsID: TFloatField
      FieldName = 'ID'
      Required = True
    end
    object UserGroupsDESCRIPTION: TWideStringField
      FieldName = 'DESCRIPTION'
      Size = 64
    end
  end
  object DSPersons: TDataSource
    DataSet = Persons
    Left = 96
    Top = 56
  end
  object Persons: TOracleDataSet
    SQL.Strings = (
      'SELECT id,  descripion'
      '  FROM cm_persons')
    Optimize = False
    Cursor = crSQLWait
    Session = sboapiDataModule.SBSession
    Left = 96
    Top = 24
  end
  object DSCategories: TDataSource
    DataSet = Categories
    Left = 136
    Top = 56
  end
  object Categories: TOracleDataSet
    SQL.Strings = (
      'SELECT id, description'
      '  FROM cm_credittypes')
    Optimize = False
    Cursor = crSQLWait
    Session = sboapiDataModule.SBSession
    Left = 136
    Top = 24
  end
  object Customers: TOracleDataSet
    SQL.Strings = (
      'SELECT id, id||'#39'-'#39'||name idname'
      '  FROM customers'
      'order by id')
    Optimize = False
    Cursor = crSQLWait
    Session = sboapiDataModule.SBSession
    Left = 256
    Top = 24
  end
  object DSCustomers: TDataSource
    DataSet = Customers
    Left = 280
    Top = 80
  end
  object Districts: TOracleDataSet
    SQL.Strings = (
      'SELECT id, id ||'#39'-'#39'||name idname'
      '  FROM agro_region'
      'order by id')
    Optimize = False
    Cursor = crSQLWait
    Session = sboapiDataModule.SBSession
    Left = 216
    Top = 24
    object DistrictsID: TFloatField
      FieldName = 'ID'
      Required = True
    end
    object DistrictsIDNAME: TWideStringField
      FieldName = 'IDNAME'
      Size = 169
    end
  end
  object DSDistricts: TDataSource
    DataSet = Districts
    Left = 216
    Top = 56
  end
  object CustNames: TOracleDataSet
    SQL.Strings = (
      'SELECT id, name idname'
      '  FROM customers'
      'order by name')
    Optimize = False
    Cursor = crSQLWait
    Session = sboapiDataModule.SBSession
    Left = 288
    Top = 24
  end
  object DSCustName: TDataSource
    DataSet = CustNames
    Left = 288
    Top = 48
  end
  object RepForms: TOracleDataSet
    SQL.Strings = (
      'select * from cm_bc_reports order by id')
    Optimize = False
    Cursor = crSQLWait
    Session = sboapiDataModule.SBSession
    Left = 336
    Top = 24
  end
  object DSRepForms: TDataSource
    DataSet = RepForms
    Left = 336
    Top = 56
  end
  object Periods: TOracleDataSet
    SQL.Strings = (
      'SELECT *'
      '  FROM cm_bp_purposes')
    Optimize = False
    Cursor = crSQLWait
    Session = sboapiDataModule.SBSession
    Left = 24
    Top = 97
  end
  object Statuses: TOracleDataSet
    SQL.Strings = (
      'SELECT 0 ID, '#39'Hesablanamayn'#39' STATNAME'
      '  FROM dual'
      'union'
      'SELECT 1, '#39'Hesablanan'#39
      '  FROM dual')
    Optimize = False
    Cursor = crSQLWait
    Session = sboapiDataModule.SBSession
    Left = 79
    Top = 97
  end
  object DSPeriods: TDataSource
    DataSet = Periods
    Left = 16
    Top = 148
  end
  object DSStatuses: TDataSource
    DataSet = Statuses
    Left = 32
    Top = 148
  end
  object ODSMakeTemp: TOracleDataSet
    SQL.Strings = (
      'insert into agro_history'
      'select * from cm_history where hdate=:enddat'
      '/'
      'insert into agro_tranches'
      'select * from cm_tranches tranchedate=:enddat'
      '/'
      'insert into agro_payments'
      
        'select * from cm_payments where paydate between :begdat and :end' +
        'dat'
      ''
      '')
    Optimize = False
    Variables.Data = {
      04000000020000000E0000003A0045004E0044004400410054000C0000000000
      0000000000000E0000003A004200450047004400410054000C00000000000000
      00000000}
    Cursor = crSQLWait
    Session = sboapiDataModule.SBSession
    Left = 128
    Top = 224
  end
  object Types: TOracleDataSet
    SQL.Strings = (
      'SELECT id, id ||'#39'-'#39'||typedesc idname'
      '  FROM cm_bp_types'
      'order by id')
    Optimize = False
    Cursor = crSQLWait
    Session = sboapiDataModule.SBSession
    Left = 376
    Top = 24
    object FloatField1: TFloatField
      FieldName = 'ID'
      Required = True
    end
    object StringField1: TWideStringField
      FieldName = 'IDNAME'
      Size = 169
    end
  end
  object DSTypes: TDataSource
    DataSet = Types
    Left = 376
    Top = 56
  end
  object Short: TOracleDataSet
    SQL.Strings = (
      'SELECT s.id, p.purposedesc||'#39'-'#39'||shortname as short, description'
      '  FROM cm_bp_sources s, cm_bp_purposes p'
      '  where purpid=p.id'
      '  order by short')
    Optimize = False
    Session = sboapiDataModule.SBSession
    Left = 418
    Top = 26
    object ShortID: TFloatField
      FieldName = 'ID'
      Required = True
    end
    object ShortSHORT: TWideStringField
      FieldName = 'SHORT'
      Size = 49
    end
    object ShortDESCRIPTION: TWideStringField
      FieldName = 'DESCRIPTION'
      Required = True
      Size = 255
    end
  end
  object DSShort: TDataSource
    DataSet = Short
    Left = 418
    Top = 56
  end
  object GTypes: TOracleDataSet
    SQL.Strings = (
      'SELECT id, name'
      '  FROM cm_ak_type')
    Optimize = False
    Cursor = crSQLWait
    Session = sboapiDataModule.SBSession
    Left = 458
    Top = 32
    object GTypesID: TFloatField
      FieldName = 'ID'
      Required = True
    end
    object GTypesNAME: TWideStringField
      FieldName = 'NAME'
      Size = 50
    end
  end
  object DSGType: TDataSource
    DataSet = GTypes
    Left = 458
    Top = 56
  end
  object zonaSrc: TDataSource
    DataSet = ZonaDataSet
    Left = 152
    Top = 224
  end
  object ZonaDataSet: TOracleDataSet
    SQL.Strings = (
      'select * from agro_economiczone ')
    Optimize = False
    QBEDefinition.QBEFieldDefs = {
      05000000020000000400000049004400010000000000080000004E0041004D00
      4500010000000000}
    Session = sboapiDataModule.SBSession
    Left = 304
    Top = 224
    object ZonaDataSetID: TFloatField
      FieldName = 'ID'
    end
    object ZonaDataSetNAME: TWideStringField
      FieldName = 'NAME'
      Size = 65
    end
  end
  object Kera: TCMExcelExport
    ConnectTo = ctNewInstance
    StyleColumnWidth = cwAutoFit
    ColumnWidth = 0
    FontTitles.Charset = DEFAULT_CHARSET
    FontTitles.Color = clNavy
    FontTitles.Height = -13
    FontTitles.Name = 'Azl Sans Serif'
    FontTitles.Style = [fsBold]
    BorderTitles.Weight = bwThin
    BorderTitles.LineStyle = blLine
    OrientationTitles = 0
    FontData.Charset = RUSSIAN_CHARSET
    FontData.Color = clWindowText
    FontData.Height = -11
    FontData.Name = 'Azl Sans Serif'
    FontData.Style = []
    FontSummary.Charset = DEFAULT_CHARSET
    FontSummary.Color = clWindowText
    FontSummary.Height = -11
    FontSummary.Name = 'Azl Sans Serif'
    FontSummary.Style = []
    SummarySelection = ssNone
    SummaryCalculation = scSUM
    Filename = 'kredit_pru1'
    Left = 176
    Top = 112
  end
  object DataSource1: TDataSource
    DataSet = OracleDataSet1
    Left = 360
    Top = 224
  end
  object OracleDataSet1: TOracleDataSet
    SQL.Strings = (
      
        'select  rownum,f.name,r.name region,pr.name Sahe, p.protnum,br.n' +
        'ame cust,p.ekin_sahe ,trunc(MONTHS_BETWEEN(p.duedatefirstcontrac' +
        't,p.dateofconclusion))period,p.creditlineamount,p.annualyinteres' +
        'trate ,cm_utils.Get_CreditFirstPlaneRest1(p.id) frist_tr'
      
        ',cm_utils.Get_CreditFirstTrDate(p.id) frist_trdat ,(select sum(t' +
        'rchamount) from cm_tranche_schedule where creditid=p.id and card' +
        'id=1 )tr1,(select sum(trchamount) from cm_tranche_schedule where' +
        ' creditid=p.id and cardid=2 )tr2,(select sum(trchamount) from cm' +
        '_tranche_schedule where creditid=p.id and cardid=3 )tr3         ' +
        '                             from '
      'cm_portfolio p,'
      'filial_t f,'
      'cm_business_plan b,'
      'agro_village v,'
      'agro_region r,'
      'cm_boorowerinfo br,'
      'agro_kredit_purpose pr'
      'where '
      'p.id=b.creditid and'
      'p.branchid=f.id and'
      'b.villageid=v.id and'
      'r.id=v.depend_id and '
      'p.id=br.creditid and'
      'p.credittype=14  and '
      'b.akpurpose=pr.id'
      ''
      ''
      ''
      ''
      ''
      ''
      ''
      ''
      ''
      '--order by f.name'
      ''
      ''
      '')
    Optimize = False
    QBEDefinition.QBEFieldDefs = {
      050000000C0000000C00000052004F0057004E0055004D000100000000000800
      00004E0041004D0045000100000000000C00000052004500470049004F004E00
      0100000000000800000053004100480045000100000000000E00000050005200
      4F0054004E0055004D0001000000000008000000430055005300540001000000
      00001200000045004B0049004E005F0053004100480045000100000000000C00
      000050004500520049004F004400010000000000200000004300520045004400
      490054004C0049004E00450041004D004F0055004E0054000100000000002600
      000041004E004E00550041004C00590049004E00540045005200450053005400
      520041005400450001000000000010000000460052004900530054005F005400
      520001000000000016000000460052004900530054005F005400520044004100
      5400010000000000}
    Session = sboapiDataModule.SBSession
    Left = 336
    Top = 224
  end
  object ExcelApplication1: TExcelApplication
    AutoConnect = False
    ConnectKind = ckRunningOrNew
    AutoQuit = False
    Left = 608
    Top = 328
  end
  object Pambiq: TOracleDataSet
    SQL.Strings = (
      
        'select r.name region, count(*) say, sum(nvl(p.ekin_sahe,0))ekin_' +
        'sahe ,sum(p.creditlineamount) creditlineamount ,sum(cm_utils.Get' +
        '_CreditFirstPlaneRest1(p.id)) frist_tr'
      ' from '
      'cm_portfolio p,'
      'filial_t f,'
      'cm_business_plan b,'
      'agro_village v,'
      'agro_region r,'
      'cm_boorowerinfo br,'
      'agro_kredit_purpose pr'
      'where '
      'p.id=b.creditid and'
      'p.branchid=f.id and'
      'b.villageid=v.id and'
      'r.id=v.depend_id and '
      'p.id=br.creditid and'
      'p.credittype=14  and '
      'b.akpurpose=pr.id and '
      'pr.id=55'
      ''
      ''
      ''
      'group  by r.name '
      'order by r.name')
    Optimize = False
    QBEDefinition.QBEFieldDefs = {
      05000000050000000C00000052004500470049004F004E000100000000001200
      000045004B0049004E005F005300410048004500010000000000200000004300
      520045004400490054004C0049004E00450041004D004F0055004E0054000100
      0000000010000000460052004900530054005F00540052000100000000000600
      0000530041005900010000000000}
    Session = sboapiDataModule.SBSession
    Left = 488
    Top = 384
    object PambiqREGION: TWideStringField
      FieldName = 'REGION'
      Size = 2048
    end
    object PambiqEKIN_SAHE: TFloatField
      FieldName = 'EKIN_SAHE'
    end
    object PambiqCREDITLINEAMOUNT: TFloatField
      FieldName = 'CREDITLINEAMOUNT'
    end
    object PambiqFRIST_TR: TFloatField
      FieldName = 'FRIST_TR'
    end
    object PambiqSAY: TFloatField
      FieldName = 'SAY'
    end
  end
  object tutun: TOracleDataSet
    SQL.Strings = (
      
        'select r.name region, count(*) say, sum(nvl(p.ekin_sahe,0))ekin_' +
        'sahe ,sum(p.creditlineamount) creditlineamount ,sum(cm_utils.Get' +
        '_CreditFirstPlaneRest1(p.id)) frist_tr'
      ' from '
      'cm_portfolio p,'
      'filial_t f,'
      'cm_business_plan b,'
      'agro_village v,'
      'agro_region r,'
      'cm_boorowerinfo br,'
      'agro_kredit_purpose pr'
      'where '
      'p.id=b.creditid and'
      'p.branchid=f.id and'
      'b.villageid=v.id and'
      'r.id=v.depend_id and '
      'p.id=br.creditid and'
      'p.credittype=14  and '
      'b.akpurpose=pr.id and '
      'pr.id=56'
      ''
      ''
      ''
      ''
      ''
      'group  by r.name '
      'order by r.name')
    Optimize = False
    QBEDefinition.QBEFieldDefs = {
      05000000050000000C00000052004500470049004F004E000100000000001200
      000045004B0049004E005F005300410048004500010000000000200000004300
      520045004400490054004C0049004E00450041004D004F0055004E0054000100
      0000000010000000460052004900530054005F00540052000100000000000600
      0000530041005900010000000000}
    Session = sboapiDataModule.SBSession
    Left = 544
    Top = 384
    object WideStringField1: TWideStringField
      FieldName = 'REGION'
      Size = 2048
    end
    object FloatField2: TFloatField
      FieldName = 'EKIN_SAHE'
    end
    object FloatField3: TFloatField
      FieldName = 'CREDITLINEAMOUNT'
    end
    object FloatField4: TFloatField
      FieldName = 'FRIST_TR'
    end
    object FloatField5: TFloatField
      FieldName = 'SAY'
    end
  end
  object qardali: TOracleDataSet
    SQL.Strings = (
      
        'select r.name region, count(*) say, sum(nvl(p.ekin_sahe,0))ekin_' +
        'sahe ,sum(p.creditlineamount) creditlineamount ,sum(cm_utils.Get' +
        '_CreditFirstPlaneRest1(p.id)) frist_tr'
      ' from '
      'cm_portfolio p,'
      'filial_t f,'
      'cm_business_plan b,'
      'agro_village v,'
      'agro_region r,'
      'cm_boorowerinfo br,'
      'agro_kredit_purpose pr'
      'where '
      'p.id=b.creditid and'
      'p.branchid=f.id and'
      'b.villageid=v.id and'
      'r.id=v.depend_id and '
      'p.id=br.creditid and'
      'p.credittype=14  and '
      'b.akpurpose=pr.id and '
      'pr.id=57'
      ''
      ''
      ''
      ''
      ''
      ''
      'group  by r.name '
      'order by r.name')
    Optimize = False
    QBEDefinition.QBEFieldDefs = {
      05000000050000000C00000052004500470049004F004E000100000000001200
      000045004B0049004E005F005300410048004500010000000000200000004300
      520045004400490054004C0049004E00450041004D004F0055004E0054000100
      0000000010000000460052004900530054005F00540052000100000000000600
      0000530041005900010000000000}
    Session = sboapiDataModule.SBSession
    Left = 600
    Top = 384
    object WideStringField2: TWideStringField
      FieldName = 'REGION'
      Size = 2048
    end
    object FloatField6: TFloatField
      FieldName = 'EKIN_SAHE'
    end
    object FloatField7: TFloatField
      FieldName = 'CREDITLINEAMOUNT'
    end
    object FloatField8: TFloatField
      FieldName = 'FRIST_TR'
    end
    object FloatField9: TFloatField
      FieldName = 'SAY'
    end
  end
  object main: TOracleDataSet
    SQL.Strings = (
      
        'select p.id,p.boorowerid,p.numberofcredit,m.givedate,m.totalamou' +
        'nt,m.totalamount-cm_ak_reports. qetname_qaliq(p.id) qet_qaliq,'
      
        'f.name filal,d.name rayon,p.dateofgrant,p.duedatefirstcontract,p' +
        '.creditlineamount,pay.odesas,pay.odfaiz,'
      
        'h.rest,h.interestrest,h.duerest,h.dueinterestrest,r.purposedesc|' +
        '|'#39'('#39'||s.shortname||'#39')'#39' credperiod,'
      
        '(select sum(payedamt)+sum(payeddueamt)    from cm_payments  wher' +
        'e'
      'paydate>=:dat and creditid=p.id) cari,'
      
        '(select sum(payedintamt)+sum(payeddueintamt)odfaiz   from cm_pay' +
        'ments  where'
      'paydate>=:dat and creditid=p.id) ayda'
      'from cm_active_credits p ,cm_curr_state h,cm_legal_measures m,'
      'cm_business_plan b, agro_region d, agro_village v,filial f,'
      
        '(select creditid, sum(payedamt)+sum(payeddueamt) odesas,sum(paye' +
        'dintamt)+sum(payeddueintamt)odfaiz   from cm_payments  group by ' +
        'creditid)pay'
      ',cm_bp_purposes r,cm_bp_sources s'
      'where  p.id=h.creditid '
      'and v.depend_id = d.id (+)'
      'AND b.villageid = v.id (+)'
      'AND b.creditid (+) = p.id'
      'and p.branchid=f.id  '
      'and p.id=pay.creditid(+)'
      'AND b.purpose = r.id(+)'
      'AND b.source = s.id(+)'
      'and p.id=m.creditid '
      'and m.measurecode=7'
      
        'and p.id in(select creditid from cm_legal_measures where measure' +
        'code =14)'
      'order by id')
    Optimize = False
    Variables.Data = {
      0400000001000000080000003A004400410054000C0000000000000000000000}
    QBEDefinition.QBEFieldDefs = {
      050000001400000004000000490044000100000000001400000042004F004F00
      52004F00570045005200490044000100000000001C0000004E0055004D004200
      450052004F004600430052004500440049005400010000000000100000004700
      49005600450044004100540045000100000000001600000054004F0054004100
      4C0041004D004F0055004E005400010000000000120000005100450054005F00
      510041004C00490051000100000000000A000000460049004C0041004C000100
      000000000A0000005200410059004F004E000100000000001600000044004100
      540045004F0046004700520041004E0054000100000000002800000044005500
      450044004100540045004600490052005300540043004F004E00540052004100
      43005400010000000000200000004300520045004400490054004C0049004E00
      450041004D004F0055004E0054000100000000000C0000004F00440045005300
      410053000100000000000C0000004F0044004600410049005A00010000000000
      0800000052004500530054000100000000001800000049004E00540045005200
      45005300540052004500530054000100000000000E0000004400550045005200
      4500530054000100000000001E00000044005500450049004E00540045005200
      4500530054005200450053005400010000000000140000004300520045004400
      50004500520049004F0044000100000000000800000043004100520049000100
      00000000080000004100590044004100010000000000}
    Session = sboapiDataModule.SBSession
    Left = 32
    Top = 336
    object mainID: TFloatField
      FieldName = 'ID'
    end
    object mainBOOROWERID: TFloatField
      FieldName = 'BOOROWERID'
    end
    object mainNUMBEROFCREDIT: TWideStringField
      FieldName = 'NUMBEROFCREDIT'
      Size = 32
    end
    object mainGIVEDATE: TDateTimeField
      FieldName = 'GIVEDATE'
    end
    object mainTOTALAMOUNT: TFloatField
      FieldName = 'TOTALAMOUNT'
    end
    object mainQET_QALIQ: TFloatField
      FieldName = 'QET_QALIQ'
    end
    object mainFILAL: TWideStringField
      FieldName = 'FILAL'
      Size = 90
    end
    object mainRAYON: TWideStringField
      FieldName = 'RAYON'
      Size = 128
    end
    object mainDATEOFGRANT: TDateTimeField
      FieldName = 'DATEOFGRANT'
    end
    object mainDUEDATEFIRSTCONTRACT: TDateTimeField
      FieldName = 'DUEDATEFIRSTCONTRACT'
    end
    object mainCREDITLINEAMOUNT: TFloatField
      FieldName = 'CREDITLINEAMOUNT'
    end
    object mainODESAS: TFloatField
      FieldName = 'ODESAS'
    end
    object mainODFAIZ: TFloatField
      FieldName = 'ODFAIZ'
    end
    object mainREST: TFloatField
      FieldName = 'REST'
    end
    object mainINTERESTREST: TFloatField
      FieldName = 'INTERESTREST'
    end
    object mainDUEREST: TFloatField
      FieldName = 'DUEREST'
    end
    object mainDUEINTERESTREST: TFloatField
      FieldName = 'DUEINTERESTREST'
    end
    object mainCREDPERIOD: TWideStringField
      FieldName = 'CREDPERIOD'
      Size = 112
    end
    object mainCARI: TFloatField
      FieldName = 'CARI'
    end
    object mainAYDA: TFloatField
      FieldName = 'AYDA'
    end
  end
  object OracleDataSet3: TOracleDataSet
    SQL.Strings = (
      'select * from cm_yonetme where creditid=:creditid '
      'order by id')
    Optimize = False
    Variables.Data = {
      0400000001000000120000003A00430052004500440049005400490044000300
      00000000000000000000}
    QBEDefinition.QBEFieldDefs = {
      05000000060000000400000049004400010000000000080000004E0041004D00
      45000100000000001200000057004800450052004500460052004F004D000100
      000000000E00000041004D004D004F0055004E00540001000000000010000000
      4300520045004400490054004900440001000000000006000000440041005400
      010000000000}
    Session = sboapiDataModule.SBSession
    Left = 88
    Top = 336
    object OracleDataSet3ID: TFloatField
      FieldName = 'ID'
    end
    object OracleDataSet3NAME: TWideStringField
      FieldName = 'NAME'
      Size = 150
    end
    object OracleDataSet3WHEREFROM: TWideStringField
      FieldName = 'WHEREFROM'
      Size = 150
    end
    object OracleDataSet3AMMOUNT: TFloatField
      FieldName = 'AMMOUNT'
    end
    object OracleDataSet3CREDITID: TFloatField
      FieldName = 'CREDITID'
    end
    object OracleDataSet3DAT: TDateTimeField
      FieldName = 'DAT'
    end
  end
  object OracleDataSet2: TOracleDataSet
    Optimize = False
    Left = 160
    Top = 48
  end
  object OracleDataSet4: TOracleDataSet
    Optimize = False
    Left = 96
    Top = 48
  end
  object Ipoteka: TOracleDataSet
    SQL.Strings = (
      
        'select p.id,p.boorowerid,p.numberofcredit, b.name,b.boorowerid p' +
        'asnum,b.pincode,b.phonenumber,b.guarantorname unvan, b.address,c' +
        'm_common.AccountNumber_Get(a.loanaccid) suda,'
      
        'cm_common.AccountNumber_Get(a.interestaccid) faiz,cm_common.Acco' +
        'untNumber_Get(a.contractaccid) cari,f.name filial,p.creditlineam' +
        'ount,p.dateofconclusion,p.duedatefirstcontract,'
      
        'p.annualyinterestrate,b.q_esas,b.q_faiz,p.annualyoverduerate, 0 ' +
        'vaxtkeceborc,pay.esasdan,caripay.esasdan cariesas,pay.faizden,ca' +
        'ripay.faizden carifaiz,pay.gec_esas,caripay.gec_esas carigec_esa' +
        's,'
      
        'h.rest,h.interestrest,h.duerest,h.stopcalcdate,p.purposeofcredit' +
        ' ,cm_utils.Get_creditPlanRest(p.id,:dat) vaxtcat from '
      
        'cm_portfolio p,cm_boorowerinfo b,cm_accounts a,filial_t f,cm_his' +
        'tory h,'
      
        '(select creditid,sum(payedamt)esasdan,sum(payedintamt) faizden,s' +
        'um(payeddueamt)gec_esas from cm_payments'
      'group by creditid) pay,'
      
        '(select creditid,sum(payedamt)esasdan,sum(payedintamt) faizden,s' +
        'um(payeddueamt)gec_esas from cm_payments'
      
        'where PAYDATE between cm_utils.get_firstmonth(:dat) and cm_utils' +
        '.get_lastmonth(:dat)'
      ''
      'group by creditid)caripay'
      'where '
      'p.id=b.creditid and'
      'h.hdate=:dat    and'
      'p.credittype=15 and '
      'p.usrgroup=13   and'
      'p.id=a.creditid and'
      'p.branchid=f.id and '
      'p.id=h.creditid and '
      'p.id=pay.creditid(+)and '
      'p.id=caripay.creditid(+)')
    Optimize = False
    Variables.Data = {
      0400000001000000080000003A004400410054000C0000000000000000000000}
    QBEDefinition.QBEFieldDefs = {
      050000002100000004000000490044000100000000001400000042004F004F00
      52004F00570045005200490044000100000000001C0000004E0055004D004200
      450052004F004600430052004500440049005400010000000000080000004E00
      41004D0045000100000000000C0000005000410053004E0055004D0001000000
      00000E000000500049004E0043004F0044004500010000000000160000005000
      48004F004E0045004E0055004D004200450052000100000000000A0000005500
      4E00560041004E000100000000000E0000004100440044005200450053005300
      0100000000000800000053005500440041000100000000000800000046004100
      49005A000100000000000800000043004100520049000100000000000C000000
      460049004C00490041004C000100000000002000000043005200450044004900
      54004C0049004E00450041004D004F0055004E00540001000000000020000000
      44004100540045004F00460043004F004E0043004C005500530049004F004E00
      0100000000002800000044005500450044004100540045004600490052005300
      540043004F004E00540052004100430054000100000000002600000041004E00
      4E00550041004C00590049004E00540045005200450053005400520041005400
      45000100000000000C00000051005F0045005300410053000100000000000C00
      000051005F004600410049005A000100000000002400000041004E004E005500
      41004C0059004F00560045005200440055004500520041005400450001000000
      00001800000056004100580054004B0045004300450042004F00520043000100
      000000000E0000004500530041005300440041004E0001000000000010000000
      430041005200490045005300410053000100000000000E000000460041004900
      5A00440045004E00010000000000100000004300410052004900460041004900
      5A00010000000000080000005200450053005400010000000000180000004900
      4E0054004500520045005300540052004500530054000100000000000E000000
      44005500450052004500530054000100000000001E0000005000550052005000
      4F00530045004F00460043005200450044004900540001000000000018000000
      530054004F005000430041004C00430044004100540045000100000000001000
      00004700450043005F0045005300410053000100000000001800000043004100
      520049004700450043005F0045005300410053000100000000000E0000005600
      410058005400430041005400010000000000}
    Session = sboapiDataModule.SBSession
    Left = 448
    Top = 384
    object IpotekaID: TFloatField
      DisplayLabel = 'Kredit id'
      FieldName = 'ID'
      Required = True
    end
    object IpotekaBOOROWERID: TFloatField
      DisplayLabel = 'M'#252#351't'#601'ri id'
      FieldName = 'BOOROWERID'
    end
    object IpotekaNUMBEROFCREDIT: TWideStringField
      DisplayLabel = 'M'#252'qavile No'
      FieldName = 'NUMBEROFCREDIT'
      Size = 32
    end
    object IpotekaNAME: TWideStringField
      DisplayLabel = 'Borclunun A.S.A'
      FieldName = 'NAME'
      Size = 150
    end
    object IpotekaPASNUM: TWideStringField
      DisplayLabel = #350#601'xsiy'#601't v'#601'siq'#601'si'
      FieldName = 'PASNUM'
      Size = 32
    end
    object IpotekaPINCODE: TWideStringField
      DisplayLabel = 'Pin'
      FieldName = 'PINCODE'
      Size = 50
    end
    object IpotekaPHONENUMBER: TWideStringField
      DisplayLabel = 'Telefon n'#246'mr'#601'l'#601'ri (+994)'
      FieldName = 'PHONENUMBER'
      Size = 500
    end
    object IpotekaUNVAN: TWideStringField
      DisplayLabel = 'Qeydiyyat '#252'nvan'#305
      FieldName = 'UNVAN'
      Size = 200
    end
    object IpotekaADDRESS: TWideStringField
      DisplayLabel = 'ipoteka predmetinin '#252'nvan'#305
      FieldName = 'ADDRESS'
      Size = 300
    end
    object IpotekaSUDA: TWideStringField
      DisplayLabel = #399'sas borc hesab n'#246'mr'#601'si (2501)'
      FieldName = 'SUDA'
      Size = 4000
    end
    object IpotekaFAIZ: TWideStringField
      DisplayLabel = 'Faiz borc hesab n'#246'mr'#601'si (2401)'
      FieldName = 'FAIZ'
      Size = 4000
    end
    object IpotekaCARI: TWideStringField
      DisplayLabel = 'Cari hesab v'#601' ya tranzit hesab n'#246'mr'#601'si'
      FieldName = 'CARI'
      Size = 4000
    end
    object IpotekaFILIAL: TWideStringField
      DisplayLabel = 'Filial'
      FieldName = 'FILIAL'
      Size = 90
    end
    object IpotekaCREDITLINEAMOUNT: TFloatField
      DisplayLabel = 'Kreditin m'#601'bl'#601#287'i'
      FieldName = 'CREDITLINEAMOUNT'
    end
    object IpotekaDATEOFCONCLUSION: TDateTimeField
      DisplayLabel = 'Verilm'#601' tarixi'
      FieldName = 'DATEOFCONCLUSION'
    end
    object IpotekaDUEDATEFIRSTCONTRACT: TDateTimeField
      DisplayLabel = 'Bitm'#601' tarixi'
      FieldName = 'DUEDATEFIRSTCONTRACT'
    end
    object IpotekaANNUALYINTERESTRATE: TFloatField
      DisplayLabel = 'Faiz d'#601'r'#601'c'#601'si'
      FieldName = 'ANNUALYINTERESTRATE'
    end
    object IpotekaQ_ESAS: TFloatField
      DisplayLabel = 'Q'#601'bul olunan '#601'sas'
      FieldName = 'Q_ESAS'
    end
    object IpotekaQ_FAIZ: TFloatField
      DisplayLabel = 'Q'#601'bul olunan faiz'
      FieldName = 'Q_FAIZ'
    end
    object IpotekaANNUALYOVERDUERATE: TFloatField
      DisplayLabel = 'Gecikm'#601' faizi'
      FieldName = 'ANNUALYOVERDUERATE'
    end
    object IpotekaVAXTKECEBORC: TFloatField
      DisplayLabel = 'Vaxt'#305' kecmi'#351' borc'
      FieldName = 'VAXTKECEBORC'
    end
    object IpotekaESASDAN: TFloatField
      DisplayLabel = 'Q'#601'bul olunandan '#246'd'#601'n'#601'n '#601'sas borc'
      FieldName = 'ESASDAN'
    end
    object IpotekaCARIESAS: TFloatField
      DisplayLabel = 'Cari ayada'
      FieldName = 'CARIESAS'
    end
    object IpotekaFAIZDEN: TFloatField
      DisplayLabel = 'q'#601'bul olunandan '#246'd'#601'nil'#601'n faiz'
      FieldName = 'FAIZDEN'
    end
    object IpotekaCARIFAIZ: TFloatField
      DisplayLabel = 'Cari ayda'
      FieldName = 'CARIFAIZ'
    end
    object IpotekaGEC_ESAS: TFloatField
      DisplayLabel = 'Abb '#246'd'#601'nil'#601'n faz'
      FieldName = 'GEC_ESAS'
    end
    object IpotekaCARIGEC_ESAS: TFloatField
      DisplayLabel = 'Abb Cari ayda'
      FieldName = 'CARIGEC_ESAS'
    end
    object IpotekaREST: TFloatField
      DisplayLabel = 'Qaliq '#601'sas'
      FieldName = 'REST'
    end
    object IpotekaINTERESTREST: TFloatField
      DisplayLabel = 'Aqrar ASCFaiz qal'#305#287#305
      FieldName = 'INTERESTREST'
    end
    object IpotekaDUEREST: TFloatField
      DisplayLabel = 'ABB Faiz qal'#305#287#305
      FieldName = 'DUEREST'
    end
    object IpotekaVAXTCAT: TFloatField
      FieldName = 'VAXTCAT'
    end
    object IpotekaSTOPCALCDATE: TDateTimeField
      DisplayLabel = 'faizl'#601'rin statusu (dayand'#305'r'#305'l'#305'b)'
      FieldName = 'STOPCALCDATE'
    end
    object IpotekaPURPOSEOFCREDIT: TWideStringField
      DisplayLabel = 'MTK'
      FieldName = 'PURPOSEOFCREDIT'
      Size = 300
    end
  end
  object CMExcelExport1: TCMExcelExport
    StyleColumnWidth = cwDefault
    ColumnWidth = 0
    FontTitles.Charset = DEFAULT_CHARSET
    FontTitles.Color = clWindowText
    FontTitles.Height = -11
    FontTitles.Name = 'Tahoma'
    FontTitles.Style = []
    OrientationTitles = 0
    FontData.Charset = DEFAULT_CHARSET
    FontData.Color = clWindowText
    FontData.Height = -11
    FontData.Name = 'Tahoma'
    FontData.Style = []
    FontSummary.Charset = DEFAULT_CHARSET
    FontSummary.Color = clWindowText
    FontSummary.Height = -11
    FontSummary.Name = 'Tahoma'
    FontSummary.Style = []
    SummarySelection = ssNone
    SummaryCalculation = scSUM
    Left = 80
    Top = 48
  end
  object EExport: TCMExcelExport
    ConnectTo = ctNewInstance
    StyleColumnWidth = cwDefault
    ColumnWidth = 0
    FontTitles.Charset = DEFAULT_CHARSET
    FontTitles.Color = clWindowText
    FontTitles.Height = -11
    FontTitles.Name = 'Tahoma'
    FontTitles.Style = []
    BorderTitles.Weight = bwThin
    BorderTitles.LineStyle = blLine
    OrientationTitles = 0
    FontData.Charset = DEFAULT_CHARSET
    FontData.Color = clWindowText
    FontData.Height = -11
    FontData.Name = 'Tahoma'
    FontData.Style = []
    FontSummary.Charset = DEFAULT_CHARSET
    FontSummary.Color = clWindowText
    FontSummary.Height = -11
    FontSummary.Name = 'Tahoma'
    FontSummary.Style = []
    SummarySelection = ssNone
    SummaryCalculation = scSUM
    Filename = #304'poteka'
    Left = 584
    Top = 328
  end
  object ODSCmActCat: TOracleDataSet
    SQL.Strings = (
      'select -1 id, '#39#220'mumi'#39' description from dual'
      'union'
      'select * from cm_active_categories')
    Optimize = False
    QBEDefinition.QBEFieldDefs = {
      0500000002000000040000002D0031000100000000000E0000002700DC004D00
      55004D0049002700010000000000}
    Session = sboapiDataModule.SBSession
    Left = 432
    Top = 320
  end
  object DSCmActCat: TDataSource
    DataSet = ODSCmActCat
    Left = 384
    Top = 320
  end
end
