object AKProgressForm: TAKProgressForm
  Left = 299
  Top = 185
  BorderIcons = []
  BorderStyle = bsSingle
  Caption = 
    '                            '#1060#1072#1080#1079#1083#1103#1088' '#1097#1077#1089#1072#1073#1083#1072#1085#1099#1088'. '#1101#1102#1079#1083#1103#1081#1080#1085'.   ....' +
    '.'
  ClientHeight = 16
  ClientWidth = 405
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Azl Sans Serif'
  Font.Style = []
  FormStyle = fsStayOnTop
  OldCreateOrder = False
  Position = poMainFormCenter
  PixelsPerInch = 96
  TextHeight = 13
  object ProgressShower: TProgressBar
    Left = 0
    Top = 0
    Width = 405
    Height = 16
    TabOrder = 0
  end
end
